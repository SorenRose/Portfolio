import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet make a roulette game
Amanda Ramos Nov. 12, 2012
 */

public class Roulette extends Applet implements ActionListener, AppletStub

{
    Random rand= new Random ();
    Button betBtn= new Button ("Bet");
    Button oddBtn= new Button ("Odd");
    Button evenBtn= new Button ("Even");
    Button singleBtn= new Button ("Single Number");
    Button resetBtn= new Button ("Reset");
    TextField betTF= new TextField ();
    TextField singleTF= new TextField ();

    Applet appletToLoad=new Applet();

    Font myFont= new Font( "Papyrus" ,1, 27 );
    Color myPurple=new Color( 200, 1, 200 );
    Color mystery=new Color (250, 85, 110 );
    Color myOrange=new Color (240, 150, 0 );

    int bet;
    int money=1000;
    String input="";
    String output="";
    int myNum;
    int rouletteNum;

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);

        resize(1300, 700);

        singleBtn.setVisible(false);
        evenBtn.setVisible(false);
        oddBtn.setVisible(false);
        singleTF.setVisible(false);

        singleBtn.setBounds( 340, 550, 100, 40 );
        this.add (singleBtn);
        singleBtn.addActionListener( this );
        singleBtn.setForeground( Color. white );
        singleBtn.setBackground( Color. blue );

        oddBtn.setBounds( 260, 550, 70, 40 );
        this.add (oddBtn);
        oddBtn.addActionListener( this );
        oddBtn.setForeground( Color. white );
        oddBtn.setBackground( Color. blue );

        evenBtn.setBounds( 180, 550, 70, 40 );
        this.add (evenBtn);
        evenBtn.addActionListener( this );
        evenBtn.setForeground( Color. white );
        evenBtn.setBackground( Color. blue );

        resetBtn.setBounds( 100, 550, 70, 40 );
        this.add (resetBtn);
        resetBtn.addActionListener( this );
        resetBtn.setForeground( Color. white );
        resetBtn.setBackground( Color. blue );

        betBtn.setBounds( 20, 550, 70, 40 );
        this.add (betBtn);
        betBtn.addActionListener( this );
        betBtn.setForeground( Color. white );
        betBtn.setBackground( Color. blue );

        betTF.setBounds( 20, 100, 150, 40 );
        this.add (betTF);
        betTF.addActionListener( this );
        betTF.setForeground( Color. white );
        betTF.setBackground( Color. blue );

        singleTF.setBounds( 20, 200, 150, 40 );
        this.add (singleTF);
        singleTF.addActionListener( this );
        singleTF.setForeground( Color. white );
        singleTF.setBackground( Color. blue );
    }

    public void paint (Graphics g)
    {
        g.setColor( mystery);
        g.fillRect(0,0, 1300, 700);
        g.setColor(Color. white);
        g.drawString(output, 300, 200);
        g.drawString("You have "+money+" dollars left", 300, 250);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == betBtn )
        {
            input=betTF.getText();
            bet=Integer.parseInt(input);

            if(bet>0&&bet<=money)
            {
                output="Nice Bet";
                betBtn.setVisible(false);
                singleBtn.setVisible(true);
                evenBtn.setVisible(true);
                oddBtn.setVisible(true);
                singleTF.setVisible(true);
                betTF.setVisible(false);
            }
            else
                output="Invalid bet";
        }
        if(e.getSource() == oddBtn )
        {

        }
        if(e.getSource() == evenBtn )
        {

        }
        if ( rouletteNum == 29 )
            myNum=30; 
        if ( rouletteNum == 28 )
            myNum=29; 
        if ( rouletteNum == 27 )
            myNum=28; 
        if ( rouletteNum == 26 )
            myNum=27; 
        if ( rouletteNum == 25 )
            myNum=26; 
        if ( rouletteNum == 24 )
            myNum=25; 
        if ( rouletteNum == 23 )
            myNum=24; 
        if ( rouletteNum == 22 )
            myNum=23; 
        if ( rouletteNum == 21 )
            myNum=22; 
        if ( rouletteNum == 20 )
            myNum=21; 
        if ( rouletteNum == 19 )
            myNum=20; 
        if ( rouletteNum == 18 )
            myNum=19; 
        if ( rouletteNum == 17 )
            myNum=18; 
        if ( rouletteNum == 16 )
            myNum=17; 
        if ( rouletteNum == 15 )
            myNum=16; 
        if ( rouletteNum == 14 )
            myNum=15; 
        if ( rouletteNum == 13 )
            myNum=14; 
        if ( rouletteNum == 12 )
            myNum=13; 
        if ( rouletteNum == 11 )
            myNum=12;
        if ( rouletteNum == 10 )
            myNum=11;
        if ( rouletteNum == 9 )
            myNum=10;
        if ( rouletteNum == 8 )
            myNum=9;
        if ( rouletteNum == 7 )
            myNum=8;
        if ( rouletteNum == 6 )
            myNum=7;
        if ( rouletteNum == 5 )
            myNum=6;
        if ( rouletteNum == 4 )
            myNum=5;
        if ( rouletteNum == 3 )
            myNum=4;
        if ( rouletteNum == 2 )
            myNum=3;
        if ( rouletteNum == 1 )
            myNum=2;
        if ( rouletteNum == 0 )
            myNum=1;
        repaint();
    }
}