import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet make a tutorial for Mastermind
Amanda Ramos Oct. 22, 2012
 */

public class NIMTutorial extends Applet implements ActionListener, AppletStub

{
    Random rand= new Random ();
    Button nextBtn= new Button ("Next");
    Button backBtn= new Button ("Back");
    Button endBtn= new Button ("End");
    Font myFont= new Font( "Papyrus" ,1, 27 );
    Applet appletToLoad= new Applet();

    int pageCt=0;
    String output="";

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);

        resize(1300,700);

        nextBtn.setBounds( 500, 600, 100, 40 );
        this.add (nextBtn);
        nextBtn.addActionListener( this );

        backBtn.setBounds( 350, 600, 100, 40 );
        this.add (backBtn);
        backBtn.addActionListener( this );

        endBtn.setBounds( 200, 600, 100, 40 );
        this.add (endBtn);
        endBtn.addActionListener( this );

    }

    public void paint (Graphics g)
    {
        backBtn.setForeground( Color. blue );
        backBtn.setBackground( Color. yellow );
        endBtn.setForeground( Color. blue );
        endBtn.setBackground( Color. yellow );
        nextBtn.setForeground( Color. blue );
        nextBtn.setBackground( Color. yellow );
        g.setColor(Color. red);
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. black);
        g.setFont ( myFont );
        if(pageCt==0)
        {
            g.drawString("Welcome to this NIM tutorial, press next to continue.", 300, 300);
            g.drawString("To go back to the game, press end to go back.", 300, 350);
        }
        if(pageCt==1)
        {
            g.drawString("NIM is a game of taking away rocks or chips. the player who takes the last one wins!", 10, 30);
            g.drawString("This game allows two players to play against each other to get the last rock left. A player", 10, 70);
            g.drawString("can take 1, 2, or 3 rocks durning his/her turn. Once the player if finished removing the number", 10, 110);
            g.drawString("of rocks they want to take, the next player can take his/her turn. Once he/she made their turn,", 10, 150);
            g.drawString(" player one goes again. Once they get down to zero rocks, the one who took the last rock(s) is ", 10, 190);
            g.drawString("now the winner! No matter what, a player cannot take more than 3, even if there is 4 rocks ", 10, 230);
            g.drawString("remaining. The number of rocks can be between 15 and 30, no more and no less.",10, 270);
        }
        if(pageCt==2)
        {
            g.drawString("Say the number of rocks is 25, player one can now take his/her turn and try to get down ", 10, 30);
            g.drawString("to the last rock. Lets say player one takes away 3 rocks, now the number is 22.", 10, 70);
            g.drawString("Now player two takes away 2 rocks. Now the number of remaining rocks is 20.", 10, 110 );
            g.drawString("Player one takes away 2 rocks, now 18 rocks are left.", 10, 150);
            g.drawString("Player two takes away 1 rock. Remaining rocks: 17", 10, 190);
            g.drawString("Player one takes away 3 rocks. Remaining rocks: 14", 10, 230);
            g.drawString("Player two takes away 2 rocks. Remaining rocks: 12", 10, 270);
            g.drawString("Player one takes away 3 rocks. Remaining rocks: 9", 10, 310);
            g.drawString("Player two takes away 3 rocks. Remaining rocks: 6", 10, 350);
            g.drawString("Player one takes away 2 rocks. Remaining rocks: 4", 10, 390);
            g.drawString("Player two takes away 1 rock. Remaining rocks: 3", 10, 430);
            g.drawString("Player one takes away 3 rocks. Remaining rocks: 0. Player one wins!", 10, 470);
            g.drawString("NOTE: This was a demo game and the choices of how many they took was optional.", 10, 510);
            g.drawString("Have fun!", 10, 550); 
            nextBtn.setVisible(false);
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
            pageCt= pageCt+1;
            nextBtn.setVisible(true);
            if(pageCt==3)
            {
                nextBtn.setVisible(false);
            }
        }
        if(e.getSource() == endBtn )
        {
            {
                nextBtn.setVisible(false);
                endBtn.setVisible(false);
                backBtn.setVisible(false);
            }
            try
            {
                Class applet2=Class.forName("NIM");
                appletToLoad=(Applet)applet2.newInstance();
                appletToLoad.setStub(this);
                add(appletToLoad);
                appletToLoad.init();
                appletToLoad.start();

            }
            catch (Exception p){}
        }
        if(e.getSource() == backBtn )
        {
            pageCt= pageCt-1;
            if(pageCt==0)
            {
                backBtn.setVisible(false);
            }
            else if( pageCt==1)
            {  
                backBtn.setVisible(true);
            }
            else if( pageCt==2)
            {  
                backBtn.setVisible(true);
            }
            else if(pageCt==3)
                backBtn.setVisible(false);
        }  
        repaint();
    }
}