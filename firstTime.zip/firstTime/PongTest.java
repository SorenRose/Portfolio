import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet to make a game of Pong
Amanda Ramos Dec. 5, 2012
 */

public class PongTest extends Applet implements Runnable, KeyListener

{

    Thread main= new Thread(this);
    int ballX=300;
    int ballY=300;
    int xChange=6;
    int yChange=5;
    int rightY=300;
    int leftY=300;
    int leftY2=20;
    int yChange2=4;
    int rightScore, leftScore;
    Image buffer;
    Graphics bufferG;

    public void init()
    {
        this.setLayout(null);
        this.addKeyListener(this);
        resize(1300, 756);
        buffer=createImage(this.getWidth(),this.getHeight());
        bufferG= buffer.getGraphics();

        main.start();

    }

    public void run()
    {
        do
        {
            Rectangle leftRect= new Rectangle(20, leftY, 25, 90);
            Rectangle rightRect= new Rectangle(1190, rightY, 25, 90);
            Rectangle squareRect= new Rectangle(645, leftY2, 25, 90);
            Rectangle BallRect= new Rectangle(ballX, ballY, 50, 40);            
            ballX=ballX+xChange;
            ballY=ballY+yChange;
            repaint();
            try
            {main.sleep(20);}
            catch(Exception e){}
            if(ballY<5||ballY>660)
                yChange=-1*yChange;
            if(leftRect.intersects(BallRect))
                {
                    xChange=6;
                }
            if(rightRect.intersects(BallRect))
               {
                    xChange=-6;
                }
            if(BallRect.intersects(squareRect))
            { 
                xChange=xChange*-1;
            }
            if(leftY2<5&&leftY2>610)
                leftY2=leftY2*-1;
            if(ballY<leftY2)
                leftY2=leftY2-4;
            else if(ballY>leftY2)
                leftY2=leftY2+4;
            if (ballX<0)
            {
                ballX=500;
                rightScore++;
                xChange=xChange*-1;
            }
            if (ballX>1300)
            {
                ballX=500;
                leftScore++;
                xChange=xChange*-1;
            }        
        }
        while(true);

    }

    public void paint (Graphics g)
    {
        bufferG.setColor(Color.black);
        bufferG.fillRect(0,0, 1304, 756);
        bufferG.setColor(Color. blue);
        bufferG.setColor( Color. black);
        bufferG.fillRect(0,0,this.getWidth(),this.getHeight());
        bufferG.setColor(Color.green);
        bufferG.drawOval( ballX, ballY, 50, 40);
        bufferG.drawRect(1190, rightY, 25, 90);
        bufferG.drawRect(20, leftY, 25, 90);
        bufferG.drawRect(645, leftY2, 25,90 );
        bufferG.fillRect(0, 0, 13000, 5);
        bufferG.fillRect(0, 700, 13000, 5);
        bufferG.drawString("Left Score "+leftScore, 50, 30);
        bufferG.drawString("Right Score "+rightScore, 1100, 30);
        g.drawImage(buffer,0,0,this);
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public void keyReleased(KeyEvent e)
    {
        int code=e.getKeyCode();

        if(code==e.VK_DOWN&& rightY<600)
        {
            rightY=rightY+20;
        }
        if(code==e.VK_UP&& rightY>20)
        {
            rightY=rightY-20;
        }
        if(code==e.VK_D&& leftY>20)
        {
            leftY=leftY-20;
        }
        if(code==e.VK_SPACE&&leftY<600)
        {
            leftY=leftY+20;
        }
    }

    public void keyPressed(KeyEvent e){}

    public void keyTyped(KeyEvent e){}

}