import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet make a game using animation and the mouse
Amanda Ramos Nov. 29, 2012
 */
//for part 3 and part 4

public class MonsterAttack extends Applet implements Runnable, MouseListener, AppletStub, ActionListener

{

    Thread main= new Thread(this);
    int x=900;
    int y=10;
    int x1=10;
    int y1=5;
    int loopCt;
    Image boss1;
    Image boss2;
    Image boss3;
    Image boss4;
    Image boss5;
    Image boss6;
    Image boss7;
    Image boss8;
    Image boss9;
    Image boss10;
    Image boss11;
    Image gameover;
    int mouseX=0;
    int mouseY=0;
    int pageCt=0;
    Button ruleBtn= new Button ("Rules");
    Applet appletToLoad= new Applet();
    Font myFont= new Font( "Papyrus" ,1, 27 );

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);
        resize(1300, 700);
        this.addMouseListener(this);

        ruleBtn.setBounds( 200, 20, 100, 40 );
        this.add (ruleBtn);
        ruleBtn.addActionListener( this );

        main.start();

        boss1=this.getImage( this.getCodeBase(),"argorok.png");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss2=this.getImage( this.getCodeBase(),"gohma.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss3=this.getImage( this.getCodeBase(),"ghost.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss4=this.getImage( this.getCodeBase(),"scorpio.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss5=this.getImage( this.getCodeBase(),"volvagia.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss6=this.getImage( this.getCodeBase(),"twin.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss7=this.getImage( this.getCodeBase(),"bongo.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss8=this.getImage( this.getCodeBase(),"spider.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss9=this.getImage( this.getCodeBase(),"bloop.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss10=this.getImage( this.getCodeBase(),"bird.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        boss11=this.getImage( this.getCodeBase(),"ganon.jpg");
        //gotten from Google Images, search for Legend of Zelda bosses
        gameover=this.getImage( this.getCodeBase(),"game over.jpg");
        //gotten from Google Images, search for Legend of Zelda game over
    }

    public void run()
    {
        do
        {
            loopCt++;
            x=x+x1;
            y=y+y1;
            repaint();
            try
            {main.sleep(100);}
            catch(Exception e){}
            if(x<0)
            {
                x1= x1*-1;

            }
            else if (x>900)
            {
                x1= x1*-1;

            }
            if(y<0)
                y1=y1*-1;
            else if(y>600)
                y1=y1*-1;
        }
        while(pageCt<11);

    }

    public void paint (Graphics g)
    {
        if(pageCt==0)
            g.drawImage(boss1, x, y, 220, 230, this);
        if(pageCt==1)
            g.drawImage(boss2, x, y, 150, 150, this);
        if(pageCt==2)
            g.drawImage(boss3, x, y, 140, 140, this);
        if(pageCt==3)
            g.drawImage(boss4, x, y, 120, 120, this);
        if(pageCt==4)
            g.drawImage(boss5, x, y, 100, 100, this);
        if(pageCt==5)
            g.drawImage(boss6, x, y, 90, 90, this);
        if(pageCt==6)
            g.drawImage(boss7, x, y, 80, 80, this);
        if(pageCt==7)
            g.drawImage(boss8, x, y, 70, 70, this);
        if(pageCt==8)
            g.drawImage(boss9, x, y, 60, 60, this);
        if(pageCt==9)
            g.drawImage(boss10, x, y, 50, 50, this);
        if(pageCt==10)
            g.drawImage(boss11, x, y, 35, 35, this);
        g.setFont(myFont);
        if(pageCt==11)
        {    
            if(loopCt<600.0)
            {
                g.drawString("You Win!", 300, 300);
                ruleBtn.setVisible(false);
                g.drawImage(boss11, 100, 80, 100, 100, this);
                g.drawImage(boss10, 210, 190, 100, 100, this);
                g.drawImage(boss9, 310, 500, 100, 100, this);
                g.drawImage(boss8, 410, 450, 100, 100, this);
                g.drawImage(boss7, 510, 300, 100, 100, this);
                g.drawImage(boss6, 610, 230, 100, 100, this);
                g.drawImage(boss5, 710, 350, 100, 100, this);
            }
            else if(loopCt==600.0)
            {
                g.drawImage(gameover,50, 40, 1300, 700, this);
                ruleBtn.setVisible(false);

            }
        }
        g.drawString("Time "+ loopCt/10.0, 10, 30);
        if(loopCt==600.0)
        {
            pageCt=11;
        }
    }

    public void actionPerformed(ActionEvent e)
    {    
        if(e.getSource() == ruleBtn )
        {
            ruleBtn.setVisible(false);
            try
            {
                Class applet2=Class.forName("MonsterRules");
                appletToLoad=(Applet)applet2.newInstance();
                appletToLoad.setStub(this);
                add(appletToLoad);
                appletToLoad.init();
                appletToLoad.start();

            }
            catch (Exception p){}
        }

    }

    public void mouseClicked(MouseEvent e)
    {
        mouseX=e.getX();
        mouseY=e.getY();
        if(pageCt==0)
        {
            if((mouseX>=x&&mouseX<=x+220)&&
            (mouseY>=y&&mouseY<=y+230))
            {
                pageCt= pageCt+1;
                
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==1)
        {
            if((mouseX>=x&&mouseX<=x+150)&&
            (mouseY>=y&&mouseY<=y+150))
            {
                pageCt= pageCt+1;
                x1=14;
                y1=9;
                
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==2)
        {
            if((mouseX>=x&&mouseX<=x+140)&&
            (mouseY>=y&&mouseY<=y+140))
            {
                pageCt= pageCt+1;   
                x1=18;
                y1=13;
                
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==3)
        {
            if((mouseX>=x&&mouseX<=x+120)&&
            (mouseY>=y&&mouseY<=y+120))
            {
                pageCt= pageCt+1;   
                x1=22;
                y1=15;
                
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==4)
        {
            if((mouseX>=x&&mouseX<=x+100)&&
            (mouseY>=y&&mouseY<=y+100))
            {
                pageCt= pageCt+1;
                x1=26;
                y1=19;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==5)
        {
            if((mouseX>=x&&mouseX<=x+90)&&
            (mouseY>=y&&mouseY<=y+90))
            {
                pageCt= pageCt+1;  
                x1=30;
                y1=23;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==6)
        {
            if((mouseX>=x&&mouseX<=x+80)&&
            (mouseY>=y&&mouseY<=y+80))
            {
                pageCt= pageCt+1; 
                x1=34;
                y1=27;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==7)
        {
            if((mouseX>=x&&mouseX<=x+70)&&
            (mouseY>=y&&mouseY<=y+70))
            {
                pageCt= pageCt+1;  
                x1=38;
                y1=31; 
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==8)
        {
            if((mouseX>=x&&mouseX<=x+60)&&
            (mouseY>=y&&mouseY<=y+60))
            {
                pageCt= pageCt+1;   
                x1=42;
                y1=35;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==9)
        {
            if((mouseX>=x&&mouseX<=x+50)&&
            (mouseY>=y&&mouseY<=y+50))
            {
                pageCt= pageCt+1;   
                x1=46;
                y1=39;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        else if(pageCt==10)
        {
            if((mouseX>=x&&mouseX<=x+36)&&
            (mouseY>=y&&mouseY<=y+36))
            {
                pageCt= pageCt+1;   
                x1=50;
                y1=43;
                if(loopCt==600.0)
                {
                    pageCt=11;
                }
            }
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}

}