import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make Hang man
Amanda Ramos Jan. 2, 2013
 */

public class HangManTest extends Applet implements ActionListener

{

    char letter='A';
    Button letterBtns[]= new Button[26];
    Font myFont= new Font( "Papyrus" ,1, 20 );
    Image pictureArray[]= new Image[7];
    char secretLetters[]={'A','W','E','S','O','M','E'};
    char dashLetters[]={'-','-','-','-','-','-','-'};
    char guess='?';
    int chances=0;
    public void init()
    {
        this.setLayout(null);
        resize(1300, 756);

        pictureArray[0]=getImage( this.getCodeBase(),"hangman style1.png");
        pictureArray[1]=getImage( this.getCodeBase(),"hangman style2.png");
        pictureArray[2]=getImage( this.getCodeBase(),"hangman style3.png");
        pictureArray[3]=getImage( this.getCodeBase(),"hangman style4.png");
        pictureArray[4]=getImage( this.getCodeBase(),"hangman style5.png");
        pictureArray[5]=getImage( this.getCodeBase(),"hangman style6.png");
        pictureArray[6]=getImage( this.getCodeBase(),"hangman style7.png");
        
        for(int i=0; i<26; i++)
        {
            
            letterBtns[i]= new Button(""+letter);
            letterBtns[i].setBounds(50+40*i, 600, 30, 30);
            this.add(letterBtns[i]);
            letterBtns[i].addActionListener(this);
            
            letterBtns[i].setForeground( Color. white );
            letterBtns[i].setBackground( Color. black );
            letter++;
        }
        
    }

    public void paint (Graphics g)
    {
        g.setColor(Color. red);
        g.fillRect(0,0, 1300, 800);
        
        g.drawImage(pictureArray[0], 20, 20, 400, 430, this);
        
        for(int i=0; i<7; i++);
        g.drawString(""+dashLetters[i],200+40*i,400);
    }

    public void actionPerformed(ActionEvent e)
    {
        
    }

}