import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.awt.image.BufferedImage;
/*A simple applet to make Pacman
Amanda Ramos Jan. 14, 2012
 */

public class pacman extends Applet implements Runnable, KeyListener, MouseListener

{
    Thread main= new Thread(this);
    BufferedImage buffer;
    Graphics2D bufferG;
    Color TopColor;
    Color rightColor;
    Color BottomColor;
    Color leftColor;
    Font myFont= new Font( "Consolas" ,1, 20 );
    Image pictureArray[]= new Image[17];
    Image redArray[]= new Image[18];
    Image pinkArray[]= new Image[18];
    Image blueArray[]= new Image[18];
    Image orangeArray[]= new Image[18];
    int pacmanX=585, pacmanY=378, redX=555, redY=250, pinkX=300, pinkY=120, blueX=600, blueY=510, orangeX=450, orangeY=450;
    int rX=585, rY=375, pac1X=338, pac1Y=510, pac2X=843, pac2Y=510, pac3X=338, pac3Y=75, pac4X=843, pac4Y=75;
    int pX=345,p2X=380,p3X=410,p4X=440,p5X=470,p6X=500,p7X=530,p8X=560,p9X=595,p10X=630,p11X=660,p12X=690,p13X=720,p14X=750,p15X=780,p16X=810,p17X=845;
    int pY=455,p2Y=485,p3Y=515,p4Y=545,p5Y=580,p6Y=615,p7Y=655,p8Y=425,p9Y=395,p10Y=365,p11Y=325,p12Y=295,p13Y=265,p14Y=235,p15Y=195,p16Y=160,p17Y=125,p18Y=85,p19Y=45;
    boolean stand=true, right=false, left=false, up=false, down=false, dead=false, enemy=true, ghost=false,redghost=false,pinkghost=false;
    boolean blueghost=false,orangeghost=false, redeye=false,pinkeye=false,blueeye=false,orangeeye=false;
    boolean p1=true,p2=true,p3=true,p4=true,p5=true,p6=true,p7=true,p8=true,p9=true,p10=true,p11=true,p12=true,p13=true,p14=true,p15=true,p16=true,p17=true,p18=true;
    boolean p19=true,p20=true,p21=true,p22=true,p23=true,p24=true,p25=true,p26=true,p27=true,p28=true,p29=true,p30=true,p31=true,p32=true,p33=true,p34=true,p35=true;
    boolean p36=true,p37=true,p38=true,p39=true,p40=true,p41=true,p42=true,p43=true,p44=true,p45=true,p46=true,p47=true,p48=true,p49=true,p50=true,p51=true,p52=true;
    boolean p53=true,p54=true,p55=true,p56=true,p57=true,p58=true,p59=true,p60=true,p61=true,p62=true,p63=true,p64=true,p65=true,p66=true,p67=true,p68=true,p69=true;
    boolean p70=true,p71=true,p72=true,p73=true,p74=true,p75=true,p76=true,p77=true,p78=true,p79=true,p80=true,p81=true,p83=true,p84=true,p86=true;//82 and 85 were a copy
    boolean p87=true,p88=true,p89=true,p90=true,p91=true,p92=true,p93=true,p94=true,p95=true,p96=true,p97=true,p98=true,p99=true,p100=true,p101=true,p102=true,p103=true;
    boolean p104=true,p105=true,p106=true,p107=true,p108=true,p109=true,p110=true,p111=true,p112=true,p113=true,p114=true,p115=true,p116=true,p117=true,p118=true,p119=true;
    boolean p120=true,p121=true,p122=true,p123=true,p124=true,p125=true,p126=true,p127=true,p128=true,p129=true,p130=true,p131=true,p132=true,p133=true,p134=true,p135=true;
    boolean p136=true,p137=true,p138=true,p139=true,p140=true,p141=true,p142=true,p143=true,p144=true,p145=true;
    int frameCt=0;
    int frame2Ct=3;
    int loopCt, ghostCt=0, eatghostCt=0,redghostCt=8, redeyeCt=10, pinkghostCt=8, pinkeyeCt=10, blueghostCt=8,blueeyeCt=10, orangeghostCt=8, orangeeyeCt=10;
    int deadFrameCt=6, redframeCt=0, pinkframeCt=0, blueframeCt=0, orangeframeCt=0;
    int numLife=3;
    int pageCt=1, scoreCt=0;
    Image maze, life, rocoto;

    public void init()
    {
        this.setLayout(null);
        this.addKeyListener(this);
        this.addMouseListener(this);
        resize(1300, 756);
        buffer= new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_INT_ARGB);
        bufferG=buffer.createGraphics();

        pictureArray[0]=getImage( this.getCodeBase(),"pacman sprite5.png");
        pictureArray[1]=getImage( this.getCodeBase(),"pacman sprite1.png");
        pictureArray[2]=getImage( this.getCodeBase(),"pacman sprite3.png");
        pictureArray[3]=getImage( this.getCodeBase(),"pacman sprite5.png");
        pictureArray[4]=getImage( this.getCodeBase(),"pacman sprite2.png");
        pictureArray[5]=getImage( this.getCodeBase(),"pacman sprite4.png");
        pictureArray[6]=getImage( this.getCodeBase(),"pacman sprite6.png");
        pictureArray[7]=getImage( this.getCodeBase(),"pacman sprite7.png");
        pictureArray[8]=getImage( this.getCodeBase(),"pacman sprite8.png");
        pictureArray[9]=getImage( this.getCodeBase(),"pacman sprite9.png");
        pictureArray[10]=getImage( this.getCodeBase(),"pacman sprite10.png");
        pictureArray[11]=getImage( this.getCodeBase(),"pacman sprite11.png");
        pictureArray[12]=getImage( this.getCodeBase(),"pacman sprite12.png");
        pictureArray[13]=getImage( this.getCodeBase(),"pacman sprite13.png");
        pictureArray[14]=getImage( this.getCodeBase(),"pacman sprite14.png");
        pictureArray[15]=getImage( this.getCodeBase(),"pacman sprite15.png");
        pictureArray[16]=getImage( this.getCodeBase(),"pacman sprite16.png");

        redArray[0]=getImage(this.getCodeBase(),"red sprite1.png");
        redArray[1]=getImage(this.getCodeBase(),"red sprite2.png");
        redArray[2]=getImage(this.getCodeBase(),"red sprite3.png");
        redArray[3]=getImage(this.getCodeBase(),"red sprite4.png");
        redArray[4]=getImage(this.getCodeBase(),"red sprite5.png");
        redArray[5]=getImage(this.getCodeBase(),"red sprite6.png");
        redArray[6]=getImage(this.getCodeBase(),"red sprite7.png");
        redArray[7]=getImage(this.getCodeBase(),"red sprite8.png");
        redArray[8]=getImage(this.getCodeBase(),"ghost sprite1.png");
        redArray[9]=getImage(this.getCodeBase(),"ghost sprite2.png");
        redArray[10]=getImage(this.getCodeBase(),"eye sprite1.png");
        redArray[11]=getImage(this.getCodeBase(),"eye sprite2.png");
        redArray[12]=getImage(this.getCodeBase(),"eye sprite3.png");
        redArray[13]=getImage(this.getCodeBase(),"eye sprite4.png");
        redArray[14]=getImage(this.getCodeBase(),"eye sprite5.png");
        redArray[15]=getImage(this.getCodeBase(),"eye sprite6.png");
        redArray[16]=getImage(this.getCodeBase(),"eye sprite7.png");
        redArray[17]=getImage(this.getCodeBase(),"eye sprite8.png");

        pinkArray[0]=getImage(this.getCodeBase(),"pink sprite1.png");
        pinkArray[1]=getImage(this.getCodeBase(),"pink sprite2.png");
        pinkArray[2]=getImage(this.getCodeBase(),"pink sprite3.png");
        pinkArray[3]=getImage(this.getCodeBase(),"pink sprite4.png");
        pinkArray[4]=getImage(this.getCodeBase(),"pink sprite5.png");
        pinkArray[5]=getImage(this.getCodeBase(),"pink sprite6.png");
        pinkArray[6]=getImage(this.getCodeBase(),"pink sprite7.png");
        pinkArray[7]=getImage(this.getCodeBase(),"pink sprite8.png");
        pinkArray[8]=getImage(this.getCodeBase(),"ghost sprite1.png");
        pinkArray[9]=getImage(this.getCodeBase(),"ghost sprite2.png");
        pinkArray[10]=getImage(this.getCodeBase(),"eye sprite1.png");
        pinkArray[11]=getImage(this.getCodeBase(),"eye sprite2.png");
        pinkArray[12]=getImage(this.getCodeBase(),"eye sprite3.png");
        pinkArray[13]=getImage(this.getCodeBase(),"eye sprite4.png");
        pinkArray[14]=getImage(this.getCodeBase(),"eye sprite5.png");
        pinkArray[15]=getImage(this.getCodeBase(),"eye sprite6.png");
        pinkArray[16]=getImage(this.getCodeBase(),"eye sprite7.png");
        pinkArray[17]=getImage(this.getCodeBase(),"eye sprite8.png");

        blueArray[0]=getImage(this.getCodeBase(),"blue sprite1.png");
        blueArray[1]=getImage(this.getCodeBase(),"blue sprite2.png");
        blueArray[2]=getImage(this.getCodeBase(),"blue sprite3.png");
        blueArray[3]=getImage(this.getCodeBase(),"blue sprite4.png");
        blueArray[4]=getImage(this.getCodeBase(),"blue sprite5.png");
        blueArray[5]=getImage(this.getCodeBase(),"blue sprite6.png");
        blueArray[6]=getImage(this.getCodeBase(),"blue sprite7.png");
        blueArray[7]=getImage(this.getCodeBase(),"blue sprite8.png");
        blueArray[8]=getImage(this.getCodeBase(),"ghost sprite1.png");
        blueArray[9]=getImage(this.getCodeBase(),"ghost sprite2.png");
        blueArray[10]=getImage(this.getCodeBase(),"eye sprite1.png");
        blueArray[11]=getImage(this.getCodeBase(),"eye sprite2.png");
        blueArray[12]=getImage(this.getCodeBase(),"eye sprite3.png");
        blueArray[13]=getImage(this.getCodeBase(),"eye sprite4.png");
        blueArray[14]=getImage(this.getCodeBase(),"eye sprite5.png");
        blueArray[15]=getImage(this.getCodeBase(),"eye sprite6.png");
        blueArray[16]=getImage(this.getCodeBase(),"eye sprite7.png");
        blueArray[17]=getImage(this.getCodeBase(),"eye sprite8.png");

        orangeArray[0]=getImage(this.getCodeBase(),"orange sprite1.png");
        orangeArray[1]=getImage(this.getCodeBase(),"orange sprite2.png");
        orangeArray[2]=getImage(this.getCodeBase(),"orange sprite3.png");
        orangeArray[3]=getImage(this.getCodeBase(),"orange sprite4.png");
        orangeArray[4]=getImage(this.getCodeBase(),"orange sprite5.png");
        orangeArray[5]=getImage(this.getCodeBase(),"orange sprite6.png");
        orangeArray[6]=getImage(this.getCodeBase(),"orange sprite7.png");
        orangeArray[7]=getImage(this.getCodeBase(),"orange sprite8.png");
        orangeArray[8]=getImage(this.getCodeBase(),"ghost sprite1.png");
        orangeArray[9]=getImage(this.getCodeBase(),"ghost sprite2.png");
        orangeArray[10]=getImage(this.getCodeBase(),"eye sprite1.png");
        orangeArray[11]=getImage(this.getCodeBase(),"eye sprite2.png");
        orangeArray[12]=getImage(this.getCodeBase(),"eye sprite3.png");
        orangeArray[13]=getImage(this.getCodeBase(),"eye sprite4.png");
        orangeArray[14]=getImage(this.getCodeBase(),"eye sprite5.png");
        orangeArray[15]=getImage(this.getCodeBase(),"eye sprite6.png");
        orangeArray[16]=getImage(this.getCodeBase(),"eye sprite7.png");
        orangeArray[17]=getImage(this.getCodeBase(),"eye sprite8.png");

        maze=this.getImage( this.getCodeBase(),"pacman maze1.jpg");
        life=this.getImage( this.getCodeBase(),"pacman sprite1.png");
        rocoto=this.getImage( this.getCodeBase(),"rocoto.jpg");
    }

    public void run()
    {
        while(pageCt<3)
        {
            loopCt++;
            Rectangle pacmanRect= new Rectangle(pacmanX,pacmanY,28,28);
            Rectangle circleRect= new Rectangle(pac1X,pac1Y,20,20);
            Rectangle circle2Rect= new Rectangle(pac2X,pac2Y,20,20);
            Rectangle circle3Rect= new Rectangle(pac3X,pac3Y,20,20);
            Rectangle circle4Rect= new Rectangle(pac4X,pac4Y,20,20);
            Rectangle redRect= new Rectangle(redX,redY,28,28);
            Rectangle pinkRect= new Rectangle(pinkX,pinkY,28,28);
            Rectangle blueRect= new Rectangle(blueX,blueY,28,28);
            Rectangle orangeRect= new Rectangle(orangeX,orangeY,28,28);
            Rectangle rocotoRect= new Rectangle(rX,rY,35,35);
            Rectangle pRect= new Rectangle(pX,pY,10,10);
            Rectangle p2Rect= new Rectangle(p2X,pY,10,10);
            Rectangle p3Rect= new Rectangle(p3X,pY,10,10);
            Rectangle p4Rect= new Rectangle(p4X,pY,10,10);
            Rectangle p5Rect= new Rectangle(p5X,pY,10,10);
            Rectangle p6Rect= new Rectangle(p6X,pY,10,10);
            Rectangle p7Rect= new Rectangle(p7X,pY,10,10);
            Rectangle p8Rect= new Rectangle(p8X,pY,10,10);
            Rectangle p9Rect= new Rectangle(p10X,pY,10,10);
            Rectangle p10Rect= new Rectangle(p11X,pY,10,10);
            Rectangle p11Rect= new Rectangle(p12X,pY,10,10);
            Rectangle p12Rect= new Rectangle(p13X,pY,10,10);
            Rectangle p13Rect= new Rectangle(p14X,pY,10,10);
            Rectangle p14Rect= new Rectangle(p15X,pY,10,10);
            Rectangle p15Rect= new Rectangle(p16X,pY,10,10);
            Rectangle p16Rect= new Rectangle(p17X,pY,10,10);
            Rectangle p17Rect= new Rectangle(p4X,p2Y,10,10);
            Rectangle p18Rect= new Rectangle(p8X,p2Y,10,10);
            Rectangle p19Rect= new Rectangle(p10X,p2Y,10,10);
            Rectangle p20Rect= new Rectangle(p14X,p2Y,10,10);
            Rectangle p21Rect= new Rectangle(p4X,p3Y,10,10);
            Rectangle p22Rect= new Rectangle(p5X,p3Y,10,10);
            Rectangle p23Rect= new Rectangle(p6X,p3Y,10,10);
            Rectangle p24Rect= new Rectangle(p7X,p3Y,10,10);
            Rectangle p25Rect= new Rectangle(p8X,p3Y,10,10);
            Rectangle p26Rect= new Rectangle(p9X,p3Y,10,10);
            Rectangle p27Rect= new Rectangle(p10X,p3Y,10,10);
            Rectangle p28Rect= new Rectangle(p11X,p3Y,10,10);
            Rectangle p29Rect= new Rectangle(p12X,p3Y,10,10);
            Rectangle p30Rect= new Rectangle(p13X,p3Y,10,10);
            Rectangle p31Rect= new Rectangle(p14X,p3Y,10,10);
            Rectangle p32Rect= new Rectangle(p4X,p4Y,10,10);
            Rectangle p33Rect= new Rectangle(p6X,p4Y,10,10);
            Rectangle p34Rect= new Rectangle(p12X,p4Y,10,10);
            Rectangle p35Rect= new Rectangle(p14X,p4Y,10,10);
            Rectangle p36Rect= new Rectangle(pX,p5Y,10,10);
            Rectangle p37Rect= new Rectangle(p2X,p5Y,10,10);
            Rectangle p38Rect= new Rectangle(p3X,p5Y,10,10);
            Rectangle p39Rect= new Rectangle(p4X,p5Y,10,10);
            Rectangle p40Rect= new Rectangle(p6X,p5Y,10,10);
            Rectangle p41Rect= new Rectangle(p7X,p5Y,10,10);
            Rectangle p42Rect= new Rectangle(p8X,p5Y,10,10);
            Rectangle p43Rect= new Rectangle(p10X,p5Y,10,10);
            Rectangle p44Rect= new Rectangle(p11X,p5Y,10,10);
            Rectangle p45Rect= new Rectangle(p12X,p5Y,10,10);
            Rectangle p46Rect= new Rectangle(p14X,p5Y,10,10);
            Rectangle p47Rect= new Rectangle(p15X,p5Y,10,10);
            Rectangle p48Rect= new Rectangle(p16X,p5Y,10,10);
            Rectangle p49Rect= new Rectangle(p17X,p5Y,10,10);
            Rectangle p50Rect= new Rectangle(pX,p6Y,10,10);
            Rectangle p51Rect= new Rectangle(p8X,p6Y,10,10);
            Rectangle p52Rect= new Rectangle(p10X,p6Y,10,10);
            Rectangle p53Rect= new Rectangle(p17X,p6Y,10,10);
            Rectangle p54Rect= new Rectangle(pX,p7Y,10,10);
            Rectangle p55Rect= new Rectangle(p2X,p7Y,10,10);
            Rectangle p56Rect= new Rectangle(p3X,p7Y,10,10);
            Rectangle p57Rect= new Rectangle(p4X,p7Y,10,10);
            Rectangle p58Rect= new Rectangle(p5X,p7Y,10,10);
            Rectangle p59Rect= new Rectangle(p6X,p7Y,10,10);
            Rectangle p60Rect= new Rectangle(p7X,p7Y,10,10);
            Rectangle p61Rect= new Rectangle(p8X,p7Y,10,10);
            Rectangle p62Rect= new Rectangle(p9X,p7Y,10,10);
            Rectangle p63Rect= new Rectangle(p10X,p7Y,10,10);
            Rectangle p64Rect= new Rectangle(p11X,p7Y,10,10);
            Rectangle p65Rect= new Rectangle(p12X,p7Y,10,10);
            Rectangle p66Rect= new Rectangle(p13X,p7Y,10,10);
            Rectangle p67Rect= new Rectangle(p14X,p7Y,10,10);
            Rectangle p68Rect= new Rectangle(p15X,p7Y,10,10);
            Rectangle p69Rect= new Rectangle(p16X,p7Y,10,10);
            Rectangle p70Rect= new Rectangle(p17X,p7Y,10,10);

            Rectangle p71Rect= new Rectangle(p4X,p8Y,10,10);
            Rectangle p72Rect= new Rectangle(p14X,p8Y,10,10);
            Rectangle p73Rect= new Rectangle(p4X,p9Y,10,10);
            Rectangle p74Rect= new Rectangle(p14X,p9Y,10,10);
            Rectangle p75Rect= new Rectangle(p4X,p10Y,10,10);
            Rectangle p76Rect= new Rectangle(p14X,p10Y,10,10);
            Rectangle p77Rect= new Rectangle(p4X,p11Y,10,10);
            Rectangle p78Rect= new Rectangle(p14X,p11Y,10,10);
            Rectangle p79Rect= new Rectangle(p4X,p12Y,10,10);
            Rectangle p80Rect= new Rectangle(p14X,p12Y,10,10);
            Rectangle p81Rect= new Rectangle(p4X,p13Y,10,10);
            Rectangle p83Rect= new Rectangle(p14X,p13Y,10,10);
            Rectangle p84Rect= new Rectangle(p4X,p14Y,10,10);
            Rectangle p86Rect= new Rectangle(p14X,p14Y,10,10);
            Rectangle p87Rect= new Rectangle(p4X,p15Y,10,10);
            Rectangle p88Rect= new Rectangle(p14X,p15Y,10,10);
            Rectangle p89Rect= new Rectangle(p4X,p16Y,10,10);
            Rectangle p90Rect= new Rectangle(p14X,p16Y,10,10);
            Rectangle p91Rect= new Rectangle(p4X,p17Y,10,10);
            Rectangle p92Rect= new Rectangle(p14X,p17Y,10,10);
            Rectangle p93Rect= new Rectangle(p4X,p18Y,10,10);
            Rectangle p94Rect= new Rectangle(p14X,p18Y,10,10);
            Rectangle p95Rect= new Rectangle(pX,p19Y,10,10);
            Rectangle p96Rect= new Rectangle(p2X,p19Y,10,10);
            Rectangle p97Rect= new Rectangle(p3X,p19Y,10,10);
            Rectangle p98Rect= new Rectangle(p4X,p19Y,10,10);
            Rectangle p99Rect= new Rectangle(p5X,p19Y,10,10);
            Rectangle p100Rect= new Rectangle(p6X,p19Y,10,10);
            Rectangle p101Rect= new Rectangle(p7X,p19Y,10,10);
            Rectangle p102Rect= new Rectangle(p8X,p19Y,10,10);
            Rectangle p103Rect= new Rectangle(p10X,p19Y,10,10);
            Rectangle p104Rect= new Rectangle(p11X,p19Y,10,10);
            Rectangle p105Rect= new Rectangle(p12X,p19Y,10,10);
            Rectangle p106Rect= new Rectangle(p13X,p19Y,10,10);
            Rectangle p107Rect= new Rectangle(p14X,p19Y,10,10);
            Rectangle p108Rect= new Rectangle(p15X,p19Y,10,10);
            Rectangle p109Rect= new Rectangle(p16X,p19Y,10,10);
            Rectangle p110Rect= new Rectangle(p17X,p19Y,10,10);
            Rectangle p111Rect= new Rectangle(pX,p17Y,10,10);
            Rectangle p112Rect= new Rectangle(p2X,p17Y,10,10);
            Rectangle p113Rect= new Rectangle(p3X,p17Y,10,10);
            Rectangle p114Rect= new Rectangle(p5X,p17Y,10,10);
            Rectangle p115Rect= new Rectangle(p6X,p17Y,10,10);
            Rectangle p116Rect= new Rectangle(p7X,p17Y,10,10);
            Rectangle p117Rect= new Rectangle(p8X,p17Y,10,10);
            Rectangle p118Rect= new Rectangle(p9X,p17Y,10,10);
            Rectangle p119Rect= new Rectangle(p10X,p17Y,10,10);
            Rectangle p120Rect= new Rectangle(p11X,p17Y,10,10);
            Rectangle p121Rect= new Rectangle(p12X,p17Y,10,10);
            Rectangle p122Rect= new Rectangle(p13X,p17Y,10,10);
            Rectangle p123Rect= new Rectangle(p15X,p17Y,10,10);
            Rectangle p124Rect= new Rectangle(p16X,p17Y,10,10);
            Rectangle p125Rect= new Rectangle(p17X,p17Y,10,10);
            Rectangle p126Rect= new Rectangle(p6X,p16Y,10,10);
            Rectangle p127Rect= new Rectangle(p12X,p16Y,10,10);
            Rectangle p128Rect= new Rectangle(p6X,p15Y,10,10);
            Rectangle p129Rect= new Rectangle(p7X,p15Y,10,10);
            Rectangle p130Rect= new Rectangle(p8X,p15Y,10,10);
            Rectangle p131Rect= new Rectangle(p10X,p15Y,10,10);
            Rectangle p132Rect= new Rectangle(p11X,p15Y,10,10);
            Rectangle p133Rect= new Rectangle(p12X,p15Y,10,10);
            Rectangle p134Rect= new Rectangle(p8X,p14Y,10,10);
            Rectangle p135Rect= new Rectangle(p10X,p14Y,10,10);
            Rectangle p136Rect= new Rectangle(pX,p16Y,10,10);
            Rectangle p137Rect= new Rectangle(p17X,p16Y,10,10);
            Rectangle p138Rect= new Rectangle(pX,p15Y,10,10);
            Rectangle p139Rect= new Rectangle(p2X,p15Y,10,10);
            Rectangle p140Rect= new Rectangle(p3X,p15Y,10,10);
            Rectangle p141Rect= new Rectangle(p15X,p15Y,10,10);
            Rectangle p142Rect= new Rectangle(p16X,p15Y,10,10);
            Rectangle p143Rect= new Rectangle(p17X,p15Y,10,10);
            Rectangle p144Rect= new Rectangle(p8X,p18Y,10,10);
            Rectangle p145Rect= new Rectangle(p10X,p18Y,10,10);

            TopColor=new Color(buffer.getRGB(pacmanX+12,pacmanY-1));
            if(!TopColor.equals(Color.black)&&up)
            {
                stand=true;
                right=false;
                left=false;
                up=false;
                down=false;
            }
            rightColor=new Color(buffer.getRGB(pacmanX+29,pacmanY+12));
            if(!rightColor.equals(Color.black)&&right)
            {
                stand=true;
                right=false;
                left=false;
                up=false;
                down=false;
            }
            BottomColor=new Color(buffer.getRGB(pacmanX+12,pacmanY+29));
            if(!BottomColor.equals(Color.black)&&(down))
            {
                stand=true;
                right=false;
                left=false;
                up=false;
                down=false;
            }
            leftColor=new Color(buffer.getRGB(pacmanX-2,pacmanY+12));
            if(!leftColor.equals(Color.black)&&(left))
            {
                stand=true;
                right=false;
                left=false;
                up=false;
                down=false;
            }
            if(numLife==-1)
                pageCt=3;
            if(right)
                pacmanX=pacmanX+10;
            if(left)
                pacmanX=pacmanX-10;
            if(up)
                pacmanY=pacmanY-10;
            if(down)
                pacmanY=pacmanY+10;

            redX=redX+10;
            pinkX=pinkX+10;
            blueX=blueX+10;
            orangeX=orangeX+10;

            repaint();
            try
            {main.sleep(100);}
            catch(Exception e){}
            frameCt++;
            if(frameCt==2)
                frameCt=0;

            frame2Ct++;
            if(frame2Ct==5)
                frame2Ct=3;

            deadFrameCt++;    
            if(deadFrameCt==17)
                deadFrameCt=6;

            redframeCt++;
            if(redframeCt==8)
                redframeCt=0;

            pinkframeCt++;
            if(pinkframeCt==8)
                pinkframeCt=0;

            blueframeCt++;
            if(blueframeCt==8)
                blueframeCt=0;

            orangeframeCt++;
            if(orangeframeCt==8)
                orangeframeCt=0;

            if(pacmanX<300)
                pacmanX=880;

            if(pacmanX>880)
                pacmanX=300;

            if(redX<300)
                redX=880;

            if(redX>880)
                redX=300;

            if(pinkX<300)
                pinkX=880;

            if(pinkX>880)
                pinkX=300;

            if(blueX<300)
                blueX=880;

            if(blueX>860)
                blueX=300;

            if(orangeX<300)
                orangeX=880;

            if(orangeX>880)
                orangeX=300;

            if(pacmanRect.intersects(pRect))
            {
                if(p1)
                    scoreCt=scoreCt+10;
                if(pX==345&&pY==455)
                {
                    p1=false;
                }
            }
            if(pacmanRect.intersects(p2Rect))
            {
                if(p2)
                    scoreCt=scoreCt+10;
                if(p2X==380&&pY==455)
                {
                    p2=false;
                }
            }
            if(pacmanRect.intersects(p3Rect))
            {
                if(p3)
                    scoreCt=scoreCt+10;
                if(p3X==410&&pY==455)
                {
                    p3=false;
                }
            }
            if(pacmanRect.intersects(p4Rect))
            {
                if(p4)
                    scoreCt=scoreCt+10;
                if(p4X==440&&pY==455)
                {
                    p4=false;
                }
            }
            if(pacmanRect.intersects(p5Rect))
            {
                if(p5)
                    scoreCt=scoreCt+10;
                if(p5X==470&&pY==455)
                {
                    p5=false;
                }
            }
            if(pacmanRect.intersects(p6Rect))
            {
                if(p6)
                    scoreCt=scoreCt+10;
                if(p6X==500&&pY==455)
                {
                    p6=false;
                }
            }
            if(pacmanRect.intersects(p7Rect))
            {
                if(p7)
                    scoreCt=scoreCt+10;
                if(p7X==530&&pY==455)
                {
                    p7=false;
                }
            }
            if(pacmanRect.intersects(p8Rect))
            {
                if(p8)
                    scoreCt=scoreCt+10;
                if(p8X==560&&pY==455)
                {
                    p8=false;
                }
            }
            if(pacmanRect.intersects(p9Rect))
            {
                if(p9)
                    scoreCt=scoreCt+10;
                if(p10X==630&&pY==455)
                {
                    p9=false;
                }
            }
            if(pacmanRect.intersects(p10Rect))
            {
                if(p10)
                    scoreCt=scoreCt+10;
                if(p11X==660&&pY==455)
                {
                    p10=false;
                }
            }
            if(pacmanRect.intersects(p11Rect))
            {
                if(p11)
                    scoreCt=scoreCt+10;
                if(p12X==690&&pY==455)
                {
                    p11=false;
                }
            }
            if(pacmanRect.intersects(p12Rect))
            {
                if(p12)
                    scoreCt=scoreCt+10;
                if(p13X==720&&pY==455)
                {
                    p12=false;
                }
            }
            if(pacmanRect.intersects(p13Rect))
            {
                if(p13)
                    scoreCt=scoreCt+10;
                if(p14X==750&&pY==455)
                {
                    p13=false;
                }
            }
            if(pacmanRect.intersects(p14Rect))
            {
                if(p14)
                    scoreCt=scoreCt+10;
                if(p15X==780&&pY==455)
                {
                    p14=false;
                }
            }
            if(pacmanRect.intersects(p15Rect))
            {
                if(p15)
                    scoreCt=scoreCt+10;
                if(p16X==810&&pY==455)
                {
                    p15=false;
                }
            }
            if(pacmanRect.intersects(p16Rect))
            {
                if(p16)
                    scoreCt=scoreCt+10;
                if(p17X==845&&pY==455)
                {
                    p16=false;
                }
            }
            if(pacmanRect.intersects(p17Rect))
            {
                if(p17)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p2Y==485)
                {
                    p17=false;
                }
            }
            if(pacmanRect.intersects(p18Rect))
            {
                if(p18)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p2Y==485)
                {
                    p18=false;
                }
            }
            if(pacmanRect.intersects(p19Rect))
            {
                if(p19)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p2Y==485)
                {
                    p19=false;
                }
            }
            if(pacmanRect.intersects(p20Rect))
            {
                if(p20)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p2Y==485)
                {
                    p20=false;
                }
            }
            if(pacmanRect.intersects(p21Rect))
            {
                if(p21)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p3Y==515)
                {
                    p21=false;
                }
            }
            if(pacmanRect.intersects(p22Rect))
            {
                if(p22)
                    scoreCt=scoreCt+10;
                if(p5X==470&&p3Y==515)
                {
                    p22=false;
                }
            }
            if(pacmanRect.intersects(p23Rect))
            {
                if(p23)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p3Y==515)
                {
                    p23=false;
                }
            }
            if(pacmanRect.intersects(p24Rect))
            {
                if(p24)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p3Y==515)
                {
                    p24=false;
                }
            }
            if(pacmanRect.intersects(p25Rect))
            {
                if(p25)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p3Y==515)
                {
                    p25=false;
                }
            }
            if(pacmanRect.intersects(p26Rect))
            {
                if(p26)
                    scoreCt=scoreCt+10;
                if(p9X==595&&p3Y==515)
                {
                    p26=false;
                }
            }
            if(pacmanRect.intersects(p27Rect))
            {
                if(p27)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p3Y==515)
                {
                    p27=false;
                }
            }
            if(pacmanRect.intersects(p28Rect))
            {
                if(p28)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p3Y==515)
                {
                    p28=false;
                }
            }
            if(pacmanRect.intersects(p29Rect))
            {
                if(p29)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p3Y==515)
                {
                    p29=false;
                }
            }
            if(pacmanRect.intersects(p30Rect))
            {
                if(p30)
                    scoreCt=scoreCt+10;
                if(p13X==720&&p3Y==515)
                {
                    p30=false;
                }
            }
            if(pacmanRect.intersects(p31Rect))
            {
                if(p31)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p3Y==515)
                {
                    p31=false;
                }
            }
            if(pacmanRect.intersects(p32Rect))
            {
                if(p32)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p4Y==545)
                {
                    p32=false;
                }
            }
            if(pacmanRect.intersects(p33Rect))
            {
                if(p33)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p4Y==545)
                {
                    p33=false;
                }
            }
            if(pacmanRect.intersects(p34Rect))
            {
                if(p34)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p4Y==545)
                {
                    p34=false;
                }
            }
            if(pacmanRect.intersects(p35Rect))
            {
                if(p35)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p4Y==545)
                {
                    p35=false;
                }
            }
            if(pacmanRect.intersects(p36Rect))
            {
                if(p36)
                    scoreCt=scoreCt+10;
                if(pX==345&&p5Y==580)
                {
                    p36=false;
                }
            }
            if(pacmanRect.intersects(p37Rect))
            {
                if(p37)
                    scoreCt=scoreCt+10;
                if(p2X==380&&p5Y==580)
                {
                    p37=false;
                }
            }
            if(pacmanRect.intersects(p38Rect))
            {
                if(p38)
                    scoreCt=scoreCt+10;
                if(p3X==410&&p5Y==580)
                {
                    p38=false;
                }
            }
            if(pacmanRect.intersects(p39Rect))
            {
                if(p39)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p5Y==580)
                {
                    p39=false;
                }
            }
            if(pacmanRect.intersects(p40Rect))
            {
                if(p40)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p5Y==580)
                {
                    p40=false;
                }
            }
            if(pacmanRect.intersects(p41Rect))
            {
                if(p41)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p5Y==580)
                {
                    p41=false;
                }
            }
            if(pacmanRect.intersects(p42Rect))
            {
                if(p42)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p5Y==580)
                {
                    p42=false;
                }
            }
            if(pacmanRect.intersects(p43Rect))
            {
                if(p43)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p5Y==580)
                {
                    p43=false;
                }
            }
            if(pacmanRect.intersects(p44Rect))
            {
                if(p44)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p5Y==580)
                {
                    p44=false;
                }
            }
            if(pacmanRect.intersects(p45Rect))
            {
                if(p45)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p5Y==580)
                {
                    p45=false;
                }
            }
            if(pacmanRect.intersects(p46Rect))
            {
                if(p46)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p5Y==580)
                {
                    p46=false;
                }
            }
            if(pacmanRect.intersects(p47Rect))
            {
                if(p47)
                    scoreCt=scoreCt+10;
                if(p15X==780&&p5Y==580)
                {
                    p47=false;
                }
            }
            if(pacmanRect.intersects(p48Rect))
            {
                if(p48)
                    scoreCt=scoreCt+10;
                if(p16X==810&&p5Y==580)
                {
                    p48=false;
                }
            }
            if(pacmanRect.intersects(p49Rect))
            {
                if(p49)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p5Y==580)
                {
                    p49=false;
                }
            }
            if(pacmanRect.intersects(p50Rect))
            {
                if(p50)
                    scoreCt=scoreCt+10;
                if(pX==345&&p6Y==615)
                {
                    p50=false;
                }
            }
            if(pacmanRect.intersects(p51Rect))
            {
                if(p51)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p6Y==615)
                {
                    p51=false;
                }
            }
            if(pacmanRect.intersects(p52Rect))
            {
                if(p52)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p6Y==615)
                {
                    p52=false;
                }
            }
            if(pacmanRect.intersects(p53Rect))
            {
                if(p53)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p6Y==615)
                {
                    p53=false;
                }
            }
            if(pacmanRect.intersects(p54Rect))
            {
                if(p54)
                    scoreCt=scoreCt+10;
                if(pX==345&&p7Y==655)
                {
                    p54=false;
                }
            }
            if(pacmanRect.intersects(p55Rect))
            {
                if(p55)
                    scoreCt=scoreCt+10;
                if(p2X==380&&p7Y==655)
                {
                    p55=false;
                }
            }
            if(pacmanRect.intersects(p56Rect))
            {
                if(p56)
                    scoreCt=scoreCt+10;
                if(p3X==410&&p7Y==655)
                {
                    p56=false;
                }
            }
            if(pacmanRect.intersects(p57Rect))
            {
                if(p57)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p7Y==655)
                {
                    p57=false;
                }
            }
            if(pacmanRect.intersects(p58Rect))
            {
                if(p58)
                    scoreCt=scoreCt+10;
                if(p5X==470&&p7Y==655)
                {
                    p58=false;
                }
            }
            if(pacmanRect.intersects(p59Rect))
            {
                if(p59)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p7Y==655)
                {
                    p59=false;
                }
            }
            if(pacmanRect.intersects(p60Rect))
            {
                if(p60)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p7Y==655)
                {
                    p60=false;
                }
            }
            if(pacmanRect.intersects(p61Rect))
            {
                if(p61)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p7Y==655)
                {
                    p61=false;
                }
            }
            if(pacmanRect.intersects(p62Rect))
            {
                if(p62)
                    scoreCt=scoreCt+10;
                if(p9X==595&&p7Y==655)
                {
                    p62=false;
                }
            }
            if(pacmanRect.intersects(p63Rect))
            {
                if(p63)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p7Y==655)
                {
                    p63=false;
                }
            }
            if(pacmanRect.intersects(p64Rect))
            {
                if(p64)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p7Y==655)
                {
                    p64=false;
                }
            }
            if(pacmanRect.intersects(p65Rect))
            {
                if(p65)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p7Y==655)
                {
                    p65=false;
                }
            }
            if(pacmanRect.intersects(p66Rect))
            {
                if(p66)
                    scoreCt=scoreCt+10;
                if(p13X==720&&p7Y==655)
                {
                    p66=false;
                }
            }
            if(pacmanRect.intersects(p67Rect))
            {
                if(p67)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p7Y==655)
                {
                    p67=false;
                }
            }
            if(pacmanRect.intersects(p68Rect))
            {
                if(p68)
                    scoreCt=scoreCt+10;
                if(p15X==780&&p7Y==655)
                {
                    p68=false;
                }
            }
            if(pacmanRect.intersects(p69Rect))
            {
                if(p69)
                    scoreCt=scoreCt+10;
                if(p16X==810&&p7Y==655)
                {
                    p69=false;
                }
            }
            if(pacmanRect.intersects(p70Rect))
            {
                if(p70)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p7Y==655)
                {
                    p70=false;
                }
            }
            if(pacmanRect.intersects(p71Rect))
            {
                if(p71)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p8Y==425)
                {
                    p71=false;
                }
            }
            if(pacmanRect.intersects(p72Rect))
            {
                if(p72)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p8Y==425)
                {
                    p72=false;
                }
            }
            if(pacmanRect.intersects(p73Rect))
            {
                if(p73)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p9Y==395)
                {
                    p73=false;
                }
            }
            if(pacmanRect.intersects(p74Rect))
            {
                if(p74)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p9Y==395)
                {
                    p74=false;
                }
            }
            if(pacmanRect.intersects(p75Rect))
            {
                if(p75)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p10Y==365)
                {
                    p75=false;
                }
            }
            if(pacmanRect.intersects(p76Rect))
            {
                if(p76)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p10Y==365)
                {
                    p76=false;
                }
            }
            if(pacmanRect.intersects(p77Rect))
            {
                if(p77)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p11Y==325)
                {
                    p77=false;
                }
            }
            if(pacmanRect.intersects(p78Rect))
            {
                if(p78)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p11Y==325)
                {
                    p78=false;
                }
            }
            if(pacmanRect.intersects(p79Rect))
            {
                if(p79)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p12Y==295)
                {
                    p79=false;
                }
            }
            if(pacmanRect.intersects(p80Rect))
            {
                if(p80)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p12Y==295)
                {
                    p80=false;
                }
            }
            if(pacmanRect.intersects(p81Rect))
            {
                if(p81)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p13Y==265)
                {
                    p81=false;
                }
            }
            if(pacmanRect.intersects(p83Rect))
            {
                if(p83)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p13Y==265)
                {
                    p83=false;
                }
            }
            if(pacmanRect.intersects(p84Rect))
            {
                if(p84)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p14Y==235)
                {
                    p84=false;
                }
            }
            if(pacmanRect.intersects(p86Rect))
            {
                if(p86)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p14Y==235)
                {
                    p86=false;
                }
            }
            if(pacmanRect.intersects(p87Rect))
            {
                if(p87)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p15Y==195)
                {
                    p87=false;
                }
            }
            if(pacmanRect.intersects(p88Rect))
            {
                if(p88)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p15Y==195)
                {
                    p88=false;
                }
            }
            if(pacmanRect.intersects(p89Rect))
            {
                if(p89)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p16Y==160)
                {
                    p89=false;
                }
            }
            if(pacmanRect.intersects(p90Rect))
            {
                if(p90)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p16Y==160)
                {
                    p90=false;
                }
            }
            if(pacmanRect.intersects(p91Rect))
            {
                if(p91)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p17Y==125)
                {
                    p91=false;
                }
            }
            if(pacmanRect.intersects(p92Rect))
            {
                if(p92)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p17Y==125)
                {
                    p92=false;
                }
            }
            if(pacmanRect.intersects(p93Rect))
            {
                if(p93)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p18Y==85)
                {
                    p93=false;
                }
            }
            if(pacmanRect.intersects(p94Rect))
            {
                if(p94)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p18Y==85)
                {
                    p94=false;
                }
            }
            if(pacmanRect.intersects(p95Rect))
            {
                if(p95)
                    scoreCt=scoreCt+10;
                if(pX==345&&p19Y==45)
                {
                    p95=false;
                }
            }
            if(pacmanRect.intersects(p96Rect))
            {
                if(p96)
                    scoreCt=scoreCt+10;
                if(p2X==380&&p19Y==45)
                {
                    p96=false;
                }
            }
            if(pacmanRect.intersects(p97Rect))
            {
                if(p97)
                    scoreCt=scoreCt+10;
                if(p3X==410&&p19Y==45)
                {
                    p97=false;
                }
            }
            if(pacmanRect.intersects(p98Rect))
            {
                if(p98)
                    scoreCt=scoreCt+10;
                if(p4X==440&&p19Y==45)
                {
                    p98=false;
                }
            }
            if(pacmanRect.intersects(p99Rect))
            {
                if(p99)
                    scoreCt=scoreCt+10;
                if(p5X==470&&p19Y==45)
                {
                    p99=false;
                }
            }
            if(pacmanRect.intersects(p100Rect))
            {
                if(p100)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p19Y==45)
                {
                    p100=false;
                }
            }
            if(pacmanRect.intersects(p101Rect))
            {
                if(p101)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p19Y==45)
                {
                    p101=false;
                }
            }
            if(pacmanRect.intersects(p102Rect))
            {
                if(p102)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p19Y==45)
                {
                    p102=false;
                }
            }
            if(pacmanRect.intersects(p103Rect))
            {
                if(p103)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p19Y==45)
                {
                    p103=false;
                }
            }
            if(pacmanRect.intersects(p104Rect))
            {
                if(p104)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p19Y==45)
                {
                    p104=false;
                }
            }
            if(pacmanRect.intersects(p105Rect))
            {
                if(p105)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p19Y==45)
                {
                    p105=false;
                }
            }
            if(pacmanRect.intersects(p106Rect))
            {
                if(p106)
                    scoreCt=scoreCt+10;
                if(p13X==720&&p19Y==45)
                {
                    p106=false;
                }
            }
            if(pacmanRect.intersects(p107Rect))
            {
                if(p107)
                    scoreCt=scoreCt+10;
                if(p14X==750&&p19Y==45)
                {
                    p107=false;
                }
            }
            if(pacmanRect.intersects(p108Rect))
            {
                if(p108)
                    scoreCt=scoreCt+10;
                if(p15X==780&&p19Y==45)
                {
                    p108=false;
                }
            }
            if(pacmanRect.intersects(p109Rect))
            {
                if(p109)
                    scoreCt=scoreCt+10;
                if(p16X==810&&p19Y==45)
                {
                    p109=false;
                }
            }
            if(pacmanRect.intersects(p110Rect))
            {
                if(p110)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p19Y==45)
                {
                    p110=false;
                }
            }
            if(pacmanRect.intersects(p111Rect))
            {
                if(p111)
                    scoreCt=scoreCt+10;
                if(pX==345&&p17Y==125)
                {
                    p111=false;
                }
            }
            if(pacmanRect.intersects(p112Rect))
            {
                if(p112)
                    scoreCt=scoreCt+10;
                if(p2X==380&&p17Y==125)
                {
                    p112=false;
                }
            }
            if(pacmanRect.intersects(p113Rect))
            {
                if(p113)
                    scoreCt=scoreCt+10;
                if(p3X==410&&p17Y==125)
                {
                    p113=false;
                }
            }
            if(pacmanRect.intersects(p114Rect))
            {
                if(p114)
                    scoreCt=scoreCt+10;
                if(p5X==470&&p17Y==125)
                {
                    p114=false;
                }
            }
            if(pacmanRect.intersects(p115Rect))
            {
                if(p115)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p17Y==125)
                {
                    p115=false;
                }
            }
            if(pacmanRect.intersects(p116Rect))
            {
                if(p116)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p17Y==125)
                {
                    p116=false;
                }
            }
            if(pacmanRect.intersects(p117Rect))
            {
                if(p117)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p17Y==125)
                {
                    p117=false;
                }
            }
            if(pacmanRect.intersects(p118Rect))
            {
                if(p118)
                    scoreCt=scoreCt+10;
                if(p9X==595&&p17Y==125)
                {
                    p118=false;
                }
            }
            if(pacmanRect.intersects(p119Rect))
            {
                if(p119)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p17Y==125)
                {
                    p119=false;
                }
            }
            if(pacmanRect.intersects(p120Rect))
            {
                if(p120)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p17Y==125)
                {
                    p120=false;
                }
            }
            if(pacmanRect.intersects(p121Rect))
            {
                if(p121)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p17Y==125)
                {
                    p121=false;
                }
            }
            if(pacmanRect.intersects(p122Rect))
            {
                if(p122)
                    scoreCt=scoreCt+10;
                if(p13X==720&&p17Y==125)
                {
                    p122=false;
                }
            }
            if(pacmanRect.intersects(p123Rect))
            {
                if(p123)
                    scoreCt=scoreCt+10;
                if(p15X==780&&p17Y==125)
                {
                    p123=false;
                }
            }
            if(pacmanRect.intersects(p124Rect))
            {
                if(p124)
                    scoreCt=scoreCt+10;
                if(p16X==810&&p17Y==125)
                {
                    p124=false;
                }
            }
            if(pacmanRect.intersects(p125Rect))
            {
                if(p125)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p17Y==125)
                {
                    p125=false;
                }
            }
            if(pacmanRect.intersects(p126Rect))
            {
                if(p126)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p16Y==160)
                {
                    p126=false;
                }
            }
            if(pacmanRect.intersects(p127Rect))
            {
                if(p127)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p16Y==160)
                {
                    p127=false;
                }
            }
            if(pacmanRect.intersects(p128Rect))
            {
                if(p128)
                    scoreCt=scoreCt+10;
                if(p6X==500&&p15Y==195)
                {
                    p128=false;
                }
            }
            if(pacmanRect.intersects(p129Rect))
            {
                if(p129)
                    scoreCt=scoreCt+10;
                if(p7X==530&&p15Y==195)
                {
                    p129=false;
                }
            }
            if(pacmanRect.intersects(p130Rect))
            {
                if(p130)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p15Y==195)
                {
                    p130=false;
                }
            }
            if(pacmanRect.intersects(p131Rect))
            {
                if(p131)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p15Y==195)
                {
                    p131=false;
                }
            }
            if(pacmanRect.intersects(p132Rect))
            {
                if(p132)
                    scoreCt=scoreCt+10;
                if(p11X==660&&p15Y==195)
                {
                    p132=false;
                }
            }
            if(pacmanRect.intersects(p133Rect))
            {
                if(p133)
                    scoreCt=scoreCt+10;
                if(p12X==690&&p15Y==195)
                {
                    p133=false;
                }
            }
            if(pacmanRect.intersects(p134Rect))
            {
                if(p134)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p14Y==235)
                {
                    p134=false;
                }
            }
            if(pacmanRect.intersects(p135Rect))
            {
                if(p135)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p14Y==235)
                {
                    p135=false;
                }
            }
            if(pacmanRect.intersects(p136Rect))
            {
                if(p136)
                    scoreCt=scoreCt+10;
                if(pX==345&&p16Y==160)
                {
                    p136=false;
                }
            }
            if(pacmanRect.intersects(p137Rect))
            {
                if(p137)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p16Y==160)
                {
                    p137=false;
                }
            }
            if(pacmanRect.intersects(p138Rect))
            {
                if(p138)
                    scoreCt=scoreCt+10;
                if(pX==345&&p15Y==195)
                {
                    p138=false;
                }
            }
            if(pacmanRect.intersects(p139Rect))
            {
                if(p139)
                    scoreCt=scoreCt+10;
                if(p2X==380&&p15Y==195)
                {
                    p139=false;
                }
            }
            if(pacmanRect.intersects(p140Rect))
            {
                if(p140)
                    scoreCt=scoreCt+10;
                if(p3X==410&&p15Y==195)
                {
                    p140=false;
                }
            }
            if(pacmanRect.intersects(p141Rect))
            {
                if(p141)
                    scoreCt=scoreCt+10;
                if(p15X==780&&p15Y==195)
                {
                    p141=false;
                }
            }
            if(pacmanRect.intersects(p142Rect))
            {
                if(p142)
                    scoreCt=scoreCt+10;
                if(p16X==810&&p15Y==195)
                {
                    p142=false;
                }
            }
            if(pacmanRect.intersects(p143Rect))
            {
                if(p143)
                    scoreCt=scoreCt+10;
                if(p17X==845&&p15Y==195)
                {
                    p143=false;
                }
            }
            if(pacmanRect.intersects(p144Rect))
            {
                if(p144)
                    scoreCt=scoreCt+10;
                if(p8X==560&&p18Y==85)
                {
                    p144=false;
                }
            }if(pacmanRect.intersects(p145Rect))
            {
                if(p145)
                    scoreCt=scoreCt+10;
                if(p10X==630&&p18Y==85)
                {
                    p145=false;
                }
            }
            if(enemy)
            {
                if(redRect.intersects(pacmanRect))
                {
                    dead=true;
                    right=false;
                    stand=false;
                    left=false;
                    up=false;
                    down=false;
                    pageCt=3; 
                    redY=800;
                    pinkY=800;
                    blueY=800;
                    orangeY=800;
                }
                if(pinkRect.intersects(pacmanRect))
                {
                    dead=true;
                    right=false;
                    stand=false;
                    left=false;
                    up=false;
                    down=false;
                    pageCt=3;
                    redY=800;
                    pinkY=800;
                    blueY=800;
                    orangeY=800;
                }
                if(blueRect.intersects(pacmanRect))
                {
                    dead=true;
                    right=false;
                    stand=false;
                    left=false;
                    up=false;
                    down=false;
                    pageCt=3;
                    redY=800;
                    pinkY=800;
                    blueY=800;
                    orangeY=800;
                }
                if(orangeRect.intersects(pacmanRect))
                {
                    dead=true;
                    right=false;
                    stand=false;
                    left=false;
                    up=false;
                    down=false;
                    pageCt=3;
                    redY=800;
                    pinkY=800;
                    blueY=800;
                    orangeY=800;
                }
            }
            if(pacmanRect.intersects(circleRect))
            {
                pac1Y=800;
                scoreCt=scoreCt+100;
                ghost=true;
                enemy=false;
                redX=redX+5;
                pinkX=pinkX+5;
                blueX=blueX+5;
                orangeX=orangeX+5;
                redghostCt++;
                if(redghostCt==10)
                    redghostCt=8;
                pinkghostCt++;
                if(pinkghostCt==10)
                    pinkghostCt=8;
                blueghostCt++;
                if(blueghostCt==10)
                    blueghostCt=8;
                orangeghostCt++;
                if(orangeghostCt==10)
                    orangeghostCt=8;
            }
            if(pacmanRect.intersects(circle2Rect))
            {
                pac2Y=800;
                scoreCt=scoreCt+100;
                ghost=true;
                enemy=false;
                redX=redX+5;
                pinkX=pinkX+5;
                blueX=blueX+5;
                orangeX=orangeX+5;
                redghostCt++;
                if(redghostCt==10)
                    redghostCt=8;
                pinkghostCt++;
                if(pinkghostCt==10)
                    pinkghostCt=8;
                blueghostCt++;
                if(blueghostCt==10)
                    blueghostCt=8;
                orangeghostCt++;
                if(orangeghostCt==10)
                    orangeghostCt=8;
            }
            if(pacmanRect.intersects(circle3Rect))
            {
                pac3Y=800;
                scoreCt=scoreCt+100;
                ghost=true;
                enemy=false;
                redX=redX+5;
                pinkX=pinkX+5;
                blueX=blueX+5;
                orangeX=orangeX+5;
                redghostCt++;
                if(redghostCt==10)
                    redghostCt=8;
                pinkghostCt++;
                if(pinkghostCt==10)
                    pinkghostCt=8;
                blueghostCt++;
                if(blueghostCt==10)
                    blueghostCt=8;
                orangeghostCt++;
                if(orangeghostCt==10)
                    orangeghostCt=8;
            }
            if(pacmanRect.intersects(circle4Rect))
            {
                pac4Y=800;
                scoreCt=scoreCt+100;
                ghost=true;
                enemy=false;

                redX=redX+5;
                pinkX=pinkX+5;
                blueX=blueX+5;
                orangeX=orangeX+5;
                redghostCt++;
                if(redghostCt==10)
                    redghostCt=8;
                pinkghostCt++;
                if(pinkghostCt==10)
                    pinkghostCt=8;
                blueghostCt++;
                if(blueghostCt==10)
                    blueghostCt=8;
                orangeghostCt++;
                if(orangeghostCt==10)
                    orangeghostCt=8;
            }
            if(ghost)
            {
                if(ghostCt<100)
                {
                    ghostCt++;
                    redghost=true;
                    pinkghost=true;
                    blueghost=true;
                    orangeghost=true;
                    if(pacmanRect.intersects(redRect))
                    {
                        redeye=true;
                        redghost=false;
                        eatghostCt=eatghostCt+1;
                        if(eatghostCt==1)
                            scoreCt=scoreCt+200;
                        else if(eatghostCt==2)
                            scoreCt=scoreCt+400;
                        else if(eatghostCt==3)
                            scoreCt=scoreCt+800;
                        else if(eatghostCt==4)
                            scoreCt=scoreCt+1600;
                    }
                    if(pacmanRect.intersects(pinkRect))
                    {
                        pinkeye=true;
                        pinkghost=false;
                        eatghostCt=eatghostCt+1;
                        if(eatghostCt==1)
                            scoreCt=scoreCt+200;
                        else if(eatghostCt==2)
                            scoreCt=scoreCt+400;
                        else if(eatghostCt==3)
                            scoreCt=scoreCt+800;
                        else if(eatghostCt==4)
                            scoreCt=scoreCt+1600;
                    }
                    if(pacmanRect.intersects(blueRect))
                    {
                        blueeye=true;
                        blueghost=false;
                        eatghostCt=eatghostCt+1;
                        if(eatghostCt==1)
                            scoreCt=scoreCt+200;
                        else if(eatghostCt==2)
                            scoreCt=scoreCt+400;
                        else if(eatghostCt==3)
                            scoreCt=scoreCt+800;
                        else if(eatghostCt==4)
                            scoreCt=scoreCt+1600;
                    }
                    if(pacmanRect.intersects(orangeRect))
                    {
                        orangeeye=true;
                        orangeghost=false;
                        eatghostCt=eatghostCt+1;
                        if(eatghostCt==1)
                            scoreCt=scoreCt+200;
                        else if(eatghostCt==2)
                            scoreCt=scoreCt+400;
                        else if(eatghostCt==3)
                            scoreCt=scoreCt+800;
                        else if(eatghostCt==4)
                            scoreCt=scoreCt+1600;
                    }
                }
                if(ghostCt>=100)
                {
                    ghostCt=0;
                    ghost=false;
                    enemy=true;
                }
            }
            if(redeye)
            {   
                redghost=false;
                redeyeCt++;
                if(redeyeCt==17)
                    redeyeCt=10;
            }
            if(pinkeye)
            {
                pinkghost=false;
                pinkeyeCt++;
                if(pinkeyeCt==17)
                    pinkeyeCt=10;
            }
            if(blueeye)
            {
                blueghost=false;
                blueeyeCt++;
                if(blueeyeCt==17)
                    blueeyeCt=10;
            }
            if(orangeeye)
            {
                orangeghost=false;
                orangeeyeCt++;
                if(orangeeyeCt==17)
                    orangeeyeCt=10;
            }
            if(loopCt>=300)
            {
                if(pacmanRect.intersects(rocotoRect))
                {
                    rY=800;
                    loopCt=0;
                    scoreCt=scoreCt+300;
                }
            }

        }
    }

    public void drawRocks( int numLife, Graphics g)
    {
        for (int num=1; num<=numLife; num++)
            bufferG.drawImage(life, 860+30*num, 225, 28, 28, this);
    }

    public void paint (Graphics g)
    {
        bufferG.setColor(Color. black);
        bufferG.fillRect(0,0,1300,700);
        bufferG.setFont(myFont);
        if(pageCt==1)
        {
            bufferG.setColor(Color.white);
            bufferG.drawString("Pacman:a tribute to my dad. To play click the screen. To move Pacman, press the arrow keys.", 200,300);
            bufferG.drawString("Note: because of the pixel detection, pacman might stop while eating a dot, SORRY!" ,200,400);
            bufferG.drawString("Also:he has one life, SORRY AGAIN!", 200,500);
        }
        if(pageCt==2)
        {
            bufferG.drawImage(maze,300,0, 600,700,this); 
            bufferG.setColor(Color.white);
            bufferG.drawString("Lives",900, 200);
            drawRocks(numLife, bufferG);
            bufferG.drawString("Score ",900,400);
            bufferG.drawString(""+scoreCt,900,450);
            bufferG.fillOval(pac1X,pac1Y,20,20);
            bufferG.fillOval(pac2X,pac2Y,20,20);
            bufferG.fillOval(pac3X,pac3Y,20,20);
            bufferG.fillOval(pac4X,pac4Y,20,20);
            if(p1)
                bufferG.fillOval(pX,pY,10,10);
            if(p2)
                bufferG.fillOval(p2X,pY,10,10);
            if(p3)
                bufferG.fillOval(p3X,pY,10,10);
            if(p4)
                bufferG.fillOval(p4X,pY,10,10);
            if(p5)
                bufferG.fillOval(p5X,pY,10,10);
            if(p6)
                bufferG.fillOval(p6X,pY,10,10);
            if(p7)
                bufferG.fillOval(p7X,pY,10,10);
            if(p8)
                bufferG.fillOval(p8X,pY,10,10);
            if(p9)
                bufferG.fillOval(p10X,pY,10,10);
            if(p10)
                bufferG.fillOval(p11X,pY,10,10);
            if(p11)
                bufferG.fillOval(p12X,pY,10,10);
            if(p12)
                bufferG.fillOval(p13X,pY,10,10);
            if(p13)
                bufferG.fillOval(p14X,pY,10,10);
            if(p14)
                bufferG.fillOval(p15X,pY,10,10);
            if(p15)
                bufferG.fillOval(p16X,pY,10,10);
            if(p16)
                bufferG.fillOval(p17X,pY,10,10);
            if(p17)
                bufferG.fillOval(p4X,p2Y,10,10);
            if(p18)
                bufferG.fillOval(p8X,p2Y,10,10);
            if(p19)
                bufferG.fillOval(p10X,p2Y,10,10);
            if(p20)
                bufferG.fillOval(p14X,p2Y,10,10);
            if(p21)
                bufferG.fillOval(p4X,p3Y,10,10);
            if(p22)
                bufferG.fillOval(p5X,p3Y,10,10);
            if(p23)
                bufferG.fillOval(p6X,p3Y,10,10);
            if(p24)
                bufferG.fillOval(p7X,p3Y,10,10);
            if(p25)
                bufferG.fillOval(p8X,p3Y,10,10);
            if(p26)
                bufferG.fillOval(p9X,p3Y,10,10);
            if(p27)
                bufferG.fillOval(p10X,p3Y,10,10);
            if(p28)
                bufferG.fillOval(p11X,p3Y,10,10);
            if(p29)
                bufferG.fillOval(p12X,p3Y,10,10);
            if(p30)
                bufferG.fillOval(p13X,p3Y,10,10);
            if(p31)
                bufferG.fillOval(p14X,p3Y,10,10);
            if(p32)
                bufferG.fillOval(p4X,p4Y,10,10);
            if(p33)
                bufferG.fillOval(p6X,p4Y,10,10);
            if(p34)
                bufferG.fillOval(p12X,p4Y,10,10);
            if(p35)
                bufferG.fillOval(p14X,p4Y,10,10);
            if(p36)
                bufferG.fillOval(pX,p5Y,10,10);
            if(p37)
                bufferG.fillOval(p2X,p5Y,10,10);
            if(p38)
                bufferG.fillOval(p3X,p5Y,10,10);
            if(p39)
                bufferG.fillOval(p4X,p5Y,10,10);
            if(p40)
                bufferG.fillOval(p6X,p5Y,10,10);
            if(p41)
                bufferG.fillOval(p7X,p5Y,10,10);
            if(p42)
                bufferG.fillOval(p8X,p5Y,10,10);
            if(p43)
                bufferG.fillOval(p10X,p5Y,10,10);
            if(p44)
                bufferG.fillOval(p11X,p5Y,10,10);
            if(p45)
                bufferG.fillOval(p12X,p5Y,10,10);
            if(p46)
                bufferG.fillOval(p14X,p5Y,10,10);
            if(p47)
                bufferG.fillOval(p15X,p5Y,10,10);
            if(p48)
                bufferG.fillOval(p16X,p5Y,10,10);
            if(p49)
                bufferG.fillOval(p17X,p5Y,10,10);
            if(p50)
                bufferG.fillOval(pX,p6Y,10,10);
            if(p51)
                bufferG.fillOval(p8X,p6Y,10,10);
            if(p52)
                bufferG.fillOval(p10X,p6Y,10,10);
            if(p53)
                bufferG.fillOval(p17X,p6Y,10,10);
            if(p54)
                bufferG.fillOval(pX,p7Y,10,10);
            if(p55)
                bufferG.fillOval(p2X,p7Y,10,10);
            if(p56)
                bufferG.fillOval(p3X,p7Y,10,10);
            if(p57)
                bufferG.fillOval(p4X,p7Y,10,10);
            if(p58)
                bufferG.fillOval(p5X,p7Y,10,10);
            if(p59)
                bufferG.fillOval(p6X,p7Y,10,10);
            if(p60)
                bufferG.fillOval(p7X,p7Y,10,10);
            if(p61)
                bufferG.fillOval(p8X,p7Y,10,10);
            if(p62)
                bufferG.fillOval(p9X,p7Y,10,10);
            if(p63)
                bufferG.fillOval(p10X,p7Y,10,10);
            if(p64)
                bufferG.fillOval(p11X,p7Y,10,10);
            if(p65)
                bufferG.fillOval(p12X,p7Y,10,10);
            if(p66)
                bufferG.fillOval(p13X,p7Y,10,10);
            if(p67)
                bufferG.fillOval(p14X,p7Y,10,10);
            if(p68)
                bufferG.fillOval(p15X,p7Y,10,10);
            if(p69)
                bufferG.fillOval(p16X,p7Y,10,10);
            if(p70)
                bufferG.fillOval(p17X,p7Y,10,10);
            if(p71)
                bufferG.fillOval(p4X,p8Y,10,10);
            if(p72)
                bufferG.fillOval(p14X,p8Y,10,10);
            if(p73)
                bufferG.fillOval(p4X,p9Y,10,10);
            if(p74)
                bufferG.fillOval(p14X,p9Y,10,10);
            if(p75)
                bufferG.fillOval(p4X,p10Y,10,10);
            if(p76)
                bufferG.fillOval(p14X,p10Y,10,10);
            if(p77)
                bufferG.fillOval(p4X,p11Y,10,10);
            if(p78)
                bufferG.fillOval(p14X,p11Y,10,10);
            if(p79)
                bufferG.fillOval(p4X,p12Y,10,10);
            if(p80)
                bufferG.fillOval(p14X,p12Y,10,10);
            if(p81)
                bufferG.fillOval(p4X,p13Y,10,10);
            if(p83)
                bufferG.fillOval(p14X,p13Y,10,10);
            if(p84)
                bufferG.fillOval(p4X,p14Y,10,10);
            if(p86)
                bufferG.fillOval(p14X,p14Y,10,10);
            if(p87)
                bufferG.fillOval(p4X,p15Y,10,10);
            if(p88)
                bufferG.fillOval(p14X,p15Y,10,10);
            if(p89)
                bufferG.fillOval(p4X,p16Y,10,10);
            if(p90)
                bufferG.fillOval(p14X,p16Y,10,10);
            if(p91)
                bufferG.fillOval(p4X,p17Y,10,10);
            if(p92)
                bufferG.fillOval(p14X,p17Y,10,10);
            if(p93)
                bufferG.fillOval(p4X,p18Y,10,10);
            if(p94)
                bufferG.fillOval(p14X,p18Y,10,10);
            if(p95)
                bufferG.fillOval(pX,p19Y,10,10);
            if(p96)
                bufferG.fillOval(p2X,p19Y,10,10);
            if(p97)
                bufferG.fillOval(p3X,p19Y,10,10);
            if(p98)
                bufferG.fillOval(p4X,p19Y,10,10);
            if(p99)
                bufferG.fillOval(p5X,p19Y,10,10);
            if(p100)
                bufferG.fillOval(p6X,p19Y,10,10);
            if(p101)
                bufferG.fillOval(p7X,p19Y,10,10);
            if(p102)
                bufferG.fillOval(p8X,p19Y,10,10);
            if(p103)
                bufferG.fillOval(p10X,p19Y,10,10);
            if(p104)
                bufferG.fillOval(p11X,p19Y,10,10);
            if(p105)
                bufferG.fillOval(p12X,p19Y,10,10);
            if(p106)
                bufferG.fillOval(p13X,p19Y,10,10);
            if(p107)
                bufferG.fillOval(p14X,p19Y,10,10);
            if(p108)
                bufferG.fillOval(p15X,p19Y,10,10);
            if(p109)
                bufferG.fillOval(p16X,p19Y,10,10);
            if(p110)
                bufferG.fillOval(p17X,p19Y,10,10);
            if(p111)
                bufferG.fillOval(pX,p17Y,10,10);
            if(p112)
                bufferG.fillOval(p2X,p17Y,10,10);
            if(p113)
                bufferG.fillOval(p3X,p17Y,10,10);
            if(p114)
                bufferG.fillOval(p5X,p17Y,10,10);
            if(p115)
                bufferG.fillOval(p6X,p17Y,10,10);
            if(p116)
                bufferG.fillOval(p7X,p17Y,10,10);
            if(p117)
                bufferG.fillOval(p8X,p17Y,10,10);
            if(p118)
                bufferG.fillOval(p9X,p17Y,10,10);
            if(p119)
                bufferG.fillOval(p10X,p17Y,10,10);
            if(p120)
                bufferG.fillOval(p11X,p17Y,10,10);
            if(p121)
                bufferG.fillOval(p12X,p17Y,10,10);
            if(p122)
                bufferG.fillOval(p13X,p17Y,10,10);
            if(p123)
                bufferG.fillOval(p15X,p17Y,10,10);
            if(p124)
                bufferG.fillOval(p16X,p17Y,10,10);
            if(p125)
                bufferG.fillOval(p17X,p17Y,10,10);
            if(p126)
                bufferG.fillOval(p6X,p16Y,10,10);
            if(p127)
                bufferG.fillOval(p12X,p16Y,10,10);
            if(p128)
                bufferG.fillOval(p6X,p15Y,10,10);
            if(p129)
                bufferG.fillOval(p7X,p15Y,10,10);
            if(p130)
                bufferG.fillOval(p8X,p15Y,10,10);
            if(p131)
                bufferG.fillOval(p10X,p15Y,10,10);
            if(p132)
                bufferG.fillOval(p11X,p15Y,10,10);
            if(p133)
                bufferG.fillOval(p12X,p15Y,10,10);
            if(p134)
                bufferG.fillOval(p8X,p14Y,10,10);
            if(p135)
                bufferG.fillOval(p10X,p14Y,10,10);
            if(p136)
                bufferG.fillOval(pX,p16Y,10,10);
            if(p137)
                bufferG.fillOval(p17X,p16Y,10,10);
            if(p138)
                bufferG.fillOval(pX,p15Y,10,10);
            if(p139)
                bufferG.fillOval(p2X,p15Y,10,10);
            if(p140)
                bufferG.fillOval(p3X,p15Y,10,10);
            if(p141)
                bufferG.fillOval(p15X,p15Y,10,10);
            if(p142)
                bufferG.fillOval(p16X,p15Y,10,10);
            if(p143)
                bufferG.fillOval(p17X,p15Y,10,10);
            if(p144)
                bufferG.fillOval(p8X,p18Y,10,10);
            if(p145)
                bufferG.fillOval(p10X,p18Y,10,10);
            if(loopCt>=300)
            {
                bufferG.drawImage(rocoto, rX, rY,35,35,this);
                rY=375;
            }
            if(enemy)
            {
                bufferG.drawImage(redArray[redframeCt],redX,redY,28,28,this);
                bufferG.drawImage(pinkArray[pinkframeCt],pinkX,pinkY,28,28,this);
                bufferG.drawImage(blueArray[blueframeCt],blueX,blueY,28,28,this);
                bufferG.drawImage(orangeArray[orangeframeCt],orangeX,orangeY,28,28,this);
                ghost=false;
                redeye=false;
                pinkeye=false;
                blueeye=false;
                orangeeye=false;
                eatghostCt=0;
            }
            if(ghost)
            {                
                if(ghostCt<100)
                {
                    bufferG.drawString("on",20,20);
                    bufferG.drawString(""+ghostCt,40,40);
                    if(redghost)
                        bufferG.drawImage(redArray[redghostCt],redX,redY,28,28,this);
                    if(pinkghost)
                        bufferG.drawImage(pinkArray[pinkghostCt],pinkX,pinkY,28,28,this);
                    if(blueghost)
                        bufferG.drawImage(blueArray[blueghostCt],blueX,blueY,28,28,this);
                    if(orangeghost)
                        bufferG.drawImage(orangeArray[orangeghostCt],orangeX,orangeY,28,28,this);
                }
            }
            if(redeye)
            {
                bufferG.drawImage(redArray[redeyeCt],redX,redY,20,20,this);   
                redghost=false;
            }
            if(pinkeye)
            {
                bufferG.drawImage(pinkArray[pinkeyeCt],pinkX,pinkY,20,20,this);   
                pinkghost=false;
            }
            if(blueeye)
            {
                bufferG.drawImage(blueArray[blueeyeCt],blueX,blueY,20,20,this);   
                blueghost=false;
            }
            if(orangeeye)
            {
                bufferG.drawImage(orangeArray[orangeeyeCt],orangeX,orangeY,20,20,this);   
                orangeghost=false;
            }
            if(stand)
                bufferG.drawImage(pictureArray[0], pacmanX, pacmanY, 28, 28, this);
            if(right)
            { 
                bufferG.drawImage(pictureArray[frameCt], pacmanX, pacmanY, 28, 28, this);
            }
            if(left)
            { 
                bufferG.drawImage(pictureArray[frameCt], pacmanX+28, pacmanY, -28, 28, this);
            }
            if(up)
            { 
                bufferG.drawImage(pictureArray[frame2Ct], pacmanX, pacmanY+28, 28, -28, this);
            }
            if(down)
            { 
                bufferG.drawImage(pictureArray[frame2Ct], pacmanX, pacmanY, 28, 28, this);
            } 
            if(dead)
            {
                bufferG.drawImage(pictureArray[deadFrameCt],pacmanX,pacmanY,20,20,this);
            }
        }
        if(pageCt==3)
        {
            bufferG.setColor(Color.white);
            bufferG.drawString("You Lose", 300,300);
        }
        g.drawImage(buffer,0,0,this);
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public void keyPressed(KeyEvent e)
    {
        int code=e.getKeyCode();
        if(code==e.VK_RIGHT&&rightColor.equals(Color.black))
        {
            right=true;
            left=false;
            stand=false;
            up=false;
            down=false;
            dead=false;
        }
        if(code==e.VK_LEFT&&leftColor.equals(Color.black))
        {
            left=true;
            right=false;
            stand=false;
            up=false;
            down=false;
            dead=false;
        }
        if(code==e.VK_UP&&TopColor.equals(Color.black))
        {
            left=false;
            right=false;
            stand=false;
            up=true;
            down=false;
            dead=false;
        }
        if(code==e.VK_DOWN&&BottomColor.equals(Color.black))
        {
            left=false;
            right=false;
            stand=false;
            up=false;
            down=true;
            dead=false;
        }
    }

    public void keyReleased(KeyEvent e){}

    public void keyTyped(KeyEvent e){}

    public void mouseClicked(MouseEvent e)
    {
        if(pageCt==1)
        {
            pageCt=2;
            main.start();
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}
}