import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*A simple applet to tell minutes, hours, seconds, and days a person was alive so far
   Amanda Ramos Sept. 25 2012
*/
    
public class daysAlive extends Applet implements ActionListener
{
    TextField yearsTF= new TextField();
    TextField monthsTF= new TextField();
    TextField daysTF= new TextField();
    
    Button daysBtn= new Button("Get Days Alive");
    Button hoursBtn= new Button("Get Days Alive");
    Button minutesBtn= new Button("Get Minutes Alive");
    Button secondsBtn= new Button("Get Seconds Alive");
    Button clearBtn= new Button ("Clear");
    
    String yearsInput="";
    String monthsInput="";
    String daysInput="";
    String output="";
    String answer="";
    String outcome="";
    String answer1="";
    
    double years;
    double months;
    double days;
    double totalDays;
    double totalHours;
    double totalMinutes;
    double totalSeconds;
    
    Font myFont= new Font( "Papyrus" ,1, 16 );
    Color myPurple=new Color( 200, 1, 200 );
    
    public void init()
    {
        this.setLayout(null);

        yearsTF.setBounds(50, 100, 100, 30 );
        this.add(yearsTF);
        
        monthsTF.setBounds(50, 200, 100, 30 );
        this.add(monthsTF);
        
        daysTF.setBounds(50, 300, 100, 30 );
        this.add(daysTF);
        
        daysBtn.setBounds( 200, 430, 150, 50 );
        this.add (daysBtn);
        daysBtn.addActionListener( this );
        
         hoursBtn.setBounds( 200, 490, 150, 50 );
        this.add (hoursBtn);
        hoursBtn.addActionListener( this );
        
         minutesBtn.setBounds( 200, 550, 150, 50 );
        this.add (minutesBtn);
        minutesBtn.addActionListener( this );
        
          secondsBtn.setBounds( 200, 610, 150, 50 );
        this.add (secondsBtn);
        secondsBtn.addActionListener( this );
        
        clearBtn.setBounds( 70, 520, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
    }

    public void actionPerformed(ActionEvent e)
    {
       if(e.getSource()== daysBtn)
       {
           yearsInput = yearsTF.getText();
           years = Double.parseDouble(yearsInput);
           
           monthsInput = monthsTF.getText();
           months = Double.parseDouble(monthsInput);
           
           daysInput = daysTF.getText();
           days = Double.parseDouble(daysInput);
           
           totalDays= years*365.25+months*30+ days;
           output= "You have lived " +totalDays+ " days.";
        } 
       if(e.getSource()== hoursBtn) 
       { 
            totalHours= (years*365.25+months*30+ days)*60;
           answer= "You have lived " +totalHours+ " hours.";
       }
       if(e.getSource()== minutesBtn)  
       {
            totalMinutes= ((years*365.25+months*30+ days)*24)*60;
        outcome= "You have lived " +totalMinutes+ " minutes.";
       }
       if(e.getSource()== secondsBtn)  
       {
            totalSeconds= totalMinutes*60;
        answer1= "You have lived " +totalSeconds+ " seconds.";
       }
       if(e.getSource()== clearBtn)  
       {
          yearsTF.setText("");
          monthsTF.setText("");
          daysTF.setText("");
          output="";
          answer="";
          outcome="";
          answer1="";
       }
       repaint();
    
    }
    public void paint( Graphics g )
    {
      g.setColor( Color. black);
      g.fillRect( 0, 0, 2000, 1000 );
      g.setColor( myPurple);
      g.setFont( myFont);
      g.drawString("DETEMINES TOTAL DAYS YOU HAVE LIVED", 400, 50 );
      g.drawString( "Enter number of years you have lived", 175, 110 );
      g.drawString( "Enter number of months you have lived", 175, 210 );
      g.drawString( "Enter number of days you have lived", 175, 310 );
      g.drawString(output, 400, 450 );
      g.drawString(answer, 400, 520 );
      g.drawString(outcome, 400, 580 );
      g.drawString(answer1, 400, 640 );
    }
}
