import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to tell the days in a month
  Amanda Ramos Oct. 11, 2012 (10/11/12)
 */

public class month extends Applet implements ActionListener

{
    Random rand= new Random ();
    TextField monthTF= new TextField ();
    Button dayBtn= new Button ("Get days");
    Button clearBtn= new Button ("Clear All");
    Font myFont= new Font( "Papyrus" ,1, 30 );
    
    double dayNum;
    String input, output="";
    
    public void init()
    {
        this.setLayout(null);
        
        monthTF.setBounds(50, 90, 190, 30 );
        this.add(monthTF);
        
        dayBtn.setBounds( 10, 450, 180, 50 );
        this.add (dayBtn);
        dayBtn.addActionListener( this );
        
        clearBtn.setBounds( 10, 510, 180, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
    }
    
    public void paint (Graphics g)
    {
        dayBtn.setForeground( Color. black );
        dayBtn.setBackground( Color. yellow );
        clearBtn.setForeground( Color. black );
        clearBtn.setBackground( Color. yellow );
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. red);
        g.setFont ( myFont );
        g.drawString("Type the number of a month to find how many days are in each month.",200, 70 );
        g.drawString("Days in a Month", 500, 30);
        g.drawString("1-January", 500, 110);
        g.drawString("2-Febuary", 500, 160);
        g.drawString("3-March", 500, 210);
        g.drawString("4-April", 500, 260);
        g.drawString("5-May", 500, 310);
        g.drawString("6-June", 500, 360);
        g.drawString("7-July", 500, 410);
        g.drawString("8-August", 500, 460);
        g.drawString("9-September", 500, 510);
        g.drawString("10-October", 500, 560);
        g.drawString("11-November", 500, 610);
        g.drawString("12-December", 500, 660);
        g.drawString(output, 100, 250);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dayBtn )
        {
            input= monthTF.getText();
          dayNum= Double.parseDouble(input);
          if ( dayNum == 1 )
                output="January has 31 days" ;
          else if ( dayNum == 2 )
                output="Febuary has 28 or 29 days";
          else if ( dayNum == 3 )
                output="March has 31 days";
          else if ( dayNum == 4 )
                output="April has 30 days";
          else if ( dayNum == 5 )
                output="May has 31 days";
          else if ( dayNum == 6 )
                output="June has 30 days";
          else if ( dayNum == 7 )
                output="July has 31 days";
          else if ( dayNum == 8 )
                output="August has 31 days";
          else if ( dayNum == 9 )
                output="September has 30 days";
          else if ( dayNum == 10 )
                output="October has 31 days";      
          else if ( dayNum == 11 )
                output="November has 30 days";
          else if ( dayNum == 12 )
                output="December has 31 days";
          else
               output="Warning! Invalid number!";
        }
        
        if(e.getSource() == clearBtn )
        {
            output="";
            monthTF.setText("");
        }
     repaint();
   }
}