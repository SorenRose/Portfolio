
import java.awt.*;
import java.applet.Applet;

/*Simple Applet, practice shadow
  Amanda Ramos  September 10,2012
 */

public class third extends Applet
{
        public void paint( Graphics g )
        { 
            g.setColor( Color. orange );
            g.drawLine( 100, 100, 200, 200 );
            g.drawLine( 100, 200, 200, 100 );
            g.drawLine( 200, 100, 250, 150 );
            g.drawLine( 200, 200, 250, 150 );
            g.drawLine( 200, 100, 150, 50 );
            g.drawLine( 200, 200, 150, 250 );
            g.setColor( Color. red );
            g.drawString( "Move 3 toothpicks", 300,200 );
            g.drawString( "Fish made by Amanda L. Ramos", 50, 300 );
        }
}