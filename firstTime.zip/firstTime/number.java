import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to classify a number
  Amanda Ramos Oct. 10, 2012
 */

public class number extends Applet implements ActionListener

{
    TextField numberTF= new TextField ();
    Button typeBtn= new Button ("Get number type");
    Button clearBtn= new Button ("Clear All");
   
    double typeNum;
    String input, output="";
    
    public void init()
    {
        this.setLayout(null);
       
        numberTF.setBounds(200, 90, 190, 30 );
        this.add(numberTF);
        
        typeBtn.setBounds( 10, 150, 180, 50 );
        this.add (typeBtn);
        typeBtn.addActionListener( this );
        
        clearBtn.setBounds( 100, 210, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
        
    }
    
    public void paint (Graphics g)
    {
        g.drawString("Type in a number (no decimals).",400, 100 );
        g.drawString(output, 200, 400);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == typeBtn )
        {
          input= numberTF.getText();
          typeNum= Double.parseDouble(input);
          if ( typeNum <0 )
                typeNum= typeNum *-1;
          if ( typeNum <= 9 )
                output="Single digit";
          else if ( typeNum < 100 )
                output="Double digits";
          else if ( typeNum >= 100)
                output="Triple digits";
        }
        
        if(e.getSource() == clearBtn )
        {
            output="";
            numberTF.setText("");
        }
     repaint();
   }
}