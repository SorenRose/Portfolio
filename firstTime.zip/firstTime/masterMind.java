import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make a tutorial for Mastermind
Amanda Ramos Oct. 23, 2012
 */

public class masterMind extends Applet implements ActionListener

{
    Button nextBtn= new Button ("Next");
    Button BBtn= new Button ("Blue");
    Button RBtn= new Button ("Red");
    Button YBtn= new Button ("Yellow");
    Button GBtn= new Button ("Green");
    Button PBtn= new Button ("Purple");
    Button OBtn= new Button ("Orange");
    Button MBtn= new Button ("Magenta");
    Button WBtn= new Button ("White");
    Font myFont= new Font( "Papyrus" ,1, 27 );

    Color myPurple=new Color( 200, 1, 200 );
    Color mystery=new Color (250, 85, 110 );
    Color myOrange=new Color (240, 150, 0 );

    int randNum=8;
    
    Random rand= new Random ();
    char secret1= 'x';
    char secret2= 'x';
    char secret3= 'x';
    char guess1= 'x';
    char guess2= 'x';
    char guess3='x';
    char choice='x';
    char red='R';
    char green='G';
    char yellow='Y';
    char blue='B';
    char magenta='M';
    char purple='P';
    char orange='O';
    char white='W';

    int pageCt=0;
    String output="";
    String output1="";
    String output2="";
    TextArea outputTA=new TextArea();
    int pegCt=0;
    int colorCt=0;
    int numGuess=0;

    public char getRandomColor()
    {
        int randNum= rand.nextInt(8);
        if(randNum==0) return 'P';
        else if(randNum==1) return 'W';
        else if(randNum==2) return 'B';
        else if(randNum==3) return 'R';
        else if(randNum==4) return 'G';
        else if(randNum==5) return 'M';
        else if(randNum==6) return 'Y';
        else return 'O';
    }

    public void init()
    {
        do
        {
            secret1=getRandomColor();
            secret2=getRandomColor();
            secret3=getRandomColor();
        }
        while(secret1==secret2|
        secret2==secret3|
        secret1==secret1);
        this.setLayout(null);

        BBtn.setBounds( 20, 600, 70, 40 );
        this.add (BBtn);
        BBtn.addActionListener( this );
        BBtn.setForeground( Color. white );
        BBtn.setBackground( Color. blue );

        RBtn.setBounds( 100, 600, 70, 40 );
        this.add (RBtn);
        RBtn.addActionListener( this );
        RBtn.setForeground( Color. yellow );
        RBtn.setBackground( Color. red );

        WBtn.setBounds( 180, 600, 70, 40 );
        this.add (WBtn);
        WBtn.addActionListener( this );
        WBtn.setForeground( Color. green );
        WBtn.setBackground( Color. white );

        OBtn.setBounds( 260, 600, 70, 40 );
        this.add (OBtn);
        OBtn.addActionListener( this );
        OBtn.setForeground( Color. blue );
        OBtn.setBackground( myOrange );

        GBtn.setBounds( 340, 600, 70, 40 );
        this.add (GBtn);
        GBtn.addActionListener( this );
        GBtn.setForeground( Color. black );
        GBtn.setBackground( Color. green );

        YBtn.setBounds( 420, 600, 70, 40 );
        this.add (YBtn);
        YBtn.addActionListener( this );
        YBtn.setForeground( Color. blue );
        YBtn.setBackground( Color. yellow );

        PBtn.setBounds( 500, 600, 70, 40 );
        this.add (PBtn);
        PBtn.addActionListener( this );
        PBtn.setForeground( Color. white );
        PBtn.setBackground( myPurple );

        MBtn.setBounds( 580, 600, 70, 40 );
        this.add (MBtn);
        MBtn.addActionListener( this );
        MBtn.setForeground( Color. black );
        MBtn.setBackground( mystery );

        nextBtn.setBounds( 660, 600, 70, 40 );
        this.add (nextBtn);
        nextBtn.addActionListener( this );
        nextBtn.setForeground( Color. blue );
        nextBtn.setBackground( Color. yellow );
    }

    public void paint (Graphics g)
    {
        g.setColor(Color. red);
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. black);
        g.setFont ( myFont );
        g.drawString(output, 300, 300);
        g.drawString(output1, 300, 340);
        g.drawString(output2, 300, 380);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
            pageCt= pageCt+1;
            nextBtn.setVisible(true);
            output="";
            output1="";
            output2="";
            numGuess=0;
            guess1= 'x';
            guess2= 'x';
            guess3= 'x';
            RBtn.setVisible(true);
            BBtn.setVisible(true);
            WBtn.setVisible(true);
            PBtn.setVisible(true);
            YBtn.setVisible(true);
            GBtn.setVisible(true);
            OBtn.setVisible(true);
            MBtn.setVisible(true);
            nextBtn.setVisible(false);
        } 
        if(e.getSource() == RBtn )
        {
            RBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=red;

        }   
        if(e.getSource() == BBtn )
        {
            BBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=blue;

        }   
        if(e.getSource() == YBtn )
        {
            YBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=yellow;

        }

        if(e.getSource() == OBtn )
        {
            OBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=orange;

        }

        if(e.getSource() == GBtn )
        {
            GBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=green;

        }

        if(e.getSource() == WBtn )
        {
            WBtn.setVisible(false);
            numGuess=numGuess+1;
            choice=white;

        }

        if(e.getSource() == PBtn )
        {
            PBtn.setVisible(false);
            numGuess=numGuess+1;
            choice='P';

        }

        if(e.getSource() == MBtn )
        {
            MBtn.setVisible(false);
            numGuess=numGuess+1;
            choice='M';

        }
        if(numGuess==1)
        {
            guess1=choice;
        }

        if(numGuess==2)
        {
            guess2=choice;
        }
        if(numGuess==3)
        {
            guess3=choice;
            RBtn.setVisible(false);
            BBtn.setVisible(false);
            WBtn.setVisible(false);
            PBtn.setVisible(false);
            YBtn.setVisible(false);
            GBtn.setVisible(false);
            OBtn.setVisible(false);
            MBtn.setVisible(false);
            nextBtn.setVisible(true);
            colorCt=0;
            pegCt=0
            if(guess1==secret1| guess1==secret2| guess1==secret3)
            {
                colorCt=colorCt+1;
            }
            if(guess2==secret1| guess2==secret2| guess2==secret3)
            {
                colorCt=colorCt+1;
            }
            if(guess3==secret1| guess3==secret2| guess3==secret3)
            {
                colorCt=colorCt+1;
            }
            if(guess1==secret1)
            {
                pegCt=pegCt+1;
            }
            if(guess2==secret2)
            {
                pegCt=pegCt+1;
            }
            if(guess3==secret3)
            {
                pegCt=pegCt+1;
            }
            output=("You have guessed "+ guess1+ ", "+guess2+ ", "+ guess3);
            output1=("You have "+pegCt+ " pegs correct.");
            output2=("You have "+colorCt+" color(s) correct.");
        }
        repaint();
    }
}