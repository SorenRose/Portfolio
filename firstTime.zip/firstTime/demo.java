import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class demo extends Applet implements ActionListener
{
    String name="";
    String lastName="";
    Button nameBtn=new Button ("Get Name");
    TextField nameTF= new TextField();
    TextField lastNameTF= new TextField();
    Font font30= new Font( "Papyrus", 1, 18);

    public void init()
    {
        this.setLayout(null);

        nameBtn.setBounds( 100, 200, 75, 40 );
        nameBtn.addActionListener(this);
        this.add(nameBtn);

        lastNameTF.setBounds( 400, 100, 150, 40 );
        nameTF.setBounds( 100, 100, 150, 40 );
        this.add(nameTF);
        this.add(lastNameTF);
    }

    public void actionPerformed(ActionEvent e)
    {
        name= nameTF.getText();
        lastName=lastNameTF.getText();
        repaint();
    }

    public void paint( Graphics g )
    {
        g.setFont( font30 );
        g.setColor( Color. red);
        g.drawString( "Enter name" , 100, 90 );
        g.drawString( "Enter last name", 400, 90 );
        g.drawString( name, 100, 300 );
        g.drawString( lastName, 130, 300 );
    }
}
