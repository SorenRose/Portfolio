
import java.awt.*;
import java.applet.Applet;

/*Simple Applet to output stuff
  Soren September 18 ,2012
 */

public class bingoApplet extends Applet
{
            Color mystery=new Color (150, 142, 120 );        
            Color myPurple=new Color( 200, 1, 200 );
            Color myBrown=new Color( 170, 130, 110 );
            public void paint( Graphics g )
        {
           g.drawRect(100, 100, 100, 100 );
           g.drawRect(100, 200, 100, 100 );
           g.drawRect(100, 300, 100, 100 );
           g.drawRect(100, 400, 100, 100 );
           g.drawRect(100, 500, 100, 100 );
           g.drawRect(200, 100, 100, 100 );
           g.drawRect(200, 200, 100, 100 );
           g.drawRect(200, 300, 100, 100 );
           g.drawRect(200, 400, 100, 100 );
           g.drawRect(200, 500, 100, 100 );
           g.drawRect(300, 100, 100, 100 );
           g.drawRect(300, 200, 100, 100 );
           g.drawRect(300, 300, 100, 100 );
           g.drawRect(300, 400, 100, 100 );
           g.drawRect(300, 500, 100, 100 );
        }
}