import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make a multiple choise applet
  Amanda Ramos Oct. 16, 2012
 */

public class multipleAnswer extends Applet implements ActionListener

{
    Random rand= new Random ();
    Button oneBtn= new Button ("Tatyana Lysenko");
    Button twoBtn= new Button ("Sally Pearson");
    Button threeBtn= new Button ("Elena Lashmanova");
    Button fourBtn= new Button ("Allyson Felix");
    Button clearBtn= new Button ("Clear All");
    Font myFont= new Font( "Papyrus" ,1, 30 );
    
    String input, output="";
    
    public void init()
    {
        this.setLayout(null);
        
        oneBtn.setBounds( 110, 350, 180, 50 );
        this.add (oneBtn);
        oneBtn.addActionListener( this );
        
        twoBtn.setBounds( 310, 350, 180, 50 );
        this.add (twoBtn);
        twoBtn.addActionListener( this );
        
        threeBtn.setBounds( 110, 450, 180, 50 );
        this.add (threeBtn);
        threeBtn.addActionListener( this );
        
        fourBtn.setBounds( 310, 450, 180, 50 );
        this.add (fourBtn);
        fourBtn.addActionListener( this );
        
        clearBtn.setBounds( 110, 550, 180, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
    }
    
    public void paint (Graphics g)
    {
        oneBtn.setForeground( Color. black );
        oneBtn.setBackground( Color. yellow );
        twoBtn.setForeground( Color. black );
        twoBtn.setBackground( Color. yellow );
        threeBtn.setForeground( Color. black );
        threeBtn.setBackground( Color. yellow );
        fourBtn.setForeground( Color. black );
        fourBtn.setBackground( Color. yellow );
        clearBtn.setForeground( Color. black );
        clearBtn.setBackground( Color. yellow );
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. red);
        g.setFont ( myFont );
        g.drawString("Who broke the hammer throw record for girls?",200, 70 );
        g.drawString(output, 100, 250);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == oneBtn )
        {
               output="Correct";
        }
        if(e.getSource() == twoBtn )
        {
               output="Incorrect";
        }
        if(e.getSource() == threeBtn )
        {
               output="Incorrect";
        }
        if(e.getSource() == fourBtn )
        {
               output="Incorrect";
        }
        if(e.getSource() == clearBtn )
        {
            output="";
        }
     repaint();
   }
}