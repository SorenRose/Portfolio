import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class test411 extends Applet implements Runnable, MouseListener, KeyListener
//An applet to try and create a melee game, started on: 8/16/2013
//to test on: runnable, mouselistener, keylistener, arrays, graphics, counters, images, init
{
    Thread main= new Thread(this);
    Font font= new Font( "Comic Sans MS", 1, 80);
    Font font1= new Font( "Comic Sans MS", 1, 50);
    Color myBlue=new Color( 20, 170, 250 );
    Image buffer;
    Graphics bufferG;
    int pageCt=0;
    int playerCt=0;
    int luffystand1Ct=0;
    int brookstand1Ct=0;
    int kurostand2Ct=0;
    int chopperstand1Ct=0;
    int mouseX=-10;
    int mouseY=-10;
    int luffy1X=100;
    int luffy1Y= 20;
    int brook1X=100;
    int brook1Y= 90;
    int kuro2X=750;
    int kuro2Y= 140;
    int chopper1X=100;
    int chopper1Y= 320;
    Image flame;
    Image skull;
    Image sunny;
    Image luffy1Array[]= new Image[7];
    Image brook1Array[]= new Image[4];
    Image kuro2Array[]= new Image[4];
    Image chopper1Array[]= new Image[4];

    Image luffy;
    Image Brook;
    Image Kuro;
    Image Crocodile;
    Image Ace;
    Image chopper;
    Image Zoro;
    Image Sanji;
    Image Shanks;
    Image Nami;
    Image Robin;

    int x=10000;
    int x1=10000;
    int x2=10000;
    int x3=10000;
    int x4=10000;
    int x5=10000;
    int x6=10000;
    int x7=10000;
    int x8=10000;
    int x9=10000;
    int x10=10000;
    int x11=10000;
    int x12=10000;
    int x13=10000;
    int x14=10000;
    int x15=10000;
    int x16=10000;
    int x17=10000;
    int x18=10000;
    int x19=10000;
    int x20=10000;
    int x21=10000;
    boolean luffy1=false;
    boolean brook1=false;
    boolean kuro2=false;
    boolean chopper1=false;
    boolean luffy1stand=true;
    boolean brook1stand=true;
    boolean kuro2stand=true;
    boolean chopper1stand=true;

    public void init()
    {
        this.setLayout(null);
        resize(1300, 756);
        buffer=createImage(this.getWidth(),this.getHeight());
        bufferG= buffer.getGraphics();
        this.addKeyListener(this);
        this.addMouseListener(this);

        flame=this.getImage(this.getCodeBase(), "flame.png" );
        skull=this.getImage(this.getCodeBase(), "strawhat.png");
        sunny=this.getImage(this.getCodeBase(), "sunny.png");
        luffy=this.getImage(this.getCodeBase(), "luffy.png" );
        luffy1Array[0]=getImage( this.getCodeBase(),"luffy1.png");
        luffy1Array[1]=getImage( this.getCodeBase(),"luffy2.png");
        luffy1Array[2]=getImage( this.getCodeBase(),"luffy3.png");
        luffy1Array[3]=getImage( this.getCodeBase(),"luffy4.png");
        luffy1Array[4]=getImage( this.getCodeBase(),"luffy5.png");
        luffy1Array[4]=getImage( this.getCodeBase(),"luffy6.png");
        luffy1Array[5]=getImage( this.getCodeBase(),"luffy7.png");
        Brook=this.getImage(this.getCodeBase(), "Brook.png" );
        brook1Array[0]=getImage( this.getCodeBase(),"brook1.png");
        brook1Array[1]=getImage( this.getCodeBase(),"brook2.png");
        brook1Array[2]=getImage( this.getCodeBase(),"brook3.png");
        brook1Array[3]=getImage( this.getCodeBase(),"brook4.png");
        Kuro=this.getImage(this.getCodeBase(), "kuro.png" );
        kuro2Array[0]=getImage( this.getCodeBase(),"kuro1.png");
        kuro2Array[1]=getImage( this.getCodeBase(),"kuro2.png");
        kuro2Array[2]=getImage( this.getCodeBase(),"kuro1.png");
        kuro2Array[3]=getImage( this.getCodeBase(),"kuro2.png");
        Crocodile=this.getImage(this.getCodeBase(), "crocodile.png" );
        Ace=this.getImage(this.getCodeBase(), "ace.png" );
        chopper=this.getImage(this.getCodeBase(), "chopper.png" );
        chopper1Array[0]=getImage( this.getCodeBase(),"chopper1.png");
        chopper1Array[1]=getImage( this.getCodeBase(),"chopper2.png");
        chopper1Array[2]=getImage( this.getCodeBase(),"chopper3.png");
        chopper1Array[3]=getImage( this.getCodeBase(),"chopper2.png");
        Zoro=this.getImage(this.getCodeBase(), "zoro.png" );
        Sanji=this.getImage(this.getCodeBase(), "sanji.png" );
        Shanks=this.getImage(this.getCodeBase(), "shanks.png" );
        Nami=this.getImage(this.getCodeBase(), "nami.png" );
        Robin=this.getImage(this.getCodeBase(), "robin.png" );

        main.start();
    }

    public void run()
    {
        do
        {    
            repaint();
            try
            {main.sleep(120);}
            catch(Exception e){}
            luffystand1Ct++;
            brookstand1Ct++;
            kurostand2Ct++;
            chopperstand1Ct++;
            if(luffy1stand==true)
            {
                if(luffystand1Ct==6)
                    luffystand1Ct=0;
            }
            if(brook1stand==true)
            {
                if(brookstand1Ct==3)
                    brookstand1Ct=0;
            }
            if(kuro2stand==true)
            {
                if(kurostand2Ct==3)
                    kurostand2Ct=0;
            }
            if(chopper1stand==true)
            {
                if(chopperstand1Ct==3)
                    chopperstand1Ct=0;
            }
        }
        while(pageCt<4);

        repaint();
    }

    public void paint( Graphics g )
    {
        bufferG.setColor( Color. black);
        bufferG.fillRect(0,0,10000,100000);

        if(pageCt==0)
        {
            bufferG.drawImage(flame,0, 150, 1300, 600, this);
            bufferG.drawImage(skull, 370, 130, 450, 400, this );
            bufferG.setFont( font );
            bufferG.setColor( Color. red);
            bufferG.drawString("One Piece ", 400, 100);
            bufferG.setColor(myBlue);
            bufferG.drawString("Navel Melee", 375, 650);
        }
        if(pageCt==1)
        {  
            bufferG.drawImage(flame,0, 150, 1300, 600, this);
            bufferG.drawImage(luffy, x, 100, 300, 350, this ); 
            bufferG.drawImage(Brook, x1, 100, 300, 350, this);
            bufferG.drawImage(Kuro, x2, 100, 300, 380, this);
            bufferG.drawImage(Crocodile, x3, 100, 300, 380, this);
            bufferG.drawImage(Ace, x4, 100, 300, 450, this);
            bufferG.drawImage(chopper, x5, 100, 300, 380, this);
            bufferG.drawImage(Zoro, x6, 100, 400, 370, this);
            bufferG.drawImage(Sanji, x7, 100, 300, 500, this);
            bufferG.drawImage(Shanks, x8, 100, 300, 420, this);
            bufferG.drawImage(Nami, x9, 100, 300, 380, this);
            bufferG.drawImage(Robin, x20, 100, 300, 430, this);
            bufferG.drawImage(luffy, x10, 100, 300, 350, this ); 
            bufferG.drawImage(Brook, x11, 100, 300, 450, this);
            bufferG.drawImage(Kuro, x12, 100, 300, 380, this);
            bufferG.drawImage(Crocodile, x13, 100, 300, 380, this);
            bufferG.drawImage(Ace, x14, 100, 300, 450, this);
            bufferG.drawImage(chopper, x15, 100, 300, 380, this);
            bufferG.drawImage(Zoro, x16, 100, 400, 370, this);
            bufferG.drawImage(Sanji, x17, 100, 300, 500, this);
            bufferG.drawImage(Shanks, x18, 100, 300, 420, this);
            bufferG.drawImage(Nami, x19, 100, 300, 380, this);
            bufferG.drawImage(Robin, x21, 100, 300, 430, this);
            bufferG.setFont( font );
            bufferG.setColor( Color. red);
            bufferG.drawString("VS.", 460, 300);
            bufferG.setFont( font1 );
            bufferG.drawString("Luffy", 100, 70);
            bufferG.drawRect(100, 20, 150, 65);
            bufferG.drawString("Brook", 100, 130);
            bufferG.drawRect(100, 90, 150, 50);
            bufferG.drawString("Kuro", 100, 190);
            bufferG.drawString("Crocodile", 100, 250);
            bufferG.drawString("Ace", 100, 310);
            bufferG.drawString("Chopper", 100, 370);
            bufferG.drawRect(100, 320, 200, 50);
            bufferG.drawString("Zoro", 100, 430);
            bufferG.drawString("Sanji", 100, 490);
            bufferG.drawString("Shanks", 100, 550);
            bufferG.drawString("Nami", 100, 610);
            bufferG.drawString("Robin", 100, 670);
            bufferG.setColor(myBlue);
            bufferG.drawString("Luffy", 750, 70);
            bufferG.drawString("Brook", 750, 130);
            bufferG.drawString("Kuro", 750, 190);
            bufferG.drawRect(750, 140, 100, 50);
            bufferG.drawString("Crocodile", 750, 250);
            bufferG.drawString("Ace", 750, 310);
            bufferG.drawString("Chopper", 750, 370);
            bufferG.drawString("Zoro", 750, 430);
            bufferG.drawString("Sanji", 750, 490);
            bufferG.drawString("Shanks", 750, 550);
            bufferG.drawString("Nami", 750, 610);
            bufferG.drawString("Robin", 750, 670);
        }
        if(pageCt==2)
        {
            bufferG.setColor( Color. white);
            bufferG.fillRect(0,0,10000,100000);
            //bufferG.fillRect(0,0,this.getWidth(),this.getHeight());
            if(luffy1==true)
            {
                if(luffy1stand==true)
                    bufferG.drawImage(luffy1Array[luffystand1Ct], 100, 400, 200, 230, this);
            }
            if(brook1==true)
            {
                if(brook1stand==true)
                    bufferG.drawImage(brook1Array[brookstand1Ct], 100, 380, 200, 250, this);
            }
            if(kuro2==true)
            {
                if(kuro2stand==true)
                    bufferG.drawImage(kuro2Array[kurostand2Ct], 750, 400, 180, 230, this);
            }
            if(chopper1==true)
            {
                if(chopper1stand==true)
                    bufferG.drawImage(chopper1Array[chopperstand1Ct], 100, 420, 160, 210, this);
            }
        }
        g.drawImage(buffer,0,0,this);
    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public void keyPressed(KeyEvent e)
    {
        int code=e.getKeyCode();
    }

    public void keyReleased(KeyEvent e)
    {

        if(luffy1stand==true)
        {
            luffystand1Ct++;
        }
        if(brook1stand==true)
        {
            brookstand1Ct++;
        }
        if(kuro2stand==true)
        {
            kurostand2Ct++;
        }
        if(chopper1stand==true)
        {
            chopperstand1Ct++;
        }
    }

    public void keyTyped(KeyEvent e){}

    public void mouseClicked(MouseEvent e)
    {

        if(pageCt==0)
        {
            pageCt=1;
        }
        if(pageCt==1)
        {
            mouseX=e.getX();
            mouseY=e.getY();
            if((mouseX>=luffy1X&&mouseX<=luffy1X+150)&&
            (mouseY>=luffy1Y&&mouseY<=luffy1Y+65))
            {
                playerCt=playerCt+1;
                luffy1=true;
            }
            if((mouseX>=brook1X&&mouseX<=brook1X+150)&&
            (mouseY>=brook1Y&&mouseY<=brook1Y+50))
            {
                playerCt=playerCt+1;
                brook1=true;
            }
            if((mouseX>=kuro2X&&mouseX<=kuro2X+150)&&
            (mouseY>=kuro2Y&&mouseY<=kuro2Y+50))
            {
                playerCt=playerCt+1;
                kuro2=true;
            }
            if((mouseX>=chopper1X&&mouseX<=chopper1X+250)&&
            (mouseY>=chopper1Y&&mouseY<=chopper1Y+50))
            {
                playerCt=playerCt+1;
                chopper1=true;
            }
            if(playerCt==2)
                pageCt=2;
            main.start();
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}
}
