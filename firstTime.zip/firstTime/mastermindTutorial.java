import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make a tutorial for Mastermind
  Amanda Ramos Oct. 22, 2012
 */

public class mastermindTutorial extends Applet implements ActionListener

{
    Random rand= new Random ();
    Button nextBtn= new Button ("Next");
    Button backBtn= new Button ("Back");
    Button endBtn= new Button ("End");
    Font myFont= new Font( "Papyrus" ,1, 27 );
    
    int pageCt=0;
    String output="";
    
    public void init()
    {
        this.setLayout(null);
        
        nextBtn.setBounds( 500, 600, 100, 40 );
        this.add (nextBtn);
        nextBtn.addActionListener( this );
        
        backBtn.setBounds( 350, 600, 100, 40 );
        this.add (backBtn);
        backBtn.addActionListener( this );
        
        endBtn.setBounds( 200, 600, 100, 40 );
        this.add (endBtn);
        endBtn.addActionListener( this );
        
    }
    
    public void paint (Graphics g)
    {
        backBtn.setForeground( Color. blue );
        backBtn.setBackground( Color. yellow );
        endBtn.setForeground( Color. blue );
        endBtn.setBackground( Color. yellow );
        nextBtn.setForeground( Color. blue );
        nextBtn.setBackground( Color. yellow );
        g.setColor(Color. red);
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. black);
        g.setFont ( myFont );
        if(pageCt==0)
        {
            g.drawString("Welcome to this MasterMind tutorial, press next to continue.", 300, 300);
        }
        if(pageCt==1)
        {
            g.drawString("Mastermind is a game of logic, a player must make a secret code made of 3 letters. For example:", 10, 30);
            g.drawString("Red, Green, Blue, Yellow, Orange, Magenta, Purple, White. Out of these colors the first letter", 10, 70);
            g.drawString("from those colors are used to make a code. The other players have to guess the 3 letters it is and has ", 10, 110);
            g.drawString("6 tries to guess which 3 letters it is. The one who tries to guess the letters has about 6 chances", 10, 150);
            g.drawString("to get the correct code. Out of 6 chances the player must get the colors and pegs(placement)", 10, 190);
            g.drawString("correct. Once they have made a 3 letter guess, he/she goes to the player who made the code ", 10, 230);
            g.drawString("and that person says how many colors out of the guess is correct and if any is in the same ",10, 270);
            g.drawString("placement as the one he/she made.The player MUST get the color and placement of that", 10, 310);
            g.drawString("specific color. If you get the code exactly correct within six tries you win!", 10, 350);
        }
        if(pageCt==2)
        {
            g.drawString("The person who makes the code will make one with the colors given last page. EX: GYM", 10, 30);
            g.drawString("(G=green, Y=yellow, M=magenta).So now the other player must guess the 3 letters now I will", 10, 70);
            g.drawString(" show a demo game. NOTE: this is a demo ONLY used to show an example.", 10, 110 );
            g.drawString("Guessing Player: guess= RBO Checker: 0 colors correct, 0 correct placements(pegs)", 10, 150);
            g.drawString("so now we know none of the colors are correct", 10, 190);
            g.drawString("Guessing Player: guess= WGP Checker: 1 color correct, 0 correct pegs", 10, 230);
            g.drawString("so now we know one color is correct but its not in the right place", 10, 270);
            g.drawString("Guessing Player: guess= GMY Checker: 3 colors correct, 1 correct peg", 10, 310);
            g.drawString("so know we have all the colors we need but two are in the wrong order", 10, 350);
            g.drawString("Guessing Player: guess= GYM Checker: 3 colors correct, 3 correct pegs", 10, 390);
            g.drawString("So now the code is correct and less then 6 tries so the guessing player wins!", 10, 430);
            g.drawString("So know you know how to play I hope, you can play with multiple people who try", 10, 470);
            g.drawString("to guess the code. Have fun!", 10, 510); 
        }
        if (pageCt==3)
        { 
            g.drawString("Thank you so much for reading this tutorial!",400, 100 );
            backBtn.setVisible(false);
            endBtn.setVisible(false);
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
             pageCt= pageCt+1;
              nextBtn.setVisible(true);
             if(pageCt==3)
             {
              nextBtn.setVisible(false);
            }
        }
        if(e.getSource() == endBtn )
        {
            pageCt=pageCt+3; 
            endBtn.setVisible(true); 
             if( pageCt==3)
            {  
                endBtn.setVisible(false);
            }
        }
        if(e.getSource() == backBtn )
        {
            pageCt= pageCt-1;
            
            if(pageCt==0)
            {
            backBtn.setVisible(false);
            }
            else if( pageCt==1)
            {  
                backBtn.setVisible(true);
            }
            else if( pageCt==2)
            {  
                backBtn.setVisible(true);
            }
            else if(pageCt==3)
                backBtn.setVisible(false);
        }  
        
        repaint();
    }
}