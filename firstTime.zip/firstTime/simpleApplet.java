
import java.awt.*;
import java.applet.Applet;

/*Simple Applet to output stuff
  Mr.Luciano  September 4,2012
 */

public class simpleApplet extends Applet
{
            Color myOrange=new Color (240, 150, 0 );        
            Color myPurple=new Color( 200, 1, 200 );
            Color myBlue=new Color( 20, 170, 250 );
            public void paint( Graphics g )
        {
            g.setColor( myOrange );   
            g.fillRect( 100, 100, 200, 200 );
            g.setColor( myPurple );
            g.fillRect( 100, 310, 200, 200 );
            g.setColor( myBlue );
            g.fillRect( 310, 100, 200, 200 );
        }
}