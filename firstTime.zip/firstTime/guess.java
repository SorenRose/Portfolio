import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to guess a number
  Amanda Ramos Oct. 9, 2012
 */

public class guess extends Applet implements ActionListener

{
    Button highBtn= new Button ("Lower");
    Button lowBtn= new Button ("Higher");
    Button correctBtn= new Button ("Correct");
    Button guessBtn= new Button ("Guess");
    Button clearBtn= new Button ("Clear");
    
   int high= 100;
   int low= 0;
   int guess= (low+high)/2;

   String input, output="";
   String input1, responce="";
   
    
    public void init()
    {
        this.setLayout(null);
       
        highBtn.setBounds( 10, 90, 100, 50 );
        this.add (highBtn);
        highBtn.addActionListener( this );
        
        lowBtn.setBounds( 10, 150, 100, 50 );
        this.add (lowBtn);
        lowBtn.addActionListener( this );
        
        correctBtn.setBounds( 10, 210, 100, 50 );
        this.add (correctBtn);
        correctBtn.addActionListener( this );
        
        clearBtn.setBounds( 10, 290, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
        
    }
    
    public void paint (Graphics g)
    {
        g.drawString("Think of a number and I will try to guess it.",400, 100 );
        g.drawString(output, 200, 400);
        g.drawString(responce, 400, 400);
    }
    
    public void actionPerformed(ActionEvent e)
    {
     if(e.getSource() == highBtn )
        {
            low= guess+1;
            output= "is it "+low;
        }
     if(e.getSource() == lowBtn )
        {
            high= guess-1;
            output= "is it "+high;
        }
     if(e.getSource() == guessBtn )
        {
            guess= (high+low);
            output= "is it "+guess;
        }   
     if(e.getSource() == correctBtn )
        {
          responce= "YAY!!!!";
        }
     if(e.getSource() == guessBtn )
        {
          guess= (high+low)/2;
            output= "is it "+guess;
        }
     if(e.getSource() == clearBtn )
        {
            
        }
     repaint();
   }
}