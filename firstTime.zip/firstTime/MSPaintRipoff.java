import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make MS Paint
Amanda Ramos Nov. 19, 2012
 */

public class MSPaintRipoff extends Applet implements ActionListener, MouseListener, MouseMotionListener

{
    Button BBtn= new Button ("Blue");
    Button RBtn= new Button ("Red");
    Button YBtn= new Button ("Yellow");
    Button GBtn= new Button ("Green");
    Button PBtn= new Button ("Purple");
    Button OBtn= new Button ("Orange");
    Button MBtn= new Button ("Pink");
    //pink is M, final change.
    Button CircleBtn= new Button ("Circle");
    Button SquareBtn= new Button ("Square");
    Button RectBtn= new Button ("Rectangle");
    Button LineBtn= new Button ("Line");
    Button WBtn= new Button ("White");
    Button NBtn= new Button ("Black");
    // black is N
    Button DBtn= new Button ("Brown");
    //brown is D
    Button ResetBtn= new Button ("Reset");
    Button penBtn= new Button ("Pen");
    Button eraserBtn= new Button ("Eraser");
    Button undoBtn= new Button ("Undo");
    Font myFont= new Font( "Papyrus" ,1, 27 );

    TextField widthTF= new TextField ();
    TextField heightTF= new TextField ();

    Color myPurple=new Color( 200, 1, 200 );
    Color mystery=new Color (250, 85, 110 );
    Color myOrange=new Color (240, 150, 0 );
    Color myBrown=new Color( 110, 70, 60 );

    char color='x',shape ='x';
    int x, y, height, width, x1, x2, y1, y2;
    boolean penOn=false;
    boolean eraserOn=false;

    String input="";

    public void init()
    {
        this.setLayout(null);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        resize(1300, 700);

        widthTF.setBounds( 90, 310, 90, 40 );
        this.add( heightTF );

        heightTF.setBounds ( 90, 360, 90, 40 );
        this.add( widthTF );

        BBtn.setBounds( 80, 60, 70, 40 );
        this.add (BBtn);
        BBtn.addActionListener( this );
        BBtn.setForeground( Color. white );
        BBtn.setBackground( Color. blue );

        RBtn.setBounds( 80, 100, 70, 40 );
        this.add (RBtn);
        RBtn.addActionListener( this );
        RBtn.setForeground( Color. yellow );
        RBtn.setBackground( Color. red );

        WBtn.setBounds( 80, 140, 70, 40 );
        this.add (WBtn);
        WBtn.addActionListener( this );
        WBtn.setForeground( Color. green );
        WBtn.setBackground( Color. white );

        OBtn.setBounds( 80, 180, 70, 40 );
        this.add (OBtn);
        OBtn.addActionListener( this );
        OBtn.setForeground( Color. blue );
        OBtn.setBackground( myOrange );

        GBtn.setBounds( 10, 60, 70, 40 );
        this.add (GBtn);
        GBtn.addActionListener( this );
        GBtn.setForeground( Color. black );
        GBtn.setBackground( Color. green );

        YBtn.setBounds( 10, 100, 70, 40 );
        this.add (YBtn);
        YBtn.addActionListener( this );
        YBtn.setForeground( Color. blue );
        YBtn.setBackground( Color. yellow );

        PBtn.setBounds( 10, 140, 70, 40 );
        this.add (PBtn);
        PBtn.addActionListener( this );
        PBtn.setForeground( Color. white );
        PBtn.setBackground( myPurple );

        MBtn.setBounds( 10, 180, 70, 40 );
        this.add (MBtn);
        MBtn.addActionListener( this );
        MBtn.setForeground( Color. black );
        MBtn.setBackground( mystery );

        NBtn.setBounds( 10, 220, 70, 40 );
        this.add (NBtn);
        NBtn.addActionListener( this );
        NBtn.setForeground( Color. white );
        NBtn.setBackground( Color. black );

        DBtn.setBounds( 80, 220, 70, 40 );
        this.add (DBtn);
        DBtn.addActionListener( this );
        DBtn.setForeground( Color. white );
        DBtn.setBackground( myBrown );

        CircleBtn.setBounds( 10, 450, 70, 40 );
        this.add (CircleBtn);
        CircleBtn.addActionListener( this );

        SquareBtn.setBounds( 10, 490, 70, 40 );
        this.add (SquareBtn);
        SquareBtn.addActionListener( this );

        RectBtn.setBounds( 80, 450, 70, 40 );
        this.add (RectBtn);
        RectBtn.addActionListener( this );

        LineBtn.setBounds( 80, 490, 70, 40 );
        this.add (LineBtn);
        LineBtn.addActionListener( this );

        penBtn.setBounds( 10, 530, 70, 40 );
        this.add (penBtn);
        penBtn.addActionListener( this );

        eraserBtn.setBounds( 80, 530, 70, 40 );
        this.add (eraserBtn);
        eraserBtn.addActionListener( this );

        undoBtn.setBounds( 10, 570, 70, 40 );
        this.add (undoBtn);
        undoBtn.addActionListener( this );

        ResetBtn.setBounds( 10, 620, 70, 40 );
        this.add (ResetBtn);
        ResetBtn.addActionListener( this );
    }

    public void paint (Graphics g)
    {
        g.setColor(Color. red);
        g.fillRect(0,0, 200, 1000);
        g.setColor(Color. black);
        g.drawString("Enter width", 5, 320);
        g.drawString("Enter height", 5, 370);
        g.drawString("Choose a color", 30, 30);
        g.drawString("Pick a shape", 5, 440);

        if(color=='R')
            g.setColor(Color.red);
        if(color=='B')
            g.setColor(Color.blue);
        if(color=='Y')
            g.setColor(Color.yellow);
        if(color=='G')
            g.setColor(Color.green);
        if(color=='W')
            g.setColor(Color.white);
        if(color=='O')
            g.setColor(myOrange);
        if(color=='M')
            g.setColor(mystery);
        if(color=='P')
            g.setColor(myPurple);
        if(color=='N')
            g.setColor(Color.black);
        if(color=='D')
            g.setColor(myBrown);

        if(shape=='C')
            g.fillOval(x,y,width, height);
        if(shape=='T')
            g.fillRect(x,y,width, height);
        if(shape=='S')
            g.fillRect(x,y,width, width);
        if(shape=='L')
            g.drawLine(x1,y1,x2,y2);
        if(penOn)
            g.fillOval(x,y,20,20);
        if(eraserOn)
            g.fillOval(x,y,25,25);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(penBtn == e.getSource())
        {
            penOn=!penOn;
        }

        if(eraserBtn == e.getSource())
        {
            eraserOn=!eraserOn;
            color='W';
            penOn=eraserOn;
        }

        if(e.getSource() == SquareBtn )
        {
            shape='S';
        }

        if(e.getSource() == RectBtn )
        {
            shape='T';
        }

        if(e.getSource() == CircleBtn )
        {
            shape='C';
        }

        if(e.getSource() == LineBtn )
        {
            shape='L';
        }

        if(e.getSource() == RBtn )
        {
            color='R';
        }   

        if(e.getSource() == BBtn )
        {
            color='B';
        }   

        if(e.getSource() == YBtn )
        {
            color='Y';
        }

        if(e.getSource() == OBtn )
        {
            color='O';
        }

        if(e.getSource() == GBtn )
        {
            color='G';
        }

        if(e.getSource() == WBtn )
        {
            color='W';   
        }

        if(e.getSource() == PBtn )
        {
            color='P';
        }

        if(e.getSource() == MBtn )
        {
            color='M';
        }

        if(e.getSource() == NBtn )
        {
            color='N';
        }

        if(e.getSource() == DBtn )
        {
            color='D';
        }

        if(e.getSource() == undoBtn )
        {
            color='W';
            Graphics g=getGraphics();
            paint(g);
        }

        if(e.getSource() ==ResetBtn )
        {
            widthTF.setText("");
            heightTF.setText("");
            color='x';
            shape='x';
            repaint();
        }
    }

    public void mouseClicked( MouseEvent e )
    {
        x=e.getX();
        y=e.getY();

        input=widthTF.getText();
        width=Integer.parseInt(input);
        input=heightTF.getText();
        height=Integer.parseInt(input);

        Graphics g=getGraphics();
        paint(g);
    }

    public void mousePressed(MouseEvent e){
        x1=e.getX();
        y1=e.getY();
    }

    public void mouseReleased(MouseEvent e){
        if(shape=='L')
        {
            x2=e.getX();
            y2=e.getY();
            Graphics g=getGraphics();
            paint(g);
        }
    }

    public void mouseDragged(MouseEvent e){
        if(penOn)
        {
            shape='x';
            x=e.getX();
            y=e.getY();
            Graphics g=getGraphics();
            paint(g);
        }
    }

    public void mouseMoved(MouseEvent e)
    {
        x=e.getX();
        y=e.getY();
    }

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}

}