import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*A simple applet to get the volume of a box with length, height, and width
   Amanda Ramos Sept. 27 2012
*/
    
public class boxVolume extends Applet implements ActionListener
{
    TextField lengthTF= new TextField();
    TextField widthTF= new TextField();
    TextField heightTF= new TextField();
    
    Button answerBtn= new Button ("Get answer");
    Button clearBtn= new Button ("Clear");
    
    Font myFont= new Font( "Papyrus" ,1, 16 );
    Color myPurple=new Color( 200, 1, 200 );
    
    String lengthInput="";
    String widthInput="";
    String heightInput="";
    String answer="";
    String output="";
    
    double length;
    double width;
    double height;
    double totalVolume;
    
    public void init()
    {
        this.setLayout(null);

        lengthTF.setBounds(50, 100, 100, 30 );
        this.add(lengthTF);
        
        widthTF.setBounds(50, 200, 100, 30 );
        this.add(widthTF);
        
        heightTF.setBounds(50, 300, 100, 30 );
        this.add(heightTF);
        
        answerBtn.setBounds( 100, 500, 100, 50 );
        this.add (answerBtn);
        answerBtn.addActionListener( this );
        
        clearBtn.setBounds( 100, 580, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
    }

    public void actionPerformed(ActionEvent e)
    {
       if(e.getSource()== answerBtn)
       {
           lengthInput = lengthTF.getText();
           length = Double.parseDouble(lengthInput);
           
           widthInput = widthTF.getText();
           width = Double.parseDouble(widthInput);
           
           heightInput = heightTF.getText();
           height = Double.parseDouble(heightInput);
           
           totalVolume= length*width*height;
           answer= "The box has a volume of "+ totalVolume+ " cubed units.";
        } 
       if(e.getSource()== clearBtn)  
       {
          lengthTF.setText("");
          widthTF.setText("");
          heightTF.setText("");
          answer="";
          output="";
       }
        repaint();
    }
    public void paint( Graphics g )
    {
      g.setColor( Color. black);
      g.fillRect( 0, 0, 2000, 1000 );
      g.setColor( myPurple);
      g.setFont( myFont);
      g.drawString("DETEMINES THE VOLUME OF A BOX", 400, 50 );
      g.drawString( "Enter the length", 175, 110 );
      g.drawString( "Enter the width", 175, 210 );
      g.drawString( "Enter the height", 175, 310 );
      g.drawString( answer, 400, 400 );
    }
}
