
import java.awt.*;
import java.applet.Applet;

/*Simple Apple to test fonts
  Soren Foxcat  September 13,2012
 */

public class fonts extends Applet
{
        Font myFont= new Font( "Papyrus" ,1, 30 );
        
           public void paint( Graphics g )
        {
            g.setFont( myFont );
            g.drawString ( "I'm awesome! AWW YEAH! " , 200, 200 );
        }
}
