
import java.awt.*;
import java.applet.Applet;

/*Simple applet, graded program, make squares and circles 
  Amanda Ramos  September 11, 2012
 */

public class testApplet extends Applet
{
        public void paint( Graphics g )
        {
            g.setColor( Color. red );    
            g.drawRect( 900, 30, 300, 50 );
            g.drawRect( 1050, 560, 50, 50 );
            g.setColor( Color. blue );
            g.fillOval(  460, 300, 60, 60 );
        }
}