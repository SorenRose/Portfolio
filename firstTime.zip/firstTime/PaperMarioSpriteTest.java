import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make Mario move
Amanda Ramos Dec. 20, 2012
 */

public class PaperMarioSpriteTest extends Applet implements Runnable, KeyListener

{

    Thread main= new Thread(this);
    Font myFont= new Font( "Papyrus" ,1, 20 );
    Image pictureArray[]= new Image[6];
    int marioX=200, marioY=400;
    int shellX=marioX+60 , shellY=marioY+60;
    boolean stand=true, right=false, left=false, jump=false, shoot=false;
    int frameCt=0;
    int jumpCt=0;
    Image shell;

    public void init()
    {
        this.setLayout(null);
        this.addKeyListener(this);
        resize(1300, 756);

        pictureArray[1]=getImage( this.getCodeBase(),"walk mario.png");
        //gotten from Google Images, search sprites

        pictureArray[0]=getImage( this.getCodeBase(),"stand mario.png");
        //gotten from Google Images, search sprites

        pictureArray[2]=getImage( this.getCodeBase(),"jump mario.png");
        //gotten from Google Images, search sprites

        pictureArray[3]=getImage( this.getCodeBase(),"shock mario.png");
        //gotten from Google Images, search sprites

        pictureArray[4]=getImage( this.getCodeBase(),"fantastic mario.png");
        //gotten from Google Images, search sprites

        pictureArray[5]=getImage( this.getCodeBase(),"throw mario.png");
        //gotten from Google Images, search sprites

        shell=this.getImage( this.getCodeBase(),"shell.png");
        //gotten from Google Images, search for paper mario shell

        main.start();
    }

    public void run()
    {
        while(true)
        {
            if(right)
                marioX=marioX+10;
            if(left)
                marioX=marioX-10;

            repaint();
            try
            {main.sleep(100);}
            catch(Exception e){}
            frameCt++;
            if(frameCt==2)
                frameCt=0;

            if(jump)
            {
                jumpCt++;
                marioY=marioY+jumpCt;

                if(jumpCt==14)
                {
                    jump=false;
                    stand=true;
                    
                }
            }
        }
    }

    public void paint (Graphics g)
    {
        g.drawLine(0, 500, 1300, 500);
        if(stand)
            g.drawImage(pictureArray[0], marioX, marioY, 100, 130, this);
        if(right)
        { 
            g.drawImage(pictureArray[frameCt], marioX, marioY, 100, 130, this);
        }
        if(left)
        { 
            g.drawImage(pictureArray[frameCt], marioX+100, marioY, -100, 130, this);
        }
        if(jump)
        { 
            g.drawImage(pictureArray[2], marioX, marioY, 100, 130, this);
        }
        if(shoot)
        { 
            g.drawImage(pictureArray[5], marioX, marioY, 100, 130, this);
            g.drawImage(shell, shellX, shellY,50, 50, this);
        }
    }

    public void keyPressed(KeyEvent e)
    {
        int code=e.getKeyCode();

        if(code==e.VK_RIGHT)
        {
            marioX=marioX+10;
            right=true;
            stand=false;
            left=false;
            jump=false;
        }
        if(code==e.VK_LEFT)
        {
            marioX=marioX-10;
            right=false;
            stand=false;
            left=true;
            jump=false;
        }
        if(code==e.VK_UP&&jump==false)
        {
            jumpCt=-15;
            jump=true;
            if( marioY<400)
            { right=false;
              left=false;
              stand=false;
              
            }
        }
        if(code==e.VK_SPACE)
        {
            shoot=true;
            right=false;
            stand=false;
            left=false;
            jump=false;
            shellX=shellX+15;
        }
    }

    public void keyReleased(KeyEvent e)
    {

        if(jump==false)
        {
            stand=true;
            right=false;
            left=false;
        }
    }

    public void keyTyped(KeyEvent e){}

}