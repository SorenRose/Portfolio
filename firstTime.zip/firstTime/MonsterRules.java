import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet make a tutorial for Monster Attack
Amanda Ramos Dec. 3, 2012
 */

public class MonsterRules extends Applet implements ActionListener, AppletStub

{
    Random rand= new Random ();
    Button nextBtn= new Button ("Next");
    Button backBtn= new Button ("Back");
    Button endBtn= new Button ("End");
    Font myFont= new Font( "Papyrus" ,1, 27 );
    Applet appletToLoad= new Applet();

    int pageCt=0;
    String output="";

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);

        resize(1300,700);

        nextBtn.setBounds( 500, 600, 100, 40 );
        this.add (nextBtn);
        nextBtn.addActionListener( this );

        backBtn.setBounds( 350, 600, 100, 40 );
        this.add (backBtn);
        backBtn.addActionListener( this );

        endBtn.setBounds( 200, 600, 100, 40 );
        this.add (endBtn);
        endBtn.addActionListener( this );

    }

    public void paint (Graphics g)
    {
        backBtn.setForeground( Color. blue );
        backBtn.setBackground( Color. yellow );
        endBtn.setForeground( Color. blue );
        endBtn.setBackground( Color. yellow );
        nextBtn.setForeground( Color. blue );
        nextBtn.setBackground( Color. yellow );
        g.setColor(Color. red);
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. black);
        g.setFont ( myFont );
        if(pageCt==0)
        {
            g.drawString("Welcome to this Monster Attack tutorial, press next to continue.", 300, 300);
            g.drawString("To go back to the game, press end to go back.", 300, 350);
        }
        if(pageCt==1)
        {
            g.drawString("Monster Attack! Play as the warrior to slay evil and banish the monsters from the", 10, 30);
            g.drawString("Earth! To attack click on the monster to go to the next one. Remember: the monsters", 10, 70);
            g.drawString("will get smaller and faster so try to see if you can slay them all! You will be timed ", 10, 110);
            g.drawString("on how long you take to get rid of them all so be quick and try to kill them all! ", 10, 150);
            g.drawString("see if you can get them in less than 60 seconds! ", 10, 150);
            nextBtn.setVisible(false);
        }
        
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
            pageCt= pageCt+1;
            nextBtn.setVisible(true);
            if(pageCt==3)
            {
                nextBtn.setVisible(false);
            }
        }
        if(e.getSource() == endBtn )
        {
            {
                nextBtn.setVisible(false);
                endBtn.setVisible(false);
                backBtn.setVisible(false);
            }
            try
            {
                Class applet2=Class.forName("MonsterAttack");
                appletToLoad=(Applet)applet2.newInstance();
                appletToLoad.setStub(this);
                add(appletToLoad);
                appletToLoad.init();
                appletToLoad.start();

            }
            catch (Exception p){}
        }
        if(e.getSource() == backBtn )
        {
            pageCt= pageCt-1;
            if(pageCt==0)
            {
                backBtn.setVisible(false);
            }
            else if( pageCt==1)
            {  
                backBtn.setVisible(true);
            }
            else if( pageCt==2)
            {  
                backBtn.setVisible(true);
            }
            else if(pageCt==3)
                backBtn.setVisible(false);
        }  
        repaint();
    }
}