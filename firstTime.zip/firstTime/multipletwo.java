import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make a multiple choise applet
  Amanda Ramos Oct. 16, 2012
 */

public class multipletwo extends Applet implements ActionListener

{
    Random rand= new Random ();
    Button oneBtn= new Button ("A");
    Button twoBtn= new Button ("B");
    Button threeBtn= new Button ("C");
    Button fourBtn= new Button ("D");
    Button fiveBtn= new Button ("50/50");
    Font myFont= new Font( "Papyrus" ,1, 30 );
    
    int questionCt=0;
    int correctCt=0;
    String output="";
    Button nextBtn= new Button ("Next");
    
    public void init()
    {
        this.setLayout(null);
        
        oneBtn.setVisible(false);
        twoBtn.setVisible(false);
        threeBtn.setVisible(false);
        fourBtn.setVisible(false);
        
        oneBtn.setBounds( 110, 350, 30, 30 );
        this.add (oneBtn);
        oneBtn.addActionListener( this );
        
        twoBtn.setBounds( 550, 350, 30, 30 );
        this.add (twoBtn);
        twoBtn.addActionListener( this );
        
        threeBtn.setBounds( 110, 450, 30, 30 );
        this.add (threeBtn);
        threeBtn.addActionListener( this );
        
        fourBtn.setBounds( 550, 450, 30, 30 );
        this.add (fourBtn);
        fourBtn.addActionListener( this );
        
        nextBtn.setBounds(425, 500, 80, 30);
        this.add (nextBtn);
        nextBtn.addActionListener(this);
        
        fiveBtn.setBounds(325, 500, 80, 30);
        this.add (fiveBtn);
        fiveBtn.addActionListener(this);
    }
    
    public void paint (Graphics g)
    {
        oneBtn.setForeground( Color. blue );
        oneBtn.setBackground( Color. yellow );
        twoBtn.setForeground( Color. blue );
        twoBtn.setBackground( Color. yellow );
        threeBtn.setForeground( Color. blue );
        threeBtn.setBackground( Color. yellow );
        fourBtn.setForeground( Color. blue );
        fourBtn.setBackground( Color. yellow );
        nextBtn.setForeground( Color. blue );
        nextBtn.setBackground( Color. yellow );
        fiveBtn.setForeground( Color. blue );
        fiveBtn.setBackground( Color. yellow );
        g.setColor(Color. red);
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. black);
        g.setFont ( myFont );
        if(questionCt==0)
        {
            g.drawString("Welcome to my multiple choice quiz. Click next to continue.", 300, 300);
        }
        if (questionCt==1)
        { 
            g.drawString("Which character's game is based on different legends?",200, 70 );
            g.drawString("Mario",138, 370 );
            g.drawString("Chibiterasu",580, 370 );
            g.drawString("Samus",138, 470 );
            g.drawString("Link",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==2)
        { 
            g.drawString("Which character is a alien bounty hunter?",200, 70 );
            g.drawString("Marth",138, 370 );
            g.drawString("Olimar",580, 370 );
            g.drawString("Pikachu",138, 470 );
            g.drawString("Samus",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==3)
        { 
            g.drawString("When was the original Super Mario Bros. released?",200, 70 );
            g.drawString("1985",138, 370 );
            g.drawString("1970",580, 370 );
            g.drawString("2012",138, 470 );
            g.drawString("1991",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==4)
        { 
            g.drawString("What game was a turn of the way video games were made in Nintendo?",200, 70 );
            g.drawString("Legend of Zelda",138, 370 );
            g.drawString("Super Mario Bros",580, 370 );
            g.drawString("Super Martio Galaxy",138, 470 );
            g.drawString("Super Mario 64",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==5)
        { 
            g.drawString("Which game was an outer space shooting game?",200, 70 );
            g.drawString("Metal Gear",138, 370 );
            g.drawString("Metroid",580, 370 );
            g.drawString("Star Fox",138, 470 );
            g.drawString("Sonic",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==6)
        { 
            g.drawString("Bonus! Which of these games will be relaesed on my Birthday?",200, 70 );
            g.drawString("ZombiU",138, 370 );
            g.drawString("Nintendo Land",580, 370 );
            g.drawString("Paper Mario Sticker Star",138, 470 );
            g.drawString("Super Mario Galaxy 2",580, 470 );
            g.drawString(output, 100, 250);
        }
        if (questionCt==7)
        { 
            g.drawString("Thank you so much for taking my quiz!",400, 100 );
            g.drawString("You got " + correctCt +" correct!", 400, 200);
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
             output=""; 
             questionCt= questionCt+1;
              oneBtn.setVisible(true);
              twoBtn.setVisible(true);
              threeBtn.setVisible(true);
              fourBtn.setVisible(true);
              nextBtn.setVisible(false);
             if(questionCt==7)
             {
             oneBtn.setVisible(false);
              twoBtn.setVisible(false);
              threeBtn.setVisible(false);
              fourBtn.setVisible(false);
              nextBtn.setVisible(false);
              fiveBtn.setVisible(false);
            }
        }
        if(e.getSource() == oneBtn )
        {
             oneBtn.setVisible(false);
             twoBtn.setVisible(false);
             threeBtn.setVisible(false);
             fourBtn.setVisible(false);
             nextBtn.setVisible(true); 
             if( questionCt==3)
            {  
                correctCt= correctCt+1;
                output="Correct!";
            }
             else if(questionCt==4)
            { 
                   correctCt= correctCt+1;
                output="Correct!";
            }
             else
                output="wrong";
        }
        if(e.getSource() == twoBtn )
        {
             oneBtn.setVisible(false);
             twoBtn.setVisible(false);
             threeBtn.setVisible(false);
             fourBtn.setVisible(false);
             nextBtn.setVisible(true); 
             if( questionCt==1)
            {  
                correctCt= correctCt+1;
                output="Correct!";
            }
             else
                output="wrong";
        }
        if(e.getSource() == threeBtn )
        {
             oneBtn.setVisible(false);
             twoBtn.setVisible(false);
             threeBtn.setVisible(false);
             fourBtn.setVisible(false);
             nextBtn.setVisible(true); 
             if( questionCt==5)
            {  
                correctCt= correctCt+1;
                output="Correct!";
            }
             else if(questionCt==6)
            {  
                correctCt= correctCt+1;
                output="Correct!";
            }
             else
                output="wrong";
        }
        if(e.getSource() == fourBtn )
        {
             oneBtn.setVisible(false);
             twoBtn.setVisible(false);
             threeBtn.setVisible(false);
             fourBtn.setVisible(false);
             nextBtn.setVisible(true);
             if( questionCt==2)
            {  
                correctCt= correctCt+1;
                output="Correct!";
            }
             else
                output="wrong";
        }
        if(e.getSource() == fiveBtn )
        {
             if(questionCt==1)
             {
             oneBtn.setVisible(false);
              twoBtn.setVisible(true);
              threeBtn.setVisible(true);
              fourBtn.setVisible(false);
            }
            if(questionCt==2)
             {
             oneBtn.setVisible(true);
              twoBtn.setVisible(false);
              threeBtn.setVisible(false);
              fourBtn.setVisible(true);
            }
            if(questionCt==3)
             {
             oneBtn.setVisible(true);
              twoBtn.setVisible(false);
              threeBtn.setVisible(true);
              fourBtn.setVisible(false);
            }
            if(questionCt==4)
             {
             oneBtn.setVisible(true);
              twoBtn.setVisible(true);
              threeBtn.setVisible(false);
              fourBtn.setVisible(false);
            }
            if(questionCt==5)
             {
             oneBtn.setVisible(false);
              twoBtn.setVisible(true);
              threeBtn.setVisible(true);
              fourBtn.setVisible(false);
            }
            if(questionCt==6)
             {
             oneBtn.setVisible(false);
              twoBtn.setVisible(false);
              threeBtn.setVisible(true);
              fourBtn.setVisible(true);
            }
           
        }
         repaint();
    }
}