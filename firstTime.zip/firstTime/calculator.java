import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*A simple applet to be a calculator
   Amanda Ramos Sept. 27 2012
*/
    
public class calculator extends Applet implements ActionListener
{
    TextField firstNumTF= new TextField();
    TextField secNumTF= new TextField();
    
    Button addBtn=new Button ("+");
    Button subBtn= new Button ("-");
    Button mulBtn= new Button ("*");
    Button divBtn= new Button ("/");                                                                                         
    Button clearBtn= new Button ("Clear");
    
    String firstNumInput="";
    String secNumInput="";
    String output="";
    
    double firstNum;
    double secNum;
    double answer;
    
    Font myFont= new Font( "Papyrus" ,1, 16 );
    Color myPurple=new Color( 200, 1, 200 );
    
    Image batman;
    
    public void init()
    {
        this.setLayout(null);

        batman=this.getImage(this.getCodeBase(), "batman.gif");
        //image gotten from http://www.yourlogoresources.com/batman-logo/
        
        firstNumTF.setBounds(50, 100, 100, 30 );
        this.add(firstNumTF);
        
        secNumTF.setBounds(50, 140, 100, 30 );
        this.add(secNumTF);
        
        addBtn.setBounds( 70, 300, 100, 50 );
        this.add (addBtn);
        addBtn.addActionListener( this );
        
        subBtn.setBounds( 70, 360, 100, 50 );
        this.add (subBtn);
        subBtn.addActionListener( this );
        
        mulBtn.setBounds( 70, 420, 100, 50 );
        this.add (mulBtn);
        mulBtn.addActionListener( this );
        
        divBtn.setBounds( 70, 480, 100, 50 );
        this.add (divBtn);
        divBtn.addActionListener( this );
        
        clearBtn.setBounds( 70, 540, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
    }

    public void actionPerformed(ActionEvent e)
    {
       if(e.getSource()== addBtn)  
       {
           firstNumInput = firstNumTF.getText();
           firstNum = Double.parseDouble(firstNumInput);
           
           secNumInput = secNumTF.getText();
           secNum = Double.parseDouble(secNumInput);
           
           answer= firstNum+secNum;
           output= firstNum + " + " +secNum + " = "+ answer;
        }
        if(e.getSource()== subBtn)  
       {
           firstNumInput = firstNumTF.getText();
           firstNum = Double.parseDouble(firstNumInput);
           
           secNumInput = secNumTF.getText();
           secNum = Double.parseDouble(secNumInput);
           
           answer= firstNum-secNum;
           output= firstNum + " - " +secNum + " = " +answer;
        }
        if(e.getSource()== mulBtn)  
       {
           firstNumInput = firstNumTF.getText();
           firstNum = Double.parseDouble(firstNumInput);
           
           secNumInput = secNumTF.getText();
           secNum = Double.parseDouble(secNumInput);
           
           answer= firstNum*secNum;
           output= firstNum + " * " +secNum + " = " +answer;
        }
        if(e.getSource()== divBtn)  
       {
           firstNumInput = firstNumTF.getText();
           firstNum = Double.parseDouble(firstNumInput);
           
           secNumInput = secNumTF.getText();
           secNum = Double.parseDouble(secNumInput);
           
           answer= firstNum/secNum;
           output= firstNum + " / " +secNum + " = " +answer;
        }
       if(e.getSource()== clearBtn)  
       {
          firstNumTF.setText("");
          secNumTF.setText("");
          output="";
       }
       repaint();
    }
    public void paint( Graphics g )
    {
    g.drawImage(batman, 0,0, 300, 300, this); 
    g.drawString( output, 400, 400 );
    addBtn.setFont( myFont );
    addBtn.setForeground( Color. yellow );
    addBtn.setBackground( Color. black );
    subBtn.setFont( myFont );
    subBtn.setForeground( Color. yellow );
    subBtn.setBackground( Color. black );
    mulBtn.setFont( myFont );
    mulBtn.setForeground( Color. yellow );
    mulBtn.setBackground( Color. black );
    divBtn.setFont( myFont );
    divBtn.setForeground( Color. yellow );
    divBtn.setBackground( Color. black );
    clearBtn.setFont( myFont );
    clearBtn.setForeground( Color. yellow );
    clearBtn.setBackground( Color. black );
    }
}
