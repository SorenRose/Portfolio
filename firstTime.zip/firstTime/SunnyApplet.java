
import java.awt.*;
import java.applet.Applet;

/*Simple applet, sunny program, make squares and circles 
  Amanda Ramos  September 11, 2012
 */

public class SunnyApplet extends Applet
{
        public void paint( Graphics g )
        {
            g.setColor( Color. yellow );
            g.fillOval( 400, 200, 200, 200 );
            g.setColor( Color. black );
            g.drawOval( 475, 320, 50, 50 );
            g.setColor( Color. yellow );
            g.fillRect( 470, 320, 60, 25 );
            g.setColor( Color. black );
            g.drawOval( 425, 225, 40, 40 );
            g.drawOval( 533, 225, 40, 40 );
            g.drawOval( 480, 229, 40, 40 );
            g.setColor( Color. yellow );
            g.fillRect( 425, 240, 150, 40 );
            g.setColor( Color. black );
            g.fillOval( 450, 235, 45, 45 );
            g.fillOval( 510, 235, 45, 45 );
        }
}