import java.awt.*;
import java.applet.Applet;

/*Simple Applet to output stuff
  Mr.Luciano  September 4,2012
 */

public class second extends Applet
{
        public void paint( Graphics g )
        {
                g.setColor( Color. red );
                g.fillOval( 200, 200, 200, 200 );
                g.fillOval( 140, 118, 120, 120 );
                g.fillOval( 340, 118, 120, 120 );
        }
}