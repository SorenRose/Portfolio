import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*An applet to get the area of a rectangle
  Amanda Ramos  September 20,2012
 */

public class rectangleArea extends Applet implements ActionListener
{
    TextField lengthTF= new TextField ();
    TextField widthTF= new TextField ();
    Button areaBtn= new Button ("Area");
    Button perimeterBtn= new Button ("Perimeter");
    String input, answer="";
    String input1, output="";
    double length, width, area, perimeter;
    Font myFont= new Font( "Papyrus" ,3, 29 );
    Font font20= new Font( "Papyrus" ,1, 20 );
    Color myPurple=new Color( 200, 1, 200 );
    
    public void init()
    {
        this.setLayout(null);

       lengthTF.setBounds( 100, 100, 150, 40 );
       this.add( lengthTF );
       widthTF.setBounds ( 100, 200, 150, 40 );
       this.add( widthTF );
       areaBtn.setBounds( 150, 300, 90, 50 );
       this.add (areaBtn );
       areaBtn.addActionListener (this);
       perimeterBtn.setBounds( 300, 300, 90, 50 );
       this.add (perimeterBtn );
       perimeterBtn.addActionListener (this);
    }

    public void actionPerformed(ActionEvent e)
    {
        input= lengthTF.getText();
        length= Double.parseDouble( input );
        input= widthTF.getText();
        width= Double.parseDouble( input );
        if(e.getSource()==areaBtn)
       {
           area= length*width;
        answer= "Area of a rectangle with a length "+ length +" and "+ width +" width is "+ area +" sq. units ";
    }
        input1=lengthTF.getText();
        length= Double.parseDouble( input1 );
        input1= widthTF.getText();
        width= Double.parseDouble( input1 );
    if(e.getSource()==perimeterBtn)
        {
        perimeter= length+ length+width+width;
        output="Peremeter of a rectangle is " + perimeter + " units.";
    }
        repaint ();
    }

    public void paint( Graphics g )
    {
        g.setColor( myPurple);
        g.setFont( myFont);
        g.drawString("Amazing Rectangle Area Finder", 500, 50);
        g.setFont( font20 ); 
        g.drawString("Enter the length of the rectangle", 300, 130 );
        g.drawString("Enter the width of the rectangle",  300, 230 );
        g.fillRect( 600, 500, (int)width, (int)length );
        g.drawString( answer, 150, 400 );
        g.drawString( output, 150, 500 );
       
    }
}
