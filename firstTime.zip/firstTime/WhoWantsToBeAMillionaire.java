import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make Hang man
Amanda Ramos Jan. 2, 2013
 */

public class WhoWantsToBeAMillionaire extends Applet implements ActionListener

{
    Random rand= new Random ();
    int randNum= 3;
    Font myFont= new Font( "Papyrus" ,1, 20 );
    Button aBtn= new Button("A");
    Button bBtn= new Button("B");
    Button cBtn= new Button("C");
    Button dBtn= new Button("D");
    Button walkBtn= new Button("Walk Away");
    String questions[]= new String[8];
    String aAnswers[]= new String[8];
    String bAnswers[]= new String[8];
    String cAnswers[]= new String[8];
    String dAnswers[]= new String[8];
    String output="";
    int questionCt=0;
    String[] money= {"$1,000", "$2,000", "$5,000", "$10,000", "$25,000", "$100,000", "$500,000", "$1,000,000"};
    char [] answers={'C','B','B','D','A','C','A','D'};
    char choice='z';
    Button halfBtn= new Button ("50/50");
    Button phoneBtn= new Button ("Phone a Friend");
    Button AudianceBtn= new Button ("Ask the audience");
    Boolean lost=false;
    Boolean walk=false;

    public void init()
    {
        this.setLayout(null);
        resize(1300, 756);

        questions[0]="Nintendo's first game counsel was called what?";
        aAnswers[0]="Wii";
        bAnswers[0]="PlayStation";
        cAnswers[0]="NES";
        dAnswers[0]="X Box";
        questions[1]="What character is Nintendo first hit?";
        aAnswers[1]="Kirby";
        bAnswers[1]="Mario";
        cAnswers[1]="Donkey Kong";
        dAnswers[1]="Luigi";
        questions[2]="Legend of Zelda's main hero is called what?";
        aAnswers[2]="Zelda";
        bAnswers[2]="Link";
        cAnswers[2]="Ganondorf";
        dAnswers[2]="Kafei";
        questions[3]="The series of Star Fox was also known as...";
        aAnswers[3]="Battle in Space";
        bAnswers[3]="Andross's Revenge";
        cAnswers[3]="Planet Venom";
        dAnswers[3]="Lylat Wars";
        questions[4]="The name Nintendo can be roughly translated to what?";
        aAnswers[4]="Leave luck to heaven";
        bAnswers[4]="No one does what we do";
        cAnswers[4]="Now you're playing with power";
        dAnswers[4]="Play and have fun";
        questions[5]="In Japan what is Legend of Zelda also known as?";
        aAnswers[5]="Link's Adventure";
        bAnswers[5]="The Hyrule Adventure";
        cAnswers[5]="The Hyrule Fantasy";
        dAnswers[5]="Zelda's History";
        questions[6]="Nintendo started as what?";
        aAnswers[6]="A card company";
        bAnswers[6]="A toy company";
        cAnswers[6]="A video game company";
        dAnswers[6]="A sport company";
        questions[7]="Who is the president of Nintendo right now?";
        aAnswers[7]="Satoru Shibata";
        bAnswers[7]="Tatsumi Kimishma";
        cAnswers[7]="Conrad Abbott";
        dAnswers[7]="Satoru Iwata";

        aBtn.setBounds( 80, 500, 30, 30 );
        this.add (aBtn);
        aBtn.addActionListener( this );
        aBtn.setForeground( Color. white );
        aBtn.setBackground( Color. black );

        bBtn.setBounds( 500, 500, 30, 30 );
        this.add (bBtn);
        bBtn.addActionListener( this );
        bBtn.setForeground( Color. white );
        bBtn.setBackground( Color. black );

        cBtn.setBounds( 80, 600, 30, 30 );
        this.add (cBtn);
        cBtn.addActionListener( this );
        cBtn.setForeground( Color. white );
        cBtn.setBackground( Color. black );

        dBtn.setBounds( 500, 600, 30, 30 );
        this.add (dBtn);
        dBtn.addActionListener( this );
        dBtn.setForeground( Color. white );
        dBtn.setBackground( Color. black );

        walkBtn.setBounds( 500, 670, 60, 30 );
        this.add (walkBtn);
        walkBtn.addActionListener( this );
        walkBtn.setForeground( Color. white );
        walkBtn.setBackground( Color. black );

        halfBtn.setBounds( 400, 670, 60, 30 );
        this.add (halfBtn);
        halfBtn.addActionListener( this );
        halfBtn.setForeground( Color. white );
        halfBtn.setBackground( Color. black );
        
        phoneBtn.setBounds( 280, 670, 100, 30 );
        this.add (phoneBtn);
        phoneBtn.addActionListener( this );
        phoneBtn.setForeground( Color. white );
        phoneBtn.setBackground( Color. black );

    }

    public void paint (Graphics g)
    {
        g.setFont(myFont);
        g.drawString(output, 200, 240);
        
        if(questionCt==8)
        { 
            g.drawString("you've won $1,000,000!!!", 200,200);
            aBtn.setVisible(false);
            bBtn.setVisible(false);
            cBtn.setVisible(false);
            dBtn.setVisible(false);
            walkBtn.setVisible(false);
            halfBtn.setVisible(false);
            phoneBtn.setVisible(false);
        }
        else if(walk==true)
        {
            aBtn.setVisible(false);
            bBtn.setVisible(false);
            cBtn.setVisible(false);
            dBtn.setVisible(false);
            walkBtn.setVisible(false);
            halfBtn.setVisible(false);
            phoneBtn.setVisible(false);
            g.setColor(Color. white);
            g.drawString(questions[questionCt], 200, 200);
            g.drawString(aAnswers[questionCt], 120, 520);
            g.drawString(bAnswers[questionCt], 540, 520);
            g.drawString(cAnswers[questionCt], 120, 620);
            g.drawString(dAnswers[questionCt], 540, 620);
            g.setColor(Color. black);
            g.drawString("You've won "+money[questionCt-1],200,200);
        }
        else if(lost==true&&walk==false)
        {
            aBtn.setVisible(false);
            bBtn.setVisible(false);
            cBtn.setVisible(false);
            dBtn.setVisible(false);
            walkBtn.setVisible(false);
            halfBtn.setVisible(false);
            phoneBtn.setVisible(false);
            if(questionCt<4)
            {  
                g.setColor(Color. white);
                g.drawString(questions[questionCt], 200, 200);
                g.drawString(aAnswers[questionCt], 120, 520);
                g.drawString(bAnswers[questionCt], 540, 520);
                g.drawString(cAnswers[questionCt], 120, 620);
                g.drawString(dAnswers[questionCt], 540, 620);
                g.setColor(Color. black);
                g.drawString("You lost", 200, 200);
            }
            else if(questionCt>3&&questionCt<7)  
            {
                g.setColor(Color. white);
                g.drawString(questions[questionCt], 200, 200);
                g.drawString(aAnswers[questionCt], 120, 520);
                g.drawString(bAnswers[questionCt], 540, 520);
                g.drawString(cAnswers[questionCt], 120, 620);
                g.drawString(dAnswers[questionCt], 540, 620);
                g.setColor(Color. black);
                g.drawString("You win $10,000", 200, 200);
            }
        }
        else
        {
            g.drawString(questions[questionCt], 200, 200);
            g.drawString(aAnswers[questionCt], 120, 520);
            g.drawString(bAnswers[questionCt], 540, 520);
            g.drawString(cAnswers[questionCt], 120, 620);
            g.drawString(dAnswers[questionCt], 540, 620);
        }

        for(int place=0; place<8; place++)
        {
            if(place==questionCt)
                g.setColor(Color. green);
            else 
                g.setColor(Color. blue);
            g.drawString(money[place], 1000, 500-50*place);
        }

    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==aBtn)
        {
            choice='A';
            output="";
        }
        if(e.getSource()==bBtn)
        {
            choice='B';
            output="";
        }
        if(e.getSource()==cBtn)
        {
            choice='C';
            output="";
        }
        if(e.getSource()==dBtn)
        {
            choice='D';
            output="";
        }
        if(e.getSource()==walkBtn)
        {
            walk=true;
            lost=false;
        }
        if(e.getSource()==halfBtn)
        {
            halfBtn.setVisible(false);
            if(answers[questionCt]=='A')
            {
                bBtn.setVisible(false);
                cBtn.setVisible(false);
            }
            if(answers[questionCt]=='B')
            {
                cBtn.setVisible(false);
                dBtn.setVisible(false);
            }
            if(answers[questionCt]=='C')
            {
                bBtn.setVisible(false);
                aBtn.setVisible(false);
            }
            if(answers[questionCt]=='D')
            {
                cBtn.setVisible(false);
                aBtn.setVisible(false);
            }
        }

        else if(choice==answers[questionCt])
        { 
            questionCt++;
            aBtn.setVisible(true);
            bBtn.setVisible(true);
            cBtn.setVisible(true);
            dBtn.setVisible(true);
        }
        else
            lost=true;
        if(e.getSource()==phoneBtn)
        {
            phoneBtn.setVisible(false);
            randNum=rand.nextInt(3);
            lost=false;
            walk=false;
            if(randNum<2)
            output="Your friend says "+ answers[questionCt];
            else
            output="Your friend says C";
        } 
        
        repaint();    
    }

}