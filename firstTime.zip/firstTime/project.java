import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

/*An applet to get words after typing in the textfield and press button
  Amanda Ramos  September 19,2012
 */

public class project extends Applet implements ActionListener
{
    String name="";
    String lastName="";
    Button nameBtn=new Button ("Get Word");
    TextField nameTF= new TextField();
    TextField lastNameTF= new TextField();
    Font font40= new Font( "Papyrus", 1, 50);
    Font font18= new Font( "Ariel", 1, 18);

    public void init()
    {
        this.setLayout(null);

        nameBtn.setBounds( 660, 600, 75, 40 );
        nameBtn.addActionListener(this);
        this.add(nameBtn);

        lastNameTF.setBounds( 1050, 600, 150, 40 );
        nameTF.setBounds( 500, 600, 150, 40 );
        this.add(nameTF);
        this.add(lastNameTF);
    }

    public void actionPerformed(ActionEvent e)
    {
        name= nameTF.getText();
        lastName=lastNameTF.getText();
        repaint();
    }

    public void paint( Graphics g )
    {
        g.setFont( font18 );
        g.drawString( "Type a word under here" , 500, 590 );
        g.drawString( "Type another word here", 1050, 590 );
        g.setFont( font40 );
        g.setColor( Color. red);
        g.drawString( name, 600, 300 );
        g.setColor( Color.blue );
        g.drawString( lastName, 600, 100 );
    }
}
