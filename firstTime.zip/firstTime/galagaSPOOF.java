import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make a game of Galaga
Amanda Ramos Dec. 11, 2012
 */

public class galagaSPOOF extends Applet implements Runnable, KeyListener, MouseListener

{

    Thread main= new Thread(this);
    Font myFont= new Font( "Papyrus" ,1, 20 );
    int Shipx=500;
    int Shipy= 500;
    int enemyX= 300;
    int enemyY= 300;
    int enemy2X= 200;
    int enemy2Y= 200;
    int enemy3X= 100;
    int enemy3Y= 100;
    int enemy4X= 400;
    int enemy4Y= 400;
    int xChange= 7;
    int yChange= 8;
    int xChange2= 9;
    int yChange2= 7;
    int xChange3= 5;
    int yChange3= 10;
    int xChange4= 12;
    int yChange4= 4;
    int Shooty= -500;
    int Shootx=Shipx+5;
    int Blasty= enemyY;
    int Blastx=enemyX+20;
    int Blast2y= enemy2Y;
    int Blast2x=enemy2X+20;
    int Blast3y= enemy3Y;
    int Blast3x=enemy3X+20;
    int Blast4y= enemy4Y;
    int Blast4x=enemy4X+20;
    Image galaga;
    Image enemy1;
    Image enemy2;
    Image enemy3;
    Image enemy4;
    Image space;
    Image buffer;
    Graphics bufferG;
    int hitCt=0;
    int pageCt=1;
    int lifeCt=5;

    public void init()
    {
        this.setLayout(null);
        this.addKeyListener(this);
        this.addMouseListener(this);
        resize(1300, 756);
        buffer=createImage(this.getWidth(),this.getHeight());
        bufferG= buffer.getGraphics();

        galaga=this.getImage( this.getCodeBase(),"galaga.png");
        //gotten from Google Images, search for Galaga

        enemy1=this.getImage( this.getCodeBase(),"enemy1.png");
        //gotten from Google Images, search for Galaga enemy

        enemy2=this.getImage( this.getCodeBase(),"enemy2.png");
        //gotten from Google Images, search for Galaga enemy

        enemy3=this.getImage( this.getCodeBase(),"enemy3.png");
        //gotten from Google Images, search for Galaga enemy

        enemy4=this.getImage( this.getCodeBase(),"enemy4.png");
        //gotten from Google Images, search for Galaga enemy

        space=this.getImage( this.getCodeBase(),"space.jpg");
        //gotten from Google Images, search for outer space
    }

    public void run()
    {
        do
        {            
            Rectangle ShipRect= new Rectangle(Shipx, Shipy, 155, 145);
            Rectangle alienRect= new Rectangle(enemyX, enemyY, 30, 70);
            Rectangle alien2Rect= new Rectangle(enemy2X, enemy2Y, 90, 130);
            Rectangle alien3Rect= new Rectangle(enemy3X, enemy3Y, 70, 100);
            Rectangle alien4Rect= new Rectangle(enemy4X, enemy4Y, 50, 80);
            Rectangle ShootRect= new Rectangle(Shootx, Shooty, 5, 10);
            Rectangle BlastRect= new Rectangle(Blastx, Blasty, 5, 10);
            Rectangle Blast2Rect= new Rectangle(Blast2x, Blast2y, 5, 10);
            Rectangle Blast3Rect= new Rectangle(Blast3x, Blast3y, 5, 10);
            Rectangle Blast4Rect= new Rectangle(Blast4x, Blast4y, 5, 10);
            enemyX=enemyX+xChange;
            enemyY=enemyY-yChange;
            enemy2X=enemy2X+xChange2;
            enemy2Y=enemy2Y-yChange2;
            enemy3X=enemy3X+xChange3;
            enemy3Y=enemy3Y-yChange3;
            enemy4X=enemy4X+xChange4;
            enemy4Y=enemy4Y-yChange4;
            if(Blasty>700)
            {
                Blasty=enemyY+16;
                Blastx=enemyX+5;
            }
            if(Blast2y>700)
            {
                Blast2y=enemy2Y+17;
                Blast2x=enemy2X+5;
            }
            if(Blast3y>700)
            {
                Blast3y=enemy3Y+18;
                Blast3x=enemy3X+5;
            }
            if(Blast4y>700)
            {
                Blast4y=enemy4Y+20;
                Blast4x=enemy4X+5;
            }
            Blasty=Blasty+16;
            Blast2y=Blast2y+17;
            Blast3y=Blast3y+18;
            Blast4y=Blast4y+20;
            Shooty=Shooty-25;

            repaint();
            try
            {main.sleep(20);}
            catch(Exception e){}
            if(enemyX<0||enemyX>1200)
                xChange=-1*xChange;
            if(enemyY<5||enemyY>400)
                yChange=-1*yChange;
            if(enemy2X<0||enemy2X>1200)
                xChange2=-1*xChange2;
            if(enemy2Y<5||enemy2Y>400)
                yChange2=-1*yChange2;
            if(enemy3X<0||enemy3X>1200)
                xChange3=-1*xChange3;
            if(enemy3Y<5||enemy3Y>400)
                yChange3=-1*yChange3;
            if(enemy4X<0||enemy4X>1200)
                xChange4=-1*xChange4;
            if(enemy4Y<5||enemy4Y>400)
                yChange4=-1*yChange4;
            if(Blasty>800)   
                Blasty=800;
                if(BlastRect.intersects(ShootRect))
            {
                Blasty=800;
                Shootx=-500;
            }
            if(BlastRect.intersects(ShipRect))
            {
                Blasty=800;
                Shipx=500;
                lifeCt=lifeCt-1;
            }
            if(Blast2Rect.intersects(ShipRect))
            {
                Blast2y=800;
                Shipx=500;
                lifeCt=lifeCt-1;
            }
            if(Blast3Rect.intersects(ShipRect))
            {
                Blast3y=800;
                Shipx=500;
                lifeCt=lifeCt-1;
            }
            if(Blast4Rect.intersects(ShipRect))
            {
                Blast4y=800;
                Shipx=500;
                lifeCt=lifeCt-1;
            }
            if(alienRect.intersects(ShootRect))
            {
                Shooty=-500;
                enemyX=-500;
                enemyY=-500;
                hitCt=hitCt+1;

            }
            if(alien2Rect.intersects(ShootRect))
            {
                Shooty=-500;
                enemy2X=-500;
                enemy2Y=-500;
                hitCt=hitCt+1;

            }
            if(alien3Rect.intersects(ShootRect))
            {
                Shooty=-500;
                enemy3X=-500;
                enemy3Y=-500;
                hitCt=hitCt+1;

            }
            if(alien4Rect.intersects(ShootRect))
            {
                Shooty=-500;
                enemy4X=-500;
                enemy4Y=-500;
                hitCt=hitCt+1;

            }
            if(hitCt==4)
                pageCt=3;
            if(lifeCt==0)
                pageCt=4;
        }
        while(pageCt<3);
        repaint();
    }

    public void paint (Graphics g)
    {
        if(pageCt==1)
        {
            bufferG.setColor(Color.black);
            bufferG.fillRect(0,0, 1304, 756);
            bufferG.setColor(Color. black);
            bufferG.fillRect(0,0,this.getWidth(),this.getHeight());
            bufferG.setColor(Color. white);
            bufferG.setFont(myFont);
            bufferG.drawString("Welcome to GALAGA! To play, use the left arrow and right arrow to move and the space bar to shoot!", 10, 250);
            bufferG.drawString("To start, click the screen.", 10, 275);
            bufferG.setColor( Color. black);            

        }
        if(pageCt==2)
        {
            bufferG.setColor(Color.black);
            bufferG.fillRect(0,0, 1304, 756);
            bufferG.setColor(Color. black);
            bufferG.fillRect(0,0,this.getWidth(),this.getHeight());
            bufferG.drawImage( space, 0,0, 1300, 756, this);
            bufferG.setColor(Color. green);
            bufferG.drawImage( enemy1, enemyX, enemyY, 40, 80, this); 
            bufferG.drawImage( enemy2, enemy2X, enemy2Y, 130, 180, this); 
            bufferG.drawImage( enemy3, enemy3X, enemy3Y, 100, 130, this); 
            bufferG.drawImage( enemy4, enemy4X, enemy4Y, 80, 110, this); 
            bufferG.fillRect( Shootx, Shooty, 5, 10);
            bufferG.setColor(Color. red);
            bufferG.fillRect( Blastx, Blasty, 5, 10);
            bufferG.fillRect( Blast2x, Blast2y, 5, 10);
            bufferG.fillRect( Blast3x, Blast3y, 5, 10);
            bufferG.fillRect( Blast4x, Blast4y, 5, 10);
            bufferG.setColor( Color. black);
            bufferG.drawImage(galaga, Shipx, Shipy, 220, 210, this);
            bufferG.setColor( Color. white);
            bufferG.drawString("Score: "+hitCt, 20, 690);
            bufferG.drawString("Life: "+lifeCt, 900, 690);

        }
        if(pageCt==3)
        {            
            bufferG.setColor(Color. black);
            bufferG.fillRect(0,0,13000, 800);
            bufferG.setFont(myFont);
            bufferG.setColor( Color. white);
            bufferG.drawString("You Win!", 600, 350);
        }
        if(pageCt==4)
        {            
            bufferG.setColor(Color. black);
            bufferG.fillRect(0,0,13000, 800);
            bufferG.setFont(myFont);
            bufferG.setColor( Color. white);
            bufferG.drawString("You Lose", 600, 350);
        }
        g.drawImage(buffer,0,0,this);

    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public void keyPressed(KeyEvent e)
    {
        int code=e.getKeyCode();

        if(code==e.VK_RIGHT)
        {
            Shipx=Shipx+20;
        }
        if(code==e.VK_LEFT)
        {
            Shipx=Shipx-20;
        }
        if(code==e.VK_SPACE && Shooty<0)
        {
            Shooty=Shipy-20;
            Shootx=Shipx;
            Shootx=Shipx+110;

        }
        if(Shipx>1290)
            Shipx=0;
        else if(Shipx<0)
            Shipx=1300;
    }

    public void keyReleased(KeyEvent e){}

    public void keyTyped(KeyEvent e){}

    public void mouseClicked(MouseEvent e)
    {
        if(pageCt==1)
        {
            pageCt=2;
            main.start();
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}

}