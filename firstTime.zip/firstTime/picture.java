import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class picture extends Applet implements ActionListener
{
    String name="";
    String lastName="";
    Button nameBtn=new Button ("Sentence");
    TextField nameTF= new TextField();
    TextField lastNameTF= new TextField();
    Font font30= new Font( "Papyrus", 1, 16);
    Image lion;

    public void init()
    {
        lion=this.getImage(this.getCodeBase(), "lion.png" );
        //gotten from http://www.themagazine.ca/2011/03/17/kings-of-the-jungle/
       
        this.setLayout(null);

        nameBtn.setBounds( 100, 500, 75, 40 );
        nameBtn.addActionListener(this);
        this.add(nameBtn);

        lastNameTF.setBounds( 400, 300, 150, 40 );
        nameTF.setBounds( 400, 100, 150, 40 );
        this.add(nameTF);
        this.add(lastNameTF);
    }

    public void actionPerformed(ActionEvent e)
    {
        name= nameTF.getText();
        lastName=lastNameTF.getText();
        repaint();
    }

    public void paint( Graphics g )
    {
        g.drawImage(lion, 500, 300, 200, 200, this ); 
        g.setFont( font30 );
        g.setColor( Color. red);
        g.drawString( "What is this animal? Type here." , 85,110 );
        g.drawString( "Write a word that describes that animal. Type here.", 10, 310 );
        g.drawString( "The "+ name+ " is "+lastName+".", 100, 600 );
    }
}
