import java.awt.*;
import java.applet.Applet;

/*Simple Applet to output stuff
  Amand Ramos  September 13,2012
 */

public class snowman extends Applet
{
        Color myPurple=new Color( 200, 1, 200 );
        Color myBrown=new Color( 170, 130, 110 );
        public void paint( Graphics g )
        {
                g.drawOval( 400, 400, 300, 300 );
                g.drawOval( 450, 200, 200, 200 );
                g.drawOval( 475, 50, 150, 150 );
                g.setColor( myPurple );
                g.fillRect( 470, 40, 160, 10 );
                g.fillRect( 509, 10, 80, 30 );
                g.setColor( myBrown );
                g.drawLine( 450, 280, 380, 100 );
                g.drawLine( 650, 280, 700, 100 );
                g.setColor( Color. black );
                g.fillOval( 545, 300, 20, 20 );
                g.fillOval( 545, 320, 20, 20 );
        }
}