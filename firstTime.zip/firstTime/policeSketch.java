import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make a magic 8 ball
Amanda Ramos Oct. 1, 2012
 */

public class policeSketch extends Applet implements ActionListener

{ 
    TextField faceTF= new TextField ();
    TextField eyesTF= new TextField ();
    TextField noseTF= new TextField ();
    TextField mouthTF= new TextField ();
    TextField styleTF= new TextField ();
    Button drawBtn= new Button ("Draw person");

    String faceInput="";
    String eyesInput="";
    String noseInput="";
    String mouthInput="";
    String styleInput="";

    double face;
    double eyes;
    double nose;
    double mouth;
    double style;

    public void init()
    {
        this.setLayout(null);

        drawBtn.setBounds ( 50, 600, 100, 50);
        this.add (drawBtn);
        drawBtn.addActionListener(this);

        faceTF.setBounds(90, 90, 100, 30 );
        this.add(faceTF);

        eyesTF.setBounds(90, 120, 100, 30 );
        this.add(eyesTF);
        
        noseTF.setBounds(90, 150, 100, 30 );
        this.add(noseTF);
        
        mouthTF.setBounds(90, 180, 100, 30 );
        this.add(mouthTF);
        
        styleTF.setBounds(90, 210, 100, 30 );
        this.add(styleTF);

    }

    public void paint (Graphics g)
    {
        if (face==1)
            g.drawOval(500, 100, 300, 300 );
        if (face==2)
            g.drawOval(500, 100, 300, 390 );
        if (face==3)
            g.drawRect(500, 100, 300, 300 );
        g.drawString("police sketch", 650, 50);
        g.drawString("enter face type ( 1=round 2=oval 3=square)", 200, 100);
        if (eyes==1)
        {   
            g.drawOval(540, 180, 80, 80 );
            g.drawOval(670, 180, 80, 80 );
            g.drawLine(620, 220, 670, 220);
        }
        if (eyes==2)
        {
           g.drawOval(670, 180, 50, 50 );
           g.drawOval(580, 180, 50, 50);
        }
        if (eyes==3)
        {   
            g.drawOval(550, 180, 70, 70 );
            g.drawOval(670, 180, 70, 70 );
        }
        if (eyes==4)
        {    
            g.drawOval(540, 180, 100, 50 );
            g.drawOval(660, 180, 100, 50 );
        }
        g.drawString("enter face type ( 1=glasses 2=beady 3=round 4=oval)", 200, 130);
        if (nose==1)
            g.drawOval(625, 225, 40, 65 );
        if (nose==2)
            g.drawOval(623, 225, 50, 50 );
        if (nose==3)
        {    
            g.drawLine(645, 225, 645, 270 );
            g.drawLine(645, 270, 655, 250 );
            g.drawLine(655, 250, 645, 300 );
        }
        g.drawString("enter nose type ( 1=glasses 2=beady 3=pointy )", 200, 160);
        if (mouth==1)
        {
           g.drawOval(600, 340, 100, 25 );
           g.drawLine(600, 353, 700, 353);
        }
        if (mouth==2)
        {
           g.drawOval(598, 310, 100, 55 );
           g.drawLine(598, 338, 698, 338);
        }
        if(mouth==3)
        {
            g.drawOval(598, 310, 100, 55 );
            g.setColor( Color. white);
            g.fillOval(598, 305, 100, 50 );
        }
        g.drawString("enter mouth type ( 1=thin 2=big 3=smile )", 200, 190);
        if(style==1)
        {
             g.drawRect(500, 60, 300, 60);
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == drawBtn )
        {
            faceInput= faceTF.getText();
            face= Double.parseDouble(faceInput);
            eyesInput=eyesTF.getText();
            eyes= Double.parseDouble(eyesInput);
            noseInput=noseTF.getText();
            nose= Double.parseDouble(noseInput);
            mouthInput=mouthTF.getText();
            mouth= Double.parseDouble(mouthInput);
            styleInput=styleTF.getText();
            style= Double.parseDouble(styleInput);
        }

        repaint();
    }
}