import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to make a magic 8 ball
  Amanda Ramos Oct. 1, 2012
 */

public class Magic8Ball extends Applet implements ActionListener

{
    Random rand= new Random ();
    TextField questionTF= new TextField ();
    Button answerBtn= new Button ("Click for response");
    Button clearBtn= new Button ("Clear All");
    Button shakeBtn= new Button ("Shake");
    Font myFont= new Font( "Papyrus" ,1, 30 );
    Image ball8;
    
    int randNum= 10;
    int x=300;
    
    
    public void init()
    {
        this.setLayout(null);
        
        ball8=this.getImage( this.getCodeBase(),"8_ball.png");
        //http://isamaras.wordpress.com/category/things-to-see-n-do/
        
        questionTF.setBounds(200, 90, 190, 30 );
        this.add(questionTF);
        
        answerBtn.setBounds( 10, 150, 180, 50 );
        this.add (answerBtn);
        answerBtn.addActionListener( this );
        
        clearBtn.setBounds( 100, 210, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
        
        shakeBtn.setBounds( 100, 270, 100, 50 );
        this.add (shakeBtn);
        shakeBtn.addActionListener( this );
    }
    
    public void paint (Graphics g)
    {
        answerBtn.setForeground( Color. red );
        answerBtn.setBackground( Color. blue );
        clearBtn.setForeground( Color. red );
        clearBtn.setBackground( Color. blue );
        shakeBtn.setForeground( Color. red );
        shakeBtn.setBackground( Color. blue );
        g.fillRect(0,0, 10000, 1000);
        g.setColor(Color. red);
        g.setFont ( myFont );
        g.drawImage( ball8, x, 300, 200, 200, this);
        g.drawString("Type in a yes/no question and I will tell you the answer.",400, 100 );
        if ( randNum == 10 )
            g.drawString("The Magic 8 Ball knows all!!!!", 200, 200 );
        if ( randNum == 0 )
            g.drawString("Certainly not", 200, 200 );
        if ( randNum == 1 )
            g.drawString("maybe", 200, 200 );
        if (randNum == 2 )
            g.drawString("Classified", 200, 200 );
        if (randNum == 3 )
            g.drawString( "Never", 200, 200 );
        if (randNum == 4 )
            g.drawString( "HELLZ YEAH!", 200, 200 );
        if (randNum == 5 )
            g.drawString( "Nope get a life", 200, 200 );
        if (randNum == 6 )
            g.drawString( "Hmmmm. Its a possibility", 200, 200 );
        if (randNum == 7 )
            g.drawString( "Out to lunch", 200, 200 );
        if (randNum == 8 )
            g.drawString( "Just leave me alone", 200, 200 );
        if (randNum == 9 )
            g.drawString( "This is my voice mail, I'm not home, at the tone leave a message *BEEP*", 200, 200 );
        if (randNum == 11 )
            g.drawString( "Just forget everything and enjoy life", 200, 200 );
        if (randNum == 12 )
            g.drawString( "Um... maybe its in between", 200, 200 );
        if (randNum == 13 )
            g.drawString( "OF COURSE IT IS!!!!", 200, 200 );
        if (randNum == 14 )
            g.drawString( "I will say... HELL YEAH!", 200, 200 );
        if (randNum == 15 )
            g.drawString( "Its a difficult question", 200, 200 );
        //This program hates me!!!!!
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == answerBtn )
        {
            randNum=rand.nextInt(16);
        }
        
        if(e.getSource() == clearBtn )
        {
            randNum = 10;
            questionTF.setText("");
        }
        if(e.getSource() == shakeBtn )
        {
            if (x==300)
                x= 350;
            else
                x=300;
        }
     repaint();
   }
}