import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.applet.AppletStub;
/*A simple applet make a tutorial for NIM
Amanda Ramos Nov. 5, 2012
 */

public class NIM implements ActionListener, AppletStub

{
    Random rand= new Random ();
    Button oneBtn= new Button ("-1");
    Button twoBtn= new Button ("-2");
    Button threeBtn= new Button ("-3");
    Button rulesBtn= new Button ("Rules");
    Button resetBtn= new Button ("Reset");

    Applet appletToLoad=new Applet();

    Font myFont= new Font( "Papyrus" ,1, 27 );
    Color myPurple=new Color( 200, 1, 200 );
    Color mystery=new Color (250, 85, 110 );
    Color myOrange=new Color (240, 150, 0 );

    int randNum=15+(15);
    int numRocks =randNum;
    String output="";
    int rocksCt=25;
    int player=1;

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);

        resize(1300, 700);

        oneBtn.setBounds( 20, 550, 70, 40 );
        this.add (oneBtn);
        oneBtn.addActionListener( this );
        oneBtn.setForeground( Color. white );
        oneBtn.setBackground( Color. blue );

        twoBtn.setBounds( 100, 550, 70, 40 );
        this.add (twoBtn);
        twoBtn.addActionListener( this );
        twoBtn.setForeground( Color. white );
        twoBtn.setBackground( Color. blue );

        threeBtn.setBounds( 180, 550, 70, 40 );
        this.add (threeBtn);
        threeBtn.addActionListener( this );
        threeBtn.setForeground( Color. white );
        threeBtn.setBackground( Color. blue );

        resetBtn.setBounds( 340, 550, 70, 40 );
        this.add (resetBtn);
        resetBtn.addActionListener( this );
        resetBtn.setForeground( Color. white );
        resetBtn.setBackground( Color. blue );

        rulesBtn.setBounds( 260, 550, 70, 40 );
        this.add (rulesBtn);
        rulesBtn.addActionListener( this );
        rulesBtn.setForeground( Color. white );
        rulesBtn.setBackground( Color. blue );
    }

    public void drawRocks( int numRocks, Graphics g)
    {
        for (int num=1; num<=numRocks; num++)
            g.fillOval(60+40*num, 100, 35, 35);
    }

    public void paint (Graphics g)
    {
        g.setColor(Color. pink);
        g.fillRect(0,0, 2000, 2000);
        g.setColor( myOrange);
        drawRocks(numRocks, g);
        g.setColor(myPurple);
        g.setFont(myFont);
        g.drawString("There are "+numRocks+" rocks remaining.", 100, 180);
        if(numRocks>0)
            g.drawString("Player "+player+" is up!", 100, 260);
        else
            g.drawString("", 100, 260);
        g.drawString(output, 100, 350);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == oneBtn )
        {
            numRocks=numRocks-1;
            if(numRocks==0)
                output="Player " +player+ " wins!";
            if(player==1)
                player=2;
            else
                player=1;
        }
        if(e.getSource() == twoBtn )
        {
            numRocks=numRocks-2;
            if(numRocks==0)
                output="Player " +player+ " wins!";
            if(player==1)
                player=2;
            else
                player=1;
        }
        if(e.getSource() == threeBtn )
        {
            numRocks=numRocks-3;
            if(numRocks==0)
                output="Player " +player+ " wins!";
            if(player==1)
                player=2;
            else
                player=1;
        }
        if(e.getSource() == resetBtn )
        {
            player=1;
            numRocks=25;
            output="";
            twoBtn.setVisible(true);
            threeBtn.setVisible(true);
            randNum=rand.nextInt(16);
            if ( randNum == 15 )
                numRocks=30; 
            if ( randNum == 14 )
                numRocks=29; 
            if ( randNum == 13 )
                numRocks=28; 
            if ( randNum == 12 )
                numRocks=27; 
            if ( randNum == 11 )
                numRocks=26;
            if ( randNum == 10 )
                numRocks=25;
            if ( randNum == 9 )
                numRocks=24;
            if ( randNum == 8 )
                numRocks=23;
            if ( randNum == 7 )
                numRocks=22;
            if ( randNum == 6 )
                numRocks=21;
            if ( randNum == 5 )
                numRocks=20;
            if ( randNum == 4 )
                numRocks=19;
            if ( randNum == 3 )
                numRocks=18;
            if ( randNum == 2 )
                numRocks=17;
            if ( randNum == 1 )
                numRocks=16;
            if ( randNum == 0 )
                numRocks=15;
        }
        if(e.getSource() == rulesBtn )
        {
            {  
                oneBtn.setVisible(false);
                twoBtn.setVisible(false);
                threeBtn.setVisible(false);
                resetBtn.setVisible(false);
                rulesBtn.setVisible(false);
            }
            try
            {
                Class applet2=Class.forName("NIMTutorial");
                appletToLoad=(Applet)applet2.newInstance();
                appletToLoad.setStub(this);
                add(appletToLoad);
                appletToLoad.init();
                appletToLoad.start();

            }
            catch (Exception p){}
        }
        if(numRocks==2)
        {
            threeBtn.setVisible(false);
        }
        if(numRocks==1)
        {
            twoBtn.setVisible(false);
            threeBtn.setVisible(false);
        }

        repaint();
    }
}