import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.awt.image.BufferedImage;
/*A simple applet to make Mario move
Amanda Ramos Dec. 20, 2012
 */

public class game extends Applet implements Runnable, KeyListener, MouseListener

{    
    Thread main= new Thread(this);
    BufferedImage buffer;
    Graphics2D bufferG;
    Color leftTopColor;
    Color rightTopColor;

    Font myFont= new Font( "Consolas" ,1, 20 );
    Image pictureArray[]= new Image[17];
    Image redArray[]= new Image[8];
    Image pinkArray[]= new Image[8];
    Image maze;
    Image rocoto;
    int pacmanX=555;
    int pacmanY=350;
    int redX=555;
    int redY=225;
    int pinkX=355;
    int pinkY=90;
    boolean right=false;
    boolean left=false; 
    boolean stand=true; 
    boolean up=false; 
    boolean down=false; 
    boolean dead=false;
    int frameCt=0;
    int frame2Ct=3;
    int deadframeCt=6;
    int redCt=0;
    int pinkCt=0;
    int scoreCt=0;
    int liveCt=3;
    int pageCt=1;
    int randNum= 2;
    int randNum1= 3;

    public void init()
    {
        this.setLayout(null);
        this.addKeyListener(this);
        this.addMouseListener(this);
        resize(1300, 756);

        buffer= new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_INT_ARGB);
        bufferG=buffer.createGraphics();

        pictureArray[0]=getImage( this.getCodeBase(),"pacman sprite5.png");
        pictureArray[1]=getImage( this.getCodeBase(),"pacman sprite1.png");
        pictureArray[2]=getImage( this.getCodeBase(),"pacman sprite3.png");
        pictureArray[3]=getImage( this.getCodeBase(),"pacman sprite2.png");
        pictureArray[4]=getImage( this.getCodeBase(),"pacman sprite4.png");
        pictureArray[5]=getImage( this.getCodeBase(),"pacman sprite5.png");
        pictureArray[6]=getImage( this.getCodeBase(),"pacman sprite6.png");
        pictureArray[7]=getImage( this.getCodeBase(),"pacman sprite7.png");
        pictureArray[8]=getImage( this.getCodeBase(),"pacman sprite8.png");
        pictureArray[9]=getImage( this.getCodeBase(),"pacman sprite9.png");
        pictureArray[10]=getImage( this.getCodeBase(),"pacman sprite10.png");
        pictureArray[11]=getImage( this.getCodeBase(),"pacman sprite11.png");
        pictureArray[12]=getImage( this.getCodeBase(),"pacman sprite12.png");
        pictureArray[13]=getImage( this.getCodeBase(),"pacman sprite13.png");
        pictureArray[14]=getImage( this.getCodeBase(),"pacman sprite14.png");
        pictureArray[15]=getImage( this.getCodeBase(),"pacman sprite15.png");
        pictureArray[16]=getImage( this.getCodeBase(),"pacman sprite16.png");

        redArray[0]=getImage( this.getCodeBase(),"red sprite1.png");
        redArray[1]=getImage( this.getCodeBase(),"red sprite2.png");
        redArray[2]=getImage( this.getCodeBase(),"red sprite3.png");
        redArray[3]=getImage( this.getCodeBase(),"red sprite4.png");
        redArray[4]=getImage( this.getCodeBase(),"red sprite5.png");
        redArray[5]=getImage( this.getCodeBase(),"red sprite6.png");
        redArray[6]=getImage( this.getCodeBase(),"red sprite7.png");
        redArray[7]=getImage( this.getCodeBase(),"red sprite8.png");

        pinkArray[0]=getImage( this.getCodeBase(),"pink sprite1.png");
        pinkArray[1]=getImage( this.getCodeBase(),"pink sprite2.png");
        pinkArray[2]=getImage( this.getCodeBase(),"pink sprite3.png");
        pinkArray[3]=getImage( this.getCodeBase(),"pink sprite4.png");
        pinkArray[4]=getImage( this.getCodeBase(),"pink sprite5.png");
        pinkArray[5]=getImage( this.getCodeBase(),"pink sprite6.png");
        pinkArray[6]=getImage( this.getCodeBase(),"pink sprite7.png");
        pinkArray[7]=getImage( this.getCodeBase(),"pink sprite8.png");

        maze=this.getImage( this.getCodeBase(),"pacman maze1.png");
        //gotten from Google Images, search for pacman maze

        main.start();
    }

    public void run()
    {
        while(pageCt<3)
        {
            Rectangle pacmanRect= new Rectangle(pacmanX, pacmanY, 60, 60);
            Rectangle redRect= new Rectangle(redX, redY, 60, 60);
            Rectangle pinkRect= new Rectangle(pinkX, pinkY, 60, 60);

            leftTopColor=new Color(buffer.getRGB(pacmanX-1,pacmanY-1));
            if(!leftTopColor.equals(Color.black))
            {
                stand=true;
                right=false;
                left=false;
                dead=false;
                up=false;
                down=false;
                frameCt=0;
            }
            rightTopColor=new Color(buffer.getRGB(pacmanX+86,pacmanY-1));
            if(!rightTopColor.equals(Color.black))
            {
                stand=true;
                right=false;
                dead=false;
                left=false;
                up=false;
                down=false;
                frameCt=0;
            }

            if(right)
                pacmanX=pacmanX+10;
            if(left)
                pacmanX=pacmanX-10;
            if(up)
                pacmanY=pacmanY-10;
            if(down)
                pacmanY=pacmanY+10;
            redX=redX+10;
            pinkX=pinkX+10;

            repaint();
            try
            {main.sleep(100);}
            catch(Exception e){}
            frameCt++;
            if(frameCt==2)
                frameCt=0;

            frame2Ct++;
            if(frame2Ct==5)
                frame2Ct=3;

            redCt++;
            if(redCt==1)
                redCt=0;

            pinkCt++;
            if(pinkCt==1)
                pinkCt=0;

            if(pacmanX<280)
                pacmanX=830;
            if(pacmanX>830)
                pacmanX=280;

            if(redX<280)
                redX=830;
            if(redX>830)
                redX=280;

            if(pinkX<280)
                pinkX=830;
            if(pinkX>830)
                pinkX=280;

            if(redRect.intersects(pacmanRect))
            {
                liveCt=liveCt-1;
                dead=true;
                stand=false;
                right=false;
                left=false;
                up=false;
                down=false;
                deadframeCt++;
            }
        }

    }

    public void paint (Graphics g)
    {
        bufferG.setColor(Color.black);
        bufferG.fillRect(0,0,1300,800);
        if(pageCt==1)
        {
            bufferG.setColor(Color. white);
            bufferG.setFont(myFont);
            bufferG.drawString("Welcome to PacMan! To play, use the left arrow and right arrow to move and the space bar to shoot!", 10, 250);
            bufferG.drawString("To start, click the screen.", 10, 275);
        }
        if(pageCt==2)
        {
            bufferG.setColor(Color.blue);
            bufferG.fillRect(300,0,600,700);
            bufferG.drawImage(maze, 300, 0, 600, 700, this);
            bufferG.setColor(Color. white);
            bufferG.setFont(myFont);
            bufferG.drawImage(redArray[redCt],redX,redY,85,85,this);
            bufferG.drawImage(pinkArray[pinkCt],pinkX,pinkY,85,85,this);
            bufferG.drawString("Lives", 1000, 400);
            bufferG.drawString("Score", 1000, 100);
            bufferG.drawString("Stand"+rightTopColor,100,100);
            if(stand)
            {    
                bufferG.drawImage(pictureArray[0], pacmanX, pacmanY, 85, 85, this);
            }
            if(right)
            {
                bufferG.drawImage(pictureArray[frameCt], pacmanX, pacmanY, 85, 85, this);
            }
            if(left)
            {
                bufferG.drawImage(pictureArray[frameCt], pacmanX+85, pacmanY, -85, 85, this);  
            }
            if(up)
            {
                bufferG.drawImage(pictureArray[frame2Ct], pacmanX, pacmanY+85, 85, -85, this);  
            }
            if(down)
            {
                bufferG.drawImage(pictureArray[frame2Ct], pacmanX, pacmanY, 85, 85, this);  
            }
            if(dead)
            {
                bufferG.drawImage(pictureArray[deadframeCt], pacmanX, pacmanY, 85, 85, this); 
            }
        }
        g.drawImage(buffer,0,0,this);
    }

    public void keyPressed(KeyEvent e)
    {
        int code=e.getKeyCode();

        if(code==e.VK_RIGHT)
        {
            right=true;
            left=false;
            stand=false;
            up=false;
            down=false;
            pacmanX=pacmanX+10;
        }
        if(code==e.VK_LEFT)
        {
            left=true;
            right=false;
            stand=false;
            up=false;
            down=false;
            pacmanX=pacmanX-10;
        }
        if(code==e.VK_UP)
        {
            left=false;
            right=false;
            stand=false;
            up=true;
            down=false;
            pacmanY=pacmanY-10;
        }
        if(code==e.VK_DOWN)
        {
            left=false;
            right=false;
            stand=false;
            up=false;
            down=true;
            pacmanY=pacmanY+10;
        }
    }

    public void keyReleased(KeyEvent e){}

    public void keyTyped(KeyEvent e){}

    public void mouseClicked(MouseEvent e)
    {
        if(pageCt==1)
        {
            pageCt=2;
            main.start();
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}

}