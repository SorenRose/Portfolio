
import java.awt.*;
import java.applet.Applet;
/*picture frame
  Amanda Ramos  September 13,2012
 */

public class FrameApplet extends Applet
{
        Color myOrange=new Color( 250, 180, 30 );
        Color myGold=new Color ( 255, 230, 85 );
        Color myBlue=new Color (80, 20, 130 );
        Color myRed=new Color ( 255, 1, 1 );
        Color myGray=new Color (130, 130, 130 ); 
        Font font30=new Font ("Papyrus", 1, 30);
            public void paint( Graphics g )
        {
           g.setColor( myGold );
           g.fillRect( 30, 30, 1220, 650 );
           g.setColor( myOrange );
           g.fillRect( 130, 130, 1020, 450 );
           g.setColor( Color. black );
           g.drawLine( 130, 130, 30, 30 );
           g.drawLine( 1150, 130, 1250, 30 );
           g.drawLine( 30, 680, 130, 580 );
           g.drawLine( 1250, 680, 1150, 580 );
           g.setColor( Color. red );
           g.fillOval( 550, 220, 200, 200 );
           g.setColor( myBlue );
           g.fillRect( 130, 430, 1020, 100 );
           g.setColor( myRed );
           g.fillOval( 550, 430, 200, 100 );
           g.drawString( "Sunset on the beach", 500, 100);
        }
}