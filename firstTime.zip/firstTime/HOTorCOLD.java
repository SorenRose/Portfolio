import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make the mouse work in a program
Amanda Ramos Nov. 14, 2012
 */

public class HOTorCOLD extends Applet implements MouseListener

{
    int mouseX=-10;
    int mouseY=-10;
    int secretX=550;
    int secretY= 550;
    String message="";
    Font myFont= new Font( "Papyrus" ,1, 27 );

    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);

        resize(1300, 700);

        this.addMouseListener(this);
    }

    public void paint (Graphics g)
    {
        g.setFont(myFont);
        g.drawString("Mouse(X): "+mouseX+" and(Y) "+mouseY, 10, 30);
        g.drawString(message, 10, 70);
    }

    public void mouseClicked( MouseEvent e )
    {
        mouseX=e.getX();
        mouseY=e.getY();
        if((mouseX==secretX&&mouseY==secretY))
        {
            message="You got it!!!!";
        }
        else if((mouseX>=secretX-5&&mouseX<=secretX+5)&&
           (mouseY>=secretY-5&&mouseY<=secretY+5))
        {
            message="You're on fire!!!";
        }
        else if((mouseX>=secretX-25&&mouseX<=secretX+25)&&
           (mouseY>=secretY-25&&mouseY<=secretY+25))
        {
            message="You're hot!!";
        }
         else if((mouseX>=secretX-50&&mouseX<=secretX+50)&&
           (mouseY>=secretY-50&&mouseY<=secretY+50))
        {
            message="You're warm!!";
        }
         else if((mouseX>=secretX-75&&mouseX<=secretX+75)&&
           (mouseY>=secretY-75&&mouseY<=secretY+75))
        {
            message="You're getting warmer!!";
        }
         else if((mouseX>=secretX-100&&mouseX<=secretX+100)&&
           (mouseY>=secretY-100&&mouseY<=secretY+100))
        {
            message="You're a little cold now!";
        }
         else if((mouseX>=secretX-150&&mouseX<=secretX+150)&&
           (mouseY>=secretY-150&&mouseY<=secretY+150))
        {
            message="You're still cold but closer!";
        }
         else if((mouseX>=secretX-200&&mouseX<=secretX+200)&&
           (mouseY>=secretY-200&&mouseY<=secretY+200))
        {
            message="You're cold!";
        }
        else
        {
            message="You're freezing";
        }
        repaint();
    }

    public void mousePressed(MouseEvent e){}


    public void mouseReleased(MouseEvent e){}


    public void mouseEntered(MouseEvent e){}


    public void mouseExited(MouseEvent e){}

    
}