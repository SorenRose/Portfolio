import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make animation work
Amanda Ramos Nov. 28, 2012
 */

public class AnimationPractice extends Applet implements Runnable

{

    Thread main=new Thread(this);
    int x=1200;
    int y=20;
    int x1=12;
    int y1=5;
    Font myFont= new Font( "Papyrus" ,1, 16 );

    public void init()
    {
        this.setLayout(null);

        resize(1300, 700);

        main.start();

    }

    public void run()
    {
        
        do
        {
            x=x-x1;
            y=y+y1;
            repaint();
            try
            {main.sleep(100);}
            catch(Exception e){}
            if(x<0)
            {
                x1= -12;
                y1= -5;
            }
            else if (x>1200)
            {
                x1= 12;
                y1= 5;
            }
        }
        while(true);
    }

    public void paint (Graphics g)
    {
        g.setFont(myFont);
        g.drawString("CAN'T CATCH ME!", x, y);
    }

}