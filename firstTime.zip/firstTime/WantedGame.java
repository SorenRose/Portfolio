import java.awt.*;
import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet make a find me game
Amanda Ramos Nov. 15, 2012
 */

public class WantedGame extends Applet implements MouseListener, ActionListener

{
    int mouseX=-10;
    int mouseY=-10;
    int secretX=330;
    int secretY= 120;
    int secretX1=440;
    int secretY1= 230;
    int secretX2=450;
    int secretY2= 375;
    String message="Find the one that's different!";
    Button nextBtn= new Button ("Next");
    Image Wanted;
    Image Wanted1;
    Image Wanted2;
    int pageCt=0;
    Font myFont= new Font( "Papyrus" ,1, 27 );
    long beginTime, endTime;
    double totalTime;
    String output;
    public void appletResize(int width, int length)
    {
        resize( 1300, 700 );  
    }

    public void init()
    {
        this.setLayout(null);
        
        beginTime=System.currentTimeMillis();

        Wanted=this.getImage( this.getCodeBase(),"Wanted!1.png");
        //http://www.google.com/imgres?

        Wanted1=this.getImage( this.getCodeBase(),"wanted3.jpg");
        //http://www.google.com/imgres?
        
        Wanted2=this.getImage( this.getCodeBase(),"wanted.jpg");
        //http://www.google.com/imgres?
        
        resize(1300, 700);

        nextBtn.setVisible(false);

        nextBtn.setBounds( 600, 10, 100, 40 );
        this.add (nextBtn);
        nextBtn.addActionListener( this );

        this.addMouseListener(this);
    }

    public void paint (Graphics g)
    {
        g.setFont(myFont);
        g.setColor(Color. red);
        if(pageCt==0)
        {
            g.drawImage( Wanted, 0, 50, 1300, 700, this);
            g.drawString("Mouse(X): "+mouseX+" and(Y) "+mouseY, 10, 30);
            g.drawString(message, 375, 25);
            g.drawString(output, 705, 25);
        }
        if(pageCt==1)
        {
            g.drawImage(Wanted1, 100, 100, 800, 500, this);
            g.drawString("Mouse(X): "+mouseX+" and(Y) "+mouseY, 10, 30);
            g.drawString(message, 375, 25);
            g.drawString(output, 705, 25);
        }
        if(pageCt==2)
        {
            g.drawImage(Wanted2, 100, 100, 400, 300, this);
            g.drawString("Mouse(X): "+mouseX+" and(Y) "+mouseY, 10, 30);
            g.drawString(message, 375, 25);
            g.drawString(output, 705, 25);
        }
    }

    public void mouseClicked( MouseEvent e )
    {
        mouseX=e.getX();
        mouseY=e.getY();
        if(pageCt==0)
        {
            if((mouseX>=secretX-40&&mouseX<=secretX+66)&&
            (mouseY>=secretY-40&&mouseY<=secretY+40))
            {
                message="You got it!!!!";
                endTime=System.currentTimeMillis();
                totalTime=(endTime-beginTime)/1000.0;
                output="Total time is "+totalTime;
                nextBtn.setVisible(true);
            }
        }
        else if(pageCt==1)
        {
            if((mouseX>=secretX1-20&&mouseX<=secretX1+20)&&
            (mouseY>=secretY1-20&&mouseY<=secretY1+20))
            {
                message="You got it!!!!";
                endTime=System.currentTimeMillis();
                totalTime=(endTime-beginTime)/1000.0;
                output="Total time is "+totalTime;
                nextBtn.setVisible(true);
            }
        }
        else if(pageCt==2)
        {
            if((mouseX>=secretX2-16&&mouseX<=secretX2+10)&&
            (mouseY>=secretY2-23&&mouseY<=secretY2+13))
            {
                message="You got it!!!!";
                endTime=System.currentTimeMillis();
                totalTime=(endTime-beginTime)/1000.0;
                output="Total time is "+totalTime;
                nextBtn.setVisible(true);
            }
        }
            repaint();
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == nextBtn )
        {
            pageCt= pageCt+1;
            nextBtn.setVisible(false);
            message="Find the one that's different!";
            output="";
        }
        repaint();
    }


    public void mousePressed(MouseEvent e){}

    public void mouseReleased(MouseEvent e){}

    public void mouseEntered(MouseEvent e){}

    public void mouseExited(MouseEvent e){}

}