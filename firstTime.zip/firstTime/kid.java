import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class kid extends Applet implements ActionListener
{
    String name="";
    String lastName="";
    Button nameBtn=new Button ("Sentence");
    TextField nameTF= new TextField();
    TextField lastNameTF= new TextField();
    Font font30= new Font( "Papyrus", 1, 16);

    public void init()
    {
        this.setLayout(null);

        nameBtn.setBounds( 100, 500, 75, 40 );
        nameBtn.addActionListener(this);
        this.add(nameBtn);

        lastNameTF.setBounds( 400, 300, 150, 40 );
        nameTF.setBounds( 400, 100, 150, 40 );
        this.add(nameTF);
        this.add(lastNameTF);
    }

    public void actionPerformed(ActionEvent e)
    {
        name= nameTF.getText();
        lastName=lastNameTF.getText();
        repaint();
    }

    public void paint( Graphics g )
    {
        g.setFont( font30 );
        g.setColor( Color. red);
        g.drawString( "What is your favorite animal? Type here." , 85,110 );
        g.drawString( "Write a word that describes your animal. Type here.", 10, 310 );
        g.drawString( "The "+ name+ " is "+lastName+".", 100, 600 );
    }
}
