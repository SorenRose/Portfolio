import java.util.Random;
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
/*A simple applet to tewll the letter grade
  Amanda Ramos Oct. 9, 2012
 */

public class grade extends Applet implements ActionListener

{
    TextField gradeTF= new TextField ();
    Button gradeBtn= new Button ("Convert to lettter");
    Button clearBtn= new Button ("Clear All");
   
    double gradeNum;
    String input, output="";
    
    public void init()
    {
        this.setLayout(null);
       
        gradeTF.setBounds(200, 90, 190, 30 );
        this.add(gradeTF);
        
        gradeBtn.setBounds( 10, 150, 180, 50 );
        this.add (gradeBtn);
        gradeBtn.addActionListener( this );
        
        clearBtn.setBounds( 100, 210, 100, 50 );
        this.add (clearBtn);
        clearBtn.addActionListener( this );
        
    }
    
    public void paint (Graphics g)
    {
        g.drawString("Type your grade in and you will get your grade letter.",400, 100 );
        g.drawString(output, 200, 400);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == gradeBtn )
        {
          input= gradeTF.getText();
          gradeNum= Double.parseDouble(input);
          if ( gradeNum >= 93 )
                output="You Got an A!!!!";
          else if ( gradeNum >= 85 )
                output="You got a B!";
          else if ( gradeNum >= 75 )
                output="You got a C.";
          else if (gradeNum >= 70 )
                output="You got a D.";
          else if (gradeNum >= 0 )
                output="You got an F.";
        }
        
        if(e.getSource() == clearBtn )
        {
            
            gradeTF.setText("");
        }
     repaint();
   }
}